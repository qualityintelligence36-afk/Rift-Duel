type Kind = "shot" | "hit" | "boom" | "dash" | "pick" | "shield" | "clang" | "chip" | "reform";

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let music: GainNode | null = null;
let muted = false;

type Bed = "menu" | "fight";

const MENU_LEAD = [0, 4, 7, 12, 7, 4, 9, 7, 5, 9, 12, 9, 7, 4, 2, 0];
const MENU_BASS = [0, -1, -5, -1, 5, -1, 7, -1, 9, -1, 5, -1, 7, -1, 0, -1];
const FIGHT_LEAD = [0, -1, 7, 3, -1, 10, -1, 7, 12, -1, 10, 8, -1, 7, 3, -1];
const FIGHT_BASS = [0, -1, 0, -1, 7, -1, 5, -1, 3, -1, 5, -1, 7, -1, 0, -1];

let bed: Bed = "menu";
let step = 0;
let nextAt = 0;
let timer = 0;
let hat: AudioBuffer | null = null;

function context(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC({ latencyHint: "interactive" });
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.32;
    master.connect(ctx.destination);
    music = ctx.createGain();
    music.gain.value = 0.62;
    music.connect(master);
    const n = Math.floor(ctx.sampleRate * 0.04);
    hat = ctx.createBuffer(1, n, ctx.sampleRate);
    const data = hat.getChannelData(0);
    for (let i = 0; i < n; i += 1) data[i] = (Math.random() * 2 - 1) * (1 - i / n);
  }
  return ctx;
}

/** Call from a pointer/key handler so iOS actually makes noise. */
export function unlockAudio(): void {
  const audio = context();
  if (audio && audio.state === "suspended") void audio.resume();
  ensureLoop();
}

export function setBed(next: Bed): void {
  if (next === bed && timer) return;
  bed = next;
  step = 0;
  if (ctx) nextAt = ctx.currentTime + 0.03;
  if (music && ctx) music.gain.setTargetAtTime(next === "menu" ? 0.7 : 0.48, ctx.currentTime, 0.06);
  if (ctx) ensureLoop();
}

export function setMuted(next: boolean): void {
  muted = next;
  if (!master || !ctx) return;
  master.gain.setTargetAtTime(next ? 0 : 0.32, ctx.currentTime, 0.02);
}

export function isMuted(): boolean {
  return muted;
}

function tone(
  freq: number,
  dur: number,
  type: OscillatorType,
  gain: number,
  slideTo?: number,
): void {
  const audio = context();
  if (!audio || !master || muted) return;
  const osc = audio.createOscillator();
  const g = audio.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, audio.currentTime);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(40, slideTo), audio.currentTime + dur);
  g.gain.setValueAtTime(gain, audio.currentTime);
  g.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + dur);
  osc.connect(g);
  g.connect(master);
  osc.start();
  osc.stop(audio.currentTime + dur + 0.02);
  osc.onended = () => {
    osc.disconnect();
    g.disconnect();
  };
}

function noise(dur: number, gain: number, fromHz: number, toHz: number, kind: BiquadFilterType): void {
  const audio = context();
  if (!audio || !master || muted) return;
  const length = Math.floor(audio.sampleRate * dur);
  const buffer = audio.createBuffer(1, length, audio.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i += 1) data[i] = Math.random() * 2 - 1;
  const src = audio.createBufferSource();
  src.buffer = buffer;
  const filter = audio.createBiquadFilter();
  filter.type = kind;
  filter.Q.value = kind === "bandpass" ? 3.2 : 0.7;
  filter.frequency.setValueAtTime(fromHz, audio.currentTime);
  filter.frequency.exponentialRampToValueAtTime(Math.max(40, toHz), audio.currentTime + dur);
  const g = audio.createGain();
  g.gain.setValueAtTime(gain, audio.currentTime);
  g.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + dur);
  src.connect(filter);
  filter.connect(g);
  g.connect(master);
  src.start();
  src.onended = () => {
    src.disconnect();
    filter.disconnect();
    g.disconnect();
  };
}

export function playFx(kind: Kind): void {
  const jitter = 0.94 + Math.random() * 0.12;
  if (kind === "shot") {
    tone(720 * jitter, 0.07, "square", 0.08, 280);
    tone(180 * jitter, 0.05, "sine", 0.06);
  } else if (kind === "hit") {
    noise(0.2, 0.42, 1600, 140, "bandpass");
    tone(160 * jitter, 0.22, "sawtooth", 0.12, 42);
    tone(620 * jitter, 0.08, "square", 0.07, 140);
    tone(240, 0.16, "triangle", 0.08, 70);
  } else if (kind === "boom") {
    noise(0.38, 0.28, 900, 80, "lowpass");
    tone(90, 0.32, "sawtooth", 0.08, 40);
  } else if (kind === "dash") {
    tone(220, 0.12, "sawtooth", 0.06, 640);
  } else if (kind === "pick") {
    tone(523, 0.08, "square", 0.07);
    tone(659, 0.09, "square", 0.06);
    tone(784, 0.12, "square", 0.06);
  } else if (kind === "shield") {
    noise(0.18, 0.16, 400, 1400, "bandpass");
    tone(280, 0.22, "sine", 0.08, 880);
    tone(520, 0.16, "triangle", 0.05, 1240);
  } else if (kind === "clang") {
    noise(0.07, 0.2, 2200, 700, "bandpass");
    tone(1180 * jitter, 0.09, "square", 0.07, 420);
    tone(1860 * jitter, 0.12, "sine", 0.05, 640);
  } else if (kind === "chip") {
    noise(0.1, 0.22, 900, 160, "lowpass");
    tone(130 * jitter, 0.1, "square", 0.06, 55);
  } else if (kind === "reform") {
    tone(196, 0.1, "sine", 0.05, 392);
    tone(294, 0.14, "triangle", 0.04, 588);
  }
}

export function resumeAudio(): void {
  if (ctx && ctx.state === "suspended") void ctx.resume();
  if (ctx) ensureLoop();
}

function hz(root: number, semi: number): number {
  return root * 2 ** (semi / 12);
}

function blip(when: number, freq: number, dur: number, type: OscillatorType, gain: number): void {
  if (!ctx || !music || freq <= 0) return;
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, when);
  g.gain.setValueAtTime(0.0001, when);
  g.gain.exponentialRampToValueAtTime(gain, when + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, when + Math.max(0.02, dur));
  osc.connect(g);
  g.connect(music);
  osc.start(when);
  osc.stop(when + dur + 0.02);
  osc.onended = () => {
    osc.disconnect();
    g.disconnect();
  };
}

function tick(when: number, gain: number): void {
  if (!ctx || !music || !hat) return;
  const src = ctx.createBufferSource();
  src.buffer = hat;
  const filter = ctx.createBiquadFilter();
  filter.type = "highpass";
  filter.frequency.value = 1800;
  const g = ctx.createGain();
  g.gain.setValueAtTime(gain, when);
  src.connect(filter);
  filter.connect(g);
  g.connect(music);
  src.start(when);
  src.onended = () => {
    src.disconnect();
    filter.disconnect();
    g.disconnect();
  };
}

function ensureLoop(): void {
  if (!ctx) return;
  if (!timer) {
    nextAt = ctx.currentTime + 0.05;
    timer = window.setInterval(pump, 50);
    ctx.addEventListener("statechange", () => {
      if (ctx?.state === "running") pump();
    });
  }
}

function pump(): void {
  if (!ctx || !music) return;
  if (muted || ctx.state !== "running") {
    nextAt = 0;
    return;
  }
  if (nextAt < ctx.currentTime) nextAt = ctx.currentTime + 0.04;
  const stepDur = bed === "menu" ? 60 / 116 / 2 : 60 / 126 / 2;
  const horizon = ctx.currentTime + 0.12;
  while (nextAt < horizon) {
    const i = step % 16;
    if (bed === "menu") {
      const lead = MENU_LEAD[i];
      const bass = MENU_BASS[i];
      if (lead >= 0) blip(nextAt, hz(523.25, lead), stepDur * 0.42, "square", 0.07);
      if (lead >= 0) blip(nextAt, hz(523.25, lead - 12), stepDur * 0.36, "triangle", 0.04);
      if (bass >= 0) blip(nextAt, hz(130.81, bass), stepDur * 0.7, "square", 0.05);
      if (i % 4 === 0) blip(nextAt, 78, 0.09, "sine", 0.04);
    } else {
      const lead = FIGHT_LEAD[i];
      const bass = FIGHT_BASS[i];
      if (lead >= 0) blip(nextAt, hz(440, lead), stepDur * 0.28, "square", 0.05);
      if (bass >= 0) blip(nextAt, hz(110, bass), stepDur * 0.55, "triangle", 0.055);
      if (i % 4 === 2) tick(nextAt, 0.03);
    }
    step += 1;
    nextAt += stepDur;
  }
}
