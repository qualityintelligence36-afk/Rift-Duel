export type MapId = "night" | "day1" | "dusk" | "snow" | "haunt" | "rain";

export type ArenaTheme = {
  id: MapId;
  name: string;
  blurb: string;
  sky: number;
  fog: number;
  fogDensity: number;
  hemiSky: number;
  hemiGround: number;
  hemi: number;
  sun: number;
  sunIntensity: number;
  sunPos: [number, number, number];
  disc: boolean;
  discColor: number;
  rift: number;
  riftCore: number;
  riftIntensity: number;
  floor: string;
  grid: string;
  wall: number;
  wallGlow: number;
  wallGlowAmt: number;
  rock: number;
  rockGlow: number;
  rockGlowAmt: number;
  stars: number;
  starOpacity: number;
};

export const MAPS: readonly ArenaTheme[] = [
  {
    id: "night",
    name: "Night",
    blurb: "Black glass and a cyan rift.",
    sky: 0x07090d,
    fog: 0x07090d,
    fogDensity: 0.022,
    hemiSky: 0xc8e6dc,
    hemiGround: 0x07090d,
    hemi: 0.55,
    sun: 0xf4f0e4,
    sunIntensity: 1.35,
    sunPos: [6, 14, 8],
    disc: false,
    discColor: 0xf4f0e4,
    rift: 0x2ee6c7,
    riftCore: 0xd7fff6,
    riftIntensity: 8,
    floor: "#0c110e",
    grid: "#1a2c24",
    wall: 0x121814,
    wallGlow: 0x14584c,
    wallGlowAmt: 0.55,
    rock: 0x24302a,
    rockGlow: 0x102820,
    rockGlowAmt: 0.4,
    stars: 0xd5e6dc,
    starOpacity: 0.8,
  },
  {
    id: "day1",
    name: "Day 1",
    blurb: "First light. Same corridor, open sky.",
    sky: 0x8ebcde,
    fog: 0xc5dced,
    fogDensity: 0.011,
    hemiSky: 0xfff6df,
    hemiGround: 0xb08958,
    hemi: 1.25,
    sun: 0xffe0a0,
    sunIntensity: 2.35,
    sunPos: [10, 24, 6],
    disc: true,
    discColor: 0xfff1c4,
    rift: 0xf0b429,
    riftCore: 0xfff4d2,
    riftIntensity: 6,
    floor: "#d5c7aa",
    grid: "#7d705c",
    wall: 0xe4d7c2,
    wallGlow: 0xc47a32,
    wallGlowAmt: 0.18,
    rock: 0x8f7354,
    rockGlow: 0x5a3a1c,
    rockGlowAmt: 0.22,
    stars: 0xffffff,
    starOpacity: 0,
  },
  {
    id: "dusk",
    name: "Dusk",
    blurb: "Violet glass and a low sun.",
    sky: 0x160a22,
    fog: 0x2a1438,
    fogDensity: 0.02,
    hemiSky: 0xe7b0ff,
    hemiGround: 0x2a1020,
    hemi: 0.7,
    sun: 0xff7a3c,
    sunIntensity: 1.7,
    sunPos: [-12, 6, 10],
    disc: true,
    discColor: 0xff8a4a,
    rift: 0xe46bff,
    riftCore: 0xffd6ff,
    riftIntensity: 9,
    floor: "#140e1c",
    grid: "#5a3470",
    wall: 0x1c1228,
    wallGlow: 0xa04ad4,
    wallGlowAmt: 0.55,
    rock: 0x3a2a4a,
    rockGlow: 0x6a3090,
    rockGlowAmt: 0.45,
    stars: 0xf0d8ff,
    starOpacity: 0.9,
  },
  {
    id: "snow",
    name: "Christmas",
    blurb: "Snow on the lane. Don't slow down.",
    sky: 0x9eb4c9,
    fog: 0xd5e4ef,
    fogDensity: 0.016,
    hemiSky: 0xf4fbff,
    hemiGround: 0x8aa0b0,
    hemi: 1.15,
    sun: 0xfff4e0,
    sunIntensity: 1.9,
    sunPos: [4, 18, -8],
    disc: true,
    discColor: 0xfff7ea,
    rift: 0xe23b3b,
    riftCore: 0xffe08a,
    riftIntensity: 7,
    floor: "#e7eef2",
    grid: "#8aa0ad",
    wall: 0xd5e0e8,
    wallGlow: 0xc23b3b,
    wallGlowAmt: 0.22,
    rock: 0xf4f7f8,
    rockGlow: 0xb7d4c4,
    rockGlowAmt: 0.35,
    stars: 0xffffff,
    starOpacity: 0.15,
  },
  {
    id: "haunt",
    name: "Halloween",
    blurb: "Ghosts in the fog. It's not easy.",
    sky: 0x100818,
    fog: 0x241028,
    fogDensity: 0.028,
    hemiSky: 0xffb15a,
    hemiGround: 0x140810,
    hemi: 0.62,
    sun: 0xff7a1a,
    sunIntensity: 1.15,
    sunPos: [-8, 10, 12],
    disc: true,
    discColor: 0xffc56a,
    rift: 0xff6a00,
    riftCore: 0xffe2a8,
    riftIntensity: 10,
    floor: "#120c14",
    grid: "#5a2418",
    wall: 0x1a1018,
    wallGlow: 0xff5a12,
    wallGlowAmt: 0.62,
    rock: 0xe07020,
    rockGlow: 0xffb000,
    rockGlowAmt: 0.55,
    stars: 0xffd0a0,
    starOpacity: 0.55,
  },
  {
    id: "rain",
    name: "Water",
    blurb: "Rain on the water. Stay in the lane.",
    sky: 0x071820,
    fog: 0x0c3040,
    fogDensity: 0.02,
    hemiSky: 0xb7d4e4,
    hemiGround: 0x062028,
    hemi: 0.7,
    sun: 0xd0e8f4,
    sunIntensity: 0.85,
    sunPos: [2, 18, 6],
    disc: false,
    discColor: 0xd0e8f4,
    rift: 0x3ec8e0,
    riftCore: 0xd8fbff,
    riftIntensity: 7,
    floor: "#073848",
    grid: "#1a8aaa",
    wall: 0x0c2834,
    wallGlow: 0x147898,
    wallGlowAmt: 0.5,
    rock: 0x1a4a58,
    rockGlow: 0x0a3040,
    rockGlowAmt: 0.45,
    stars: 0xc5e8f4,
    starOpacity: 0.12,
  },
];

export function mapById(id: string | null | undefined): ArenaTheme {
  return MAPS.find((m) => m.id === id) ?? MAPS[0];
}
