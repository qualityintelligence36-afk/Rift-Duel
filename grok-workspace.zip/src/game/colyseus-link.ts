import { Client, MatchMakeError, type Room, getStateCallbacks } from "colyseus.js";

export type NetPeer = {
  id: string;
  name: string;
  connectionState: "new" | "connecting" | "connected" | "disconnected" | "failed";
  rttMs: number | null;
  candidateType: null;
};

type StatusKind = "connecting" | "open" | "reconnecting" | "error";

export interface ColyseusLinkOptions {
  code: string;
  name: string;
  map: string;
  hosting: boolean;
  onReady?: (sessionId: string) => void;
  onPeers?: (peers: NetPeer[]) => void;
  onMessage?: (from: string, data: unknown) => void;
  onStatus?: (kind: StatusKind, detail?: string) => void;
}

type RosterRow = { id: string; name: string };

/** Same origin in the preview (proxied to the Colyseus process). Override with VITE_GAME_SERVER. */
export function gameServerEndpoint(): string {
  const configured = import.meta.env.VITE_GAME_SERVER as string | undefined;
  if (configured && configured.trim()) return configured.trim().replace(/\/$/, "");
  if (typeof window === "undefined") return "http://127.0.0.1:2567";
  return window.location.origin;
}

function explain(err: unknown): string {
  const message = err instanceof Error ? err.message : String(err);
  const code = err instanceof MatchMakeError ? err.code : 0;
  if (code === 4211 || code === 4212 || /no rooms|not found/i.test(message)) {
    return "No room with that code. Your friend taps Create room first.";
  }
  if (/already in use/i.test(message)) return "That code is already in use. Create another.";
  if (/4 letters/i.test(message)) return "Code needs 4 letters.";
  if (/full|maxClients|locked/i.test(message)) return "That room is full.";
  if (/failed to fetch|network|econnrefused|offline|reset|timed out/i.test(message)) {
    return "Can't reach the game server. Leave this open — it keeps trying.";
  }
  return message || "The room didn't open.";
}

function shouldRetry(err: unknown): boolean {
  const message = err instanceof Error ? err.message : String(err);
  const code = err instanceof MatchMakeError ? err.code : 0;
  if (code === 4211 || code === 4212) return false;
  if (/already in use|4 letters|full|maxClients|locked|no rooms|not found/i.test(message)) return false;
  return true;
}

export class ColyseusLink {
  private client: Client | null = null;
  private room: Room | null = null;
  private closed = false;
  private pingTimer = 0;
  private pingSent = 0;
  private rtt: number | null = null;
  private roster: RosterRow[] = [];
  private token = "";

  constructor(private readonly opts: ColyseusLinkOptions) {}

  async start(): Promise<void> {
    this.opts.onStatus?.("connecting");
    const endpoint = gameServerEndpoint();
    this.client = new Client(endpoint);
    let last = "Can't reach the game server.";
    while (!this.closed) {
      try {
        const options = {
          code: this.opts.code,
          name: this.opts.name,
          map: this.opts.map,
        };
        this.room = this.opts.hosting
          ? await this.client.create("rift", options)
          : await this.client.join("rift", options);
        if (this.closed) {
          void this.room.leave(true);
          return;
        }
        this.bind(this.room);
        return;
      } catch (err) {
        last = explain(err);
        if (!shouldRetry(err)) break;
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
    }
    if (!this.closed) this.opts.onStatus?.("error", last);
  }

  send(data: unknown): void {
    this.dispatch(data);
  }

  relay(_data: unknown): void {}

  pushState(data: unknown): void {
    this.dispatch(data);
  }

  broadcast(_data: unknown): void {}

  close(): void {
    this.closed = true;
    if (this.pingTimer) window.clearInterval(this.pingTimer);
    this.pingTimer = 0;
    const room = this.room;
    this.room = null;
    if (room) void room.leave(true);
  }

  private dispatch(data: unknown): void {
    const room = this.room;
    if (!room || data == null || typeof data !== "object") return;
    const kind = (data as { k?: string }).k;
    if (kind === "st") room.send("st", data);
    else room.send("ev", data);
  }

  private bind(room: Room): void {
    this.token = room.reconnectionToken;
    this.opts.onReady?.(room.sessionId);
    this.opts.onStatus?.("open");
    room.onMessage("roster", (rows: RosterRow[]) => {
      this.roster = Array.isArray(rows) ? rows : [];
      this.emitPeers("connected");
    });
    room.onMessage("ev", (payload: unknown) => {
      const from = this.otherId();
      if (from) this.opts.onMessage?.(from, payload);
    });
    room.onMessage("st", (payload: unknown) => {
      const from = this.otherId();
      if (from) this.opts.onMessage?.(from, payload);
    });
    room.onMessage("pong", (sent: unknown) => {
      const t = Number(sent);
      if (Number.isFinite(t)) this.rtt = Math.max(0, Date.now() - t);
      this.emitPeers("connected");
    });
    try {
      const $ = getStateCallbacks(room);
      $(room.state).pilots.onAdd((_pilot: { name?: string }, id: string) => {
        if (!this.roster.some((row) => row.id === id)) {
          this.roster = [...this.roster, { id, name: _pilot?.name || "" }];
          this.emitPeers("connected");
        }
      });
    } catch {
      /* roster messages still carry the other pilot */
    }
    this.pingTimer = window.setInterval(() => {
      if (!this.room) return;
      this.pingSent = Date.now();
      this.room.send("ping", this.pingSent);
    }, 2000);
    room.send("hello");
    room.onLeave((code) => {
      if (this.closed) return;
      if (this.pingTimer) window.clearInterval(this.pingTimer);
      this.pingTimer = 0;
      if (code === 4000) return;
      void this.restore();
    });
    room.onError((code, message) => {
      if (!this.closed) this.opts.onStatus?.("error", message || `Connection error ${code}`);
    });
  }

  private async restore(): Promise<void> {
    if (this.closed || !this.client || !this.token) return;
    this.opts.onStatus?.("reconnecting", "Reconnecting…");
    this.emitPeers("connecting");
    try {
      const room = await this.client.reconnect(this.token);
      if (this.closed) {
        void room.leave(true);
        return;
      }
      this.room = room;
      this.bind(room);
    } catch {
      if (this.closed) return;
      this.room = null;
      this.opts.onStatus?.("error", "The link dropped. Head back and create the room again.");
      this.emitPeers("failed");
    }
  }

  private otherId(): string | null {
    const self = this.room?.sessionId;
    return this.roster.find((row) => row.id !== self)?.id ?? null;
  }

  private emitPeers(state: NetPeer["connectionState"]): void {
    const peers = this.roster.map((row) => ({
      id: row.id,
      name: row.name,
      connectionState: state,
      rttMs: row.id === this.room?.sessionId ? null : this.rtt,
      candidateType: null as null,
    }));
    this.opts.onPeers?.(peers);
  }
}
