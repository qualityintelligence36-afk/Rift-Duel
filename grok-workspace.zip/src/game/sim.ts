import {
  BOLT_DAMAGE,
  BOLT_LIFE,
  BOLT_R,
  BOLT_SPEED,
  DRAG,
  FIRE_CD,
  FRAGS_TO_WIN,
  MAX_SPEED,
  NOSE_MAX,
  RAPID_CD,
  ROCK_DAMAGE,
  ROCK_HITS,
  ROCK_RESPAWN,
  SHIELD_CD,
  SHIELD_TIME,
  SHIP_R,
  STRAFE_ACCEL,
  THRUST_ACCEL,
  aimDir,
  asteroids,
  clamp,
  clampShip,
  laneForward,
  laneRight,
  nowSec,
  spawnFor,
  type Side,
} from "./math";

export type Owner = "you" | "them";
export type PowerKind = 0 | 1 | 2;

export type Ship = {
  side: Side;
  x: number;
  z: number;
  vx: number;
  vz: number;
  nose: number;
  hp: number;
  alive: boolean;
  invuln: number;
  respawn: number;
  shield: number;
  rapid: number;
  spread: number;
  boostCd: number;
  fireCd: number;
  flash: number;
  hurtCd: number;
};

export type Bolt = {
  id: number;
  owner: Owner;
  x: number;
  z: number;
  dx: number;
  dz: number;
  life: number;
};

export type Power = { id: number; kind: PowerKind; x: number; z: number };

export type RockState = { hp: number; max: number; down: number; pop: number };

export type Actions = {
  strafe: number;
  thrust: number;
  fire: boolean;
  boost: boolean;
};

export type Fx = "shot" | "hit" | "boom" | "dash" | "pick" | "shield" | "clang" | "chip" | "reform";

export type Impact = { owner: Owner; x: number; z: number; kind: "hit" | "clang" };

export type RockHit = { kind: "chip" | "blast"; x: number; z: number };

export type SimEvent =
  | { t: "shot"; id: number; x: number; z: number; dx: number; dz: number }
  | { t: "hit"; id: number }
  | { t: "down" }
  | { t: "take"; id: number }
  | { t: "power"; power: Power }
  | { t: "chip"; i: number; x: number; z: number }
  | { t: "blast"; i: number; x: number; z: number }
  | { t: "reform"; i: number; x: number; z: number };

export const IDLE_ACTIONS: Actions = { strafe: 0, thrust: 0, fire: false, boost: false };

function makeShip(side: Side): Ship {
  const p = spawnFor(side);
  return {
    side,
    x: p.x,
    z: p.z,
    vx: 0,
    vz: 0,
    nose: 0,
    hp: 100,
    alive: true,
    invuln: 0,
    respawn: 0,
    shield: 0,
    rapid: 0,
    spread: 0,
    boostCd: 0,
    fireCd: 0,
    flash: 0,
    hurtCd: 0,
  };
}

function freshRocks(): RockState[] {
  return asteroids(0).map(() => ({ hp: ROCK_HITS, max: ROCK_HITS, down: 0, pop: 0 }));
}

export class Sim {
  you: Ship = makeShip(1);
  them: Ship = makeShip(-1);
  bolts: Bolt[] = [];
  power: Power | null = null;
  rocks: RockState[] = freshRocks();
  frags = 0;
  deaths = 0;
  over: "you" | "them" | null = null;
  time = 0;
  nextBolt = 1;
  nextPowerId = 1;
  nextPowerAt = 7;
  fx: Fx[] = [];
  impacts: Impact[] = [];
  events: SimEvent[] = [];
  authority = true;
  net = false;

  diorama(): void {
    this.you = makeShip(1);
    this.them = makeShip(-1);
    this.bolts = [];
    this.power = null;
    this.rocks = freshRocks();
    this.frags = 0;
    this.deaths = 0;
    this.over = null;
    this.time = 0;
    this.nextPowerAt = 7;
    this.net = false;
    this.authority = true;
    this.fx = [];
    this.impacts = [];
    this.events = [];
  }

  prepare(side: Side, net: boolean, authority: boolean): void {
    this.diorama();
    this.you = makeShip(side);
    this.them = makeShip(side === 1 ? -1 : 1);
    this.you.invuln = 1.15;
    this.them.invuln = 1.15;
    this.net = net;
    this.authority = authority;
  }

  step(dt: number, actions: Actions): void {
    this.fx = [];
    this.impacts = [];
    this.events = [];
    if (this.over) return;
    this.time += dt;
    const themActions = this.net ? IDLE_ACTIONS : this.warden();
    this.integrate(this.you, actions, dt);
    if (!this.net) this.integrate(this.them, themActions, dt);
    this.tick(this.you, dt);
    this.tick(this.them, dt);
    this.shoot(this.you, actions, true, dt);
    if (!this.net) this.shoot(this.them, themActions, false, dt);
    this.advanceBolts(dt);
    this.collide();
    this.bumpRocks();
    this.bumpShips();
    this.powerups();
    this.tickRocks(dt);
    this.respawn(this.you, dt);
    if (!this.net) this.respawn(this.them, dt);
  }

  applyRemote(s: {
    x: number;
    z: number;
    vx: number;
    vz: number;
    nose: number;
    hp: number;
    alive: boolean;
    frags: number;
    deaths: number;
    shield: number;
    rapid: number;
    spread: number;
  }): void {
    this.them.x = s.x;
    this.them.z = s.z;
    this.them.vx = s.vx;
    this.them.vz = s.vz;
    this.them.nose = s.nose;
    this.them.hp = s.hp;
    this.them.shield = s.shield;
    this.them.rapid = s.rapid;
    this.them.spread = s.spread;
    const wasAlive = this.them.alive;
    this.them.alive = s.alive;
    if (wasAlive && !s.alive) this.them.respawn = 2.2;
    this.deaths = Math.max(this.deaths, s.frags);
    this.frags = Math.max(this.frags, s.deaths);
    this.checkWin();
  }

  ingestShot(id: number, x: number, z: number, dx: number, dz: number): boolean {
    if (this.bolts.some((b) => b.owner === "them" && b.id === id)) return false;
    this.bolts.push({ id, owner: "them", x, z, dx, dz, life: BOLT_LIFE });
    return true;
  }

  resolveHit(id: number): boolean {
    const i = this.bolts.findIndex((b) => b.owner === "you" && b.id === id);
    if (i < 0) return false;
    this.bolts.splice(i, 1);
    return true;
  }

  remoteDown(): boolean {
    if (!this.them.alive) return false;
    this.them.alive = false;
    this.them.hp = 0;
    this.them.respawn = 2.2;
    this.frags += 1;
    this.checkWin();
    return true;
  }

  offerPower(power: Power): void {
    this.power = power;
    this.nextPowerId = Math.max(this.nextPowerId, power.id + 1);
  }

  remoteTake(id: number): void {
    if (this.power && this.power.id === id) {
      this.power = null;
      this.nextPowerAt = this.time + 10;
    }
  }

  /** One missile hit on a center rock. Returns null if it was already rubble. */
  strike(i: number): RockHit | null {
    const rock = this.rocks[i];
    if (!rock || rock.down > 0 || rock.hp <= 0) return null;
    const spot = asteroids(nowSec())[i];
    if (!spot) return null;
    rock.hp -= 1;
    if (rock.hp > 0) return { kind: "chip", x: spot.x, z: spot.z };
    rock.hp = 0;
    rock.down = ROCK_RESPAWN;
    return { kind: "blast", x: spot.x, z: spot.z };
  }

  private warden(): Actions {
    const ai = this.them;
    const player = this.you;
    if (!ai.alive) return IDLE_ACTIONS;
    let dodge = 0;
    let incoming = false;
    let soonest = 99;
    for (const b of this.bolts) {
      if (b.owner !== "you") continue;
      const vz = b.dz * BOLT_SPEED;
      if (Math.abs(vz) < 0.01) continue;
      const t = (ai.z - b.z) / vz;
      if (t > 0 && t < 0.92 && t < soonest) {
        const ix = b.x + b.dx * BOLT_SPEED * t;
        if (Math.abs(ix - ai.x) < 2.15) {
          incoming = true;
          soonest = t;
          const world = ai.x >= ix ? 1 : -1;
          dodge = world * laneRight(ai.side).x;
        }
      }
    }
    const right = laneRight(ai.side).x;
    const lead = player.x + player.vx * 0.24;
    let strafe = clamp((lead - ai.x) * right * 1.9, -1, 1);
    if (dodge) strafe = clamp(dodge * 1, -1, 1);
    const home = ai.side === 1 ? 8.6 : -8.6;
    const thrust = clamp((home - ai.z) * laneForward(ai.side).z * 0.7, -1, 1);
    const aligned = player.alive && Math.abs(lead - ai.x) < 1.05;
    const burst = this.time > 0.4 && Math.sin(this.time * 7.2) > -0.42;
    const boost = incoming && ai.shield <= 0 && ai.boostCd <= 0;
    return { strafe, thrust, fire: aligned && burst && !dodge, boost };
  }

  private integrate(ship: Ship, a: Actions, dt: number): void {
    if (!ship.alive) return;
    const f = laneForward(ship.side);
    const r = laneRight(ship.side);
    const ax = r.x * a.strafe * STRAFE_ACCEL + f.x * a.thrust * THRUST_ACCEL;
    const az = r.z * a.strafe * STRAFE_ACCEL + f.z * a.thrust * THRUST_ACCEL;
    ship.vx += ax * dt;
    ship.vz += az * dt;
    const damp = Math.exp(-DRAG * dt);
    ship.vx *= damp;
    ship.vz *= damp;
    const sp = Math.hypot(ship.vx, ship.vz);
    if (sp > MAX_SPEED) {
      const s = MAX_SPEED / sp;
      ship.vx *= s;
      ship.vz *= s;
    }
    ship.x += ship.vx * dt;
    ship.z += ship.vz * dt;
    const c = clampShip(ship.side, ship.x, ship.z);
    if (c.x !== ship.x) ship.vx *= -0.2;
    if (c.z !== ship.z) ship.vz *= -0.2;
    ship.x = c.x;
    ship.z = c.z;
    const targetNose = clamp(-a.strafe, -1, 1) * NOSE_MAX;
    ship.nose += (targetNose - ship.nose) * (1 - Math.exp(-12 * dt));
    if (a.boost && ship.shield <= 0 && ship.boostCd <= 0) {
      ship.shield = SHIELD_TIME;
      ship.boostCd = SHIELD_CD;
      this.fx.push("shield");
    }
  }

  private tick(ship: Ship, dt: number): void {
    ship.invuln = Math.max(0, ship.invuln - dt);
    ship.shield = Math.max(0, ship.shield - dt);
    ship.rapid = Math.max(0, ship.rapid - dt);
    ship.spread = Math.max(0, ship.spread - dt);
    ship.boostCd = Math.max(0, ship.boostCd - dt);
    ship.flash = Math.max(0, ship.flash - dt);
    ship.hurtCd = Math.max(0, ship.hurtCd - dt);
  }

  private shoot(ship: Ship, a: Actions, local: boolean, dt: number): void {
    ship.fireCd = Math.max(0, ship.fireCd - dt);
    if (!ship.alive || !a.fire) return;
    const cd = ship.rapid > 0 ? RAPID_CD : FIRE_CD;
    if (ship.fireCd > 0) return;
    ship.fireCd = cd;
    const angles = ship.spread > 0 ? [ship.nose - 0.22, ship.nose, ship.nose + 0.22] : [ship.nose];
    for (const n of angles) {
      const d = aimDir(ship.side, n);
      const id = this.nextBolt++;
      const x = ship.x + d.x * 1.2;
      const z = ship.z + d.z * 1.2;
      this.bolts.push({
        id,
        owner: local ? "you" : "them",
        x,
        z,
        dx: d.x,
        dz: d.z,
        life: BOLT_LIFE,
      });
      if (local) this.events.push({ t: "shot", id, x, z, dx: d.x, dz: d.z });
    }
    if (local) this.fx.push("shot");
  }

  private advanceBolts(dt: number): void {
    for (let i = this.bolts.length - 1; i >= 0; i -= 1) {
      const b = this.bolts[i];
      b.x += b.dx * BOLT_SPEED * dt;
      b.z += b.dz * BOLT_SPEED * dt;
      b.life -= dt;
      if (b.life <= 0 || Math.abs(b.x) > 18 || Math.abs(b.z) > 22) this.bolts.splice(i, 1);
    }
  }

  private collide(): void {
    const rocks = asteroids(nowSec());
    for (let i = this.bolts.length - 1; i >= 0; i -= 1) {
      const b = this.bolts[i];
      let dead = false;
      for (let ri = 0; ri < rocks.length; ri += 1) {
        const rock = rocks[ri];
        const state = this.rocks[ri];
        if (state && state.down > 0) continue;
        const dx = b.x - rock.x;
        const dz = b.z - rock.z;
        const reach = rock.r + BOLT_R;
        if (dx * dx + dz * dz < reach * reach) {
          dead = true;
          if (!this.net || b.owner === "you") {
            const hit = this.strike(ri);
            if (hit?.kind === "chip") this.fx.push("chip");
            if (hit) this.events.push({ t: hit.kind, i: ri, x: hit.x, z: hit.z });
          }
          break;
        }
      }
      if (!dead) {
        const target = b.owner === "you" ? this.them : this.you;
        const dx = b.x - target.x;
        const dz = b.z - target.z;
        const reach = SHIP_R + BOLT_R;
        const hit = target.alive && target.invuln <= 0 && dx * dx + dz * dz < reach * reach;
        if (hit) {
          dead = true;
          if (!(this.net && target === this.them)) this.hurt(target, BOLT_DAMAGE, b.id);
        }
      }
      if (dead) this.bolts.splice(i, 1);
    }
  }

  private hurt(ship: Ship, dmg: number, boltId: number | null): void {
    if (!ship.alive || ship.invuln > 0) return;
    const owner: Owner = ship === this.you ? "you" : "them";
    if (ship.shield > 0) {
      ship.flash = 0.18;
      this.impacts.push({ owner, x: ship.x, z: ship.z, kind: "clang" });
      if (boltId !== null && ship === this.you) this.events.push({ t: "hit", id: boltId });
      return;
    }
    ship.hp -= dmg;
    ship.flash = 0.28;
    if (ship.hp <= 0) {
      ship.hp = 0;
      ship.alive = false;
      ship.respawn = 2.2;
      ship.vx = 0;
      ship.vz = 0;
      this.fx.push("boom");
      if (ship === this.you) {
        this.deaths += 1;
        this.events.push({ t: "down" });
        if (boltId !== null) this.events.push({ t: "hit", id: boltId });
      } else {
        this.frags += 1;
      }
      this.checkWin();
    } else {
      this.impacts.push({ owner, x: ship.x, z: ship.z, kind: "hit" });
      if (boltId !== null && ship === this.you) this.events.push({ t: "hit", id: boltId });
    }
  }

  private bumpRocks(): void {
    const rocks = asteroids(nowSec());
    const ships = this.net ? [this.you] : [this.you, this.them];
    for (const ship of ships) {
      if (!ship.alive) continue;
      for (let ri = 0; ri < rocks.length; ri += 1) {
        const rock = rocks[ri];
        const state = this.rocks[ri];
        if (state && state.down > 0) continue;
        const dx = ship.x - rock.x;
        const dz = ship.z - rock.z;
        const min = rock.r + SHIP_R;
        const d2 = dx * dx + dz * dz;
        if (d2 >= min * min || d2 < 1e-8) continue;
        const d = Math.sqrt(d2);
        ship.x = rock.x + (dx / d) * (min + 0.04);
        ship.z = rock.z + (dz / d) * (min + 0.04);
        const c = clampShip(ship.side, ship.x, ship.z);
        ship.x = c.x;
        ship.z = c.z;
        ship.vx *= 0.35;
        ship.vz *= 0.35;
        if (ship.hurtCd <= 0) {
          ship.hurtCd = 0.7;
          this.hurt(ship, ROCK_DAMAGE, null);
        }
      }
    }
  }

  private bumpShips(): void {
    if (!this.you.alive || !this.them.alive) return;
    const dx = this.you.x - this.them.x;
    const dz = this.you.z - this.them.z;
    const min = SHIP_R * 2;
    const d2 = dx * dx + dz * dz;
    if (d2 >= min * min || d2 < 1e-8) return;
    const d = Math.sqrt(d2);
    const push = (min - d) / 2 + 0.02;
    const nx = dx / d;
    const nz = dz / d;
    this.you.x += nx * (this.net ? push * 2 : push);
    this.you.z += nz * (this.net ? push * 2 : push);
    if (!this.net) {
      this.them.x -= nx * push;
      this.them.z -= nz * push;
      const ct = clampShip(this.them.side, this.them.x, this.them.z);
      this.them.x = ct.x;
      this.them.z = ct.z;
    }
    const cy = clampShip(this.you.side, this.you.x, this.you.z);
    this.you.x = cy.x;
    this.you.z = cy.z;
  }

  private powerups(): void {
    if (!this.over && !this.power && this.time >= this.nextPowerAt && (this.authority || !this.net)) {
      const kind = (this.nextPowerId % 3) as PowerKind;
      const power = {
        id: this.nextPowerId,
        kind,
        x: 0,
        z: 0,
      };
      this.nextPowerId += 1;
      this.power = power;
      this.nextPowerAt = this.time + 12;
      if (this.net) this.events.push({ t: "power", power });
    }
    if (!this.power) return;
    const reach = (SHIP_R + 0.95) ** 2;
    const youD = (this.you.x - this.power.x) ** 2 + (this.you.z - this.power.z) ** 2;
    const themD = (this.them.x - this.power.x) ** 2 + (this.them.z - this.power.z) ** 2;
    const youHit = this.you.alive && youD < reach;
    const themHit = !this.net && this.them.alive && themD < reach;
    if (!youHit && !themHit) return;
    const youWins = youHit && (!themHit || youD <= themD);
    const power = this.power;
    this.power = null;
    this.nextPowerAt = this.time + 10;
    if (youWins) {
      this.grant(this.you, power.kind);
      this.fx.push("pick");
      this.events.push({ t: "take", id: power.id });
    } else {
      this.grant(this.them, power.kind);
    }
  }

  private grant(ship: Ship, kind: PowerKind): void {
    if (kind === 0) ship.rapid = 7.5;
    else if (kind === 1) ship.spread = 7.5;
    else ship.shield = Math.max(ship.shield, 8);
  }

  private tickRocks(dt: number): void {
    const spots = asteroids(nowSec());
    for (let i = 0; i < this.rocks.length; i += 1) {
      const rock = this.rocks[i];
      if (rock.pop > 0) rock.pop = Math.max(0, rock.pop - dt);
      if (rock.down <= 0) continue;
      rock.down = Math.max(0, rock.down - dt);
      if (rock.down > 0) continue;
      rock.hp = rock.max;
      rock.pop = 0.45;
      this.fx.push("reform");
      const spot = spots[i];
      if (spot) this.events.push({ t: "reform", i, x: spot.x, z: spot.z });
    }
  }

  private respawn(ship: Ship, dt: number): void {
    if (ship.alive || this.over) return;
    ship.respawn -= dt;
    if (ship.respawn > 0) return;
    const p = spawnFor(ship.side);
    ship.x = p.x;
    ship.z = p.z;
    ship.vx = 0;
    ship.vz = 0;
    ship.nose = 0;
    ship.hp = 100;
    ship.alive = true;
    ship.invuln = 1.35;
    ship.shield = 0;
    ship.boostCd = 0;
    ship.rapid = 0;
    ship.spread = 0;
  }

  private checkWin(): void {
    if (this.over) return;
    if (this.frags >= FRAGS_TO_WIN) this.over = "you";
    else if (this.deaths >= FRAGS_TO_WIN) this.over = "them";
  }
}
