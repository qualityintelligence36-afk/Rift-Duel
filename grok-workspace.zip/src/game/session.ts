import { ColyseusLink, type NetPeer } from "./colyseus-link";
import { playFx, resumeAudio, setBed, setMuted } from "./audio";
import { FRAGS_TO_WIN, SHIELD_CD } from "./math";
import { mapById, type MapId } from "./maps";
import { Sim, type Actions, type PowerKind } from "./sim";
import { RiftView } from "./view";

export type Phase = "title" | "waiting" | "play" | "over";
export type LinkState = "off" | "waiting" | "live" | "lost";

export type Hud = {
  phase: Phase;
  room: string;
  youName: string;
  themName: string;
  youHp: number;
  themHp: number;
  youFrags: number;
  themFrags: number;
  fragsToWin: number;
  shield: boolean;
  rapid: boolean;
  spread: boolean;
  shieldCd: number;
  banner: string;
  status: string;
  winner: "you" | "them" | null;
  rtt: number | null;
  link: LinkState;
  muted: boolean;
  wardenWins: number;
  countdown: number;
  net: boolean;
  map: MapId;
};

export const INITIAL_HUD: Hud = {
  phase: "title",
  room: "",
  youName: "YOU",
  themName: "Your Problem",
  youHp: 100,
  themHp: 100,
  youFrags: 0,
  themFrags: 0,
  fragsToWin: FRAGS_TO_WIN,
  shield: false,
  rapid: false,
  spread: false,
  shieldCd: 0,
  banner: "",
  status: "",
  winner: null,
  rtt: null,
  link: "off",
  muted: false,
  wardenWins: 0,
  countdown: 0,
  net: false,
  map: "night",
};

type Wire = (
  | {
      k: "st";
      seq: number;
      x: number;
      z: number;
      vx: number;
      vz: number;
      n: number;
      hp: number;
      a: number;
      fr: number;
      de: number;
      sh: number;
      rp: number;
      sp: number;
      ep?: number;
    }
  | { k: "sh"; id: number; x: number; z: number; dx: number; dz: number }
  | { k: "hit"; id: number }
  | { k: "dn" }
  | { k: "pw"; id: number; kind: PowerKind; x: number }
  | { k: "tk"; id: number }
  | { k: "go"; at: number; m?: string }
  | { k: "mp"; m: string }
  | { k: "re" }
  | { k: "rk"; i: number }
) & { e?: string };

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
    };
  }
}

const STEP = 1 / 60;
const AMBER = 0xf26b1d;
const CYAN = 0x2ee6c7;

function cleanName(raw: string): string {
  const s = raw.replace(/[^a-zA-Z0-9 ]/g, "").trim().slice(0, 12);
  return s.length > 0 ? s : "YOU";
}

function loadPeerId(): string {
  const key = "rift-duel-peer";
  try {
    const existing = sessionStorage.getItem(key);
    if (existing && /^[a-zA-Z0-9_-]{1,64}$/.test(existing)) return existing;
    const id = `p${crypto.randomUUID().replace(/-/g, "").slice(0, 16)}`;
    sessionStorage.setItem(key, id);
    return id;
  } catch {
    return `p${Math.random().toString(36).slice(2, 12)}`;
  }
}

function loadWins(): number {
  try {
    return Number(localStorage.getItem("rift-duel-wins") ?? "0") || 0;
  } catch {
    return 0;
  }
}

function loadMap(): MapId {
  try {
    return mapById(localStorage.getItem("rift-duel-map")).id;
  } catch {
    return "night";
  }
}

function loadMute(): boolean {
  try {
    return localStorage.getItem("rift-duel-mute") === "1";
  } catch {
    return false;
  }
}

export class RiftSession {
  private readonly sim = new Sim();
  private readonly view: RiftView;
  private readonly keys = new Set<string>();
  private qa: Set<string> | null = null;
  private stick = { x: 0, y: 0, on: false };
  private fireHeld = false;
  private boostHeld = false;
  private shieldQueued = false;
  private pointerFire = false;
  private phase: Phase = "title";
  private link: LinkState = "off";
  private roomCode = "";
  private youName = "YOU";
  private themName = "Your Problem";
  private net = false;
  private muted = loadMute();
  private mapId = loadMap();
  private wardenWins = loadWins();
  private winsStored = false;
  private banner = "";
  private bannerUntil = 0;
  private status = "";
  private countdown = 0;
  private goAt = 0;
  private goSentAt = 0;
  private mapSentAt = 0;
  private readyAt = 0;
  private sideReady = false;
  private hosting = false;
  private signalingOk = true;
  private selfId = "local";
  private peerId: string | null = null;
  private room: ColyseusLink | null = null;
  private rtt: number | null = null;
  private seq = 0;
  private epoch = 0;
  private eid = 0;
  private seenE = new Set<string>();
  private themSeq = 0;
  private themEpoch = 0;
  private remoteAt = 0;
  private netAcc = 0;
  private acc = 0;
  private last = 0;
  private lastHud = 0;
  private hudKey = "";
  private raf = 0;
  private dead = false;
  private readonly resizeObserver: ResizeObserver;
  private readonly onKeyDown: (e: KeyboardEvent) => void;
  private readonly onKeyUp: (e: KeyboardEvent) => void;
  private readonly onBlur: () => void;
  private readonly onVis: () => void;
  private readonly onPointerDown: (e: PointerEvent) => void;
  private readonly onPointerUp: () => void;

  constructor(
    canvas: HTMLCanvasElement,
    private readonly onHud: (hud: Hud) => void,
  ) {
    this.view = new RiftView(canvas);
    this.view.setMap(this.mapId);
    setMuted(this.muted);
    this.resizeObserver = new ResizeObserver(() => this.view.resize());
    this.resizeObserver.observe(canvas);
    this.onKeyDown = (e) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (this.qa) return;
      this.keys.add(e.code);
      if (this.phase === "play" && ["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) {
        e.preventDefault();
      }
    };
    this.onKeyUp = (e) => {
      this.keys.delete(e.code);
    };
    this.onBlur = () => this.keys.clear();
    this.onVis = () => {
      if (document.visibilityState === "visible") resumeAudio();
      else this.keys.clear();
    };
    this.onPointerDown = () => {
      if (this.phase === "play") this.pointerFire = true;
    };
    this.onPointerUp = () => {
      this.pointerFire = false;
    };
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onVis);
    canvas.addEventListener("pointerdown", this.onPointerDown);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("pagehide", () => this.closeRoom());
    if (import.meta.env.DEV) {
      const stub = (window.__controlsTest ?? {
        keys: [] as string[],
        touched: false,
        getYaw: () => 0,
        getSpeed: () => 0,
        setKeys: (codes: string[]) => {
          stub.keys = codes;
          stub.touched = true;
        },
      }) as {
        keys?: string[];
        touched?: boolean;
        getYaw: () => number;
        getSpeed: () => number;
        setKeys?: (codes: string[]) => void;
      };
      stub.getYaw = () => this.sim.you.nose;
      stub.getSpeed = () => Math.hypot(this.sim.you.vx, this.sim.you.vz);
      stub.setKeys = (codes: string[]) => {
        stub.keys = codes;
        stub.touched = true;
        this.qa = new Set(codes);
      };
      window.__controlsTest = stub;
      if (stub.touched && Array.isArray(stub.keys)) this.qa = new Set(stub.keys);
    }
    this.publish(true);
  }

  start(): void {
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  setStick(x: number, y: number, on: boolean): void {
    this.stick.x = x;
    this.stick.y = y;
    this.stick.on = on;
  }

  setFire(on: boolean): void {
    this.fireHeld = on;
  }

  setBoost(on: boolean): void {
    this.boostHeld = on;
    if (on) this.shieldQueued = true;
  }

  setMap(id: MapId): void {
    this.mapId = mapById(id).id;
    this.view.setMap(this.mapId);
    try {
      localStorage.setItem("rift-duel-map", this.mapId);
    } catch {
      /* ignore quota */
    }
    this.publish(true);
  }

  toggleMute(): void {
    this.muted = !this.muted;
    setMuted(this.muted);
    try {
      localStorage.setItem("rift-duel-mute", this.muted ? "1" : "0");
    } catch {
      /* ignore quota */
    }
    this.publish(true);
  }

  startSolo(name: string): void {
    this.closeRoom();
    this.youName = cleanName(name);
    this.themName = "Your Problem";
    this.rememberName();
    this.net = false;
    this.link = "off";
    this.peerId = null;
    this.sideReady = false;
    this.goAt = 0;
    this.countdown = 0;
    this.winsStored = false;
    this.roomCode = "";
    this.status = "Your Problem holds the far lip";
    this.banner = "";
    this.sim.prepare(1, false, true);
    this.phase = "play";
    this.rtt = null;
    this.publish(true);
  }

  host(code: string, name: string): boolean {
    return this.open(code, name, true);
  }

  join(code: string, name: string): boolean {
    return this.open(code, name, false);
  }

  leave(): void {
    this.closeRoom();
    this.phase = "title";
    this.net = false;
    this.link = "off";
    this.peerId = null;
    this.sideReady = false;
    this.goAt = 0;
    this.countdown = 0;
    this.banner = "";
    this.status = "";
    this.roomCode = "";
    this.themName = "Your Problem";
    this.sim.diorama();
    this.publish(true);
  }

  rematch(): void {
    if (this.phase !== "over" && this.phase !== "play") return;
    if (this.net && this.peerId) {
      this.netSend({ k: "re" });
      this.restartLinked();
      return;
    }
    this.startSolo(this.youName);
  }

  dispose(): void {
    this.dead = true;
    cancelAnimationFrame(this.raf);
    this.closeRoom();
    this.resizeObserver.disconnect();
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onVis);
    this.view.renderer.domElement.removeEventListener("pointerdown", this.onPointerDown);
    window.removeEventListener("pointerup", this.onPointerUp);
    this.view.dispose();
    if (window.__controlsTest) delete window.__controlsTest;
  }

  private open(code: string, name: string, hosting: boolean): boolean {
    const room = code.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 4);
    if (!/^[A-Z0-9]{4}$/.test(room)) {
      this.status = "Code needs 4 letters";
      this.publish(true);
      return false;
    }
    this.closeRoom();
    this.youName = cleanName(name);
    this.rememberName();
    this.themName = "Your Problem";
    this.roomCode = room;
    this.net = true;
    this.link = "waiting";
    this.phase = "waiting";
    this.peerId = null;
    this.sideReady = false;
    this.goAt = 0;
    this.readyAt = 0;
    this.countdown = 0;
    this.winsStored = false;
    this.banner = "";
    this.rtt = null;
    this.themSeq = 0;
    this.themEpoch = 0;
    this.seq = 0;
    this.epoch = Date.now();
    this.seenE.clear();
    this.hosting = hosting;
    this.signalingOk = true;
    this.status = "Connecting to the game server…";
    this.sim.diorama();
    this.selfId = loadPeerId();
    this.mapSentAt = 0;
    this.room = new ColyseusLink({
      code: room,
      name: this.youName,
      map: this.mapId,
      hosting,
      onReady: (sessionId) => {
        this.selfId = sessionId;
        this.status = hosting
          ? "Tell your friend this code. They tap Join room on this same game."
          : "In the room. Waiting for the other phone.";
        this.publish(true);
      },
      onPeers: (peers) => this.onPeers(peers),
      onMessage: (_from, data) => this.onNet(data),
      onStatus: (kind, detail) => {
        if (kind === "error") {
          this.signalingOk = false;
          this.link = this.peerId ? "lost" : "waiting";
          this.status = detail || "Can't reach the game server.";
          this.publish(true);
          return;
        }
        if (kind === "reconnecting") {
          this.link = "waiting";
          this.status = detail || "Reconnecting…";
          this.publish(true);
          return;
        }
        if (kind === "connecting") {
          this.status = "Connecting to the game server…";
          this.publish(true);
          return;
        }
        this.onSignaling(true);
      },
    });
    void this.room.start();
    this.publish(true);
    return true;
  }

  private restartLinked(): void {
    if (!this.peerId) return;
    const side = this.selfId < this.peerId ? 1 : -1;
    this.sim.prepare(side, true, this.selfId < this.peerId);
    this.sideReady = true;
    this.readyAt = performance.now();
    this.phase = "play";
    this.countdown = 0;
    this.goAt = 0;
    this.banner = "";
    this.winsStored = false;
    this.status = "Rematch";
    this.publish(true);
  }

  private onSignaling(ok: boolean): void {
    if (ok === this.signalingOk) return;
    this.signalingOk = ok;
    if (this.phase !== "waiting" || this.peerId) return;
    this.status = ok
      ? this.hosting
        ? "Tell your friend this code. They tap Join room on this same game."
        : "In the room. Waiting for the other phone."
      : "Can't reach the game server. Leave this open — it keeps trying.";
    this.publish(true);
  }

  private armSide(remoteId: string): void {
    const side = this.selfId < remoteId ? 1 : -1;
    this.sim.prepare(side, true, this.selfId < remoteId);
    this.sideReady = true;
    this.readyAt = performance.now();
    this.status = `${this.themName} is in. Hold still — the lane opens.`;
  }

  private onPeers(peers: NetPeer[]): void {
    const remote = peers.find((p) => p.id !== this.selfId);
    if (!remote) {
      if (this.peerId && (this.phase === "play" || this.phase === "waiting" || this.phase === "over")) {
        this.link = "lost";
        this.status = "Pilot dropped. The lane is yours — or head back to the bay.";
        this.say("LINK LOST");
      }
      this.publish(true);
      return;
    }
    this.peerId = remote.id;
    if (remote.name) this.themName = cleanName(remote.name);
    this.rtt = remote.rttMs;
    const direct = remote.connectionState === "connected";
    this.link = direct ? "live" : "waiting";
    if (!this.sideReady && (this.phase === "waiting" || this.phase === "title")) {
      this.armSide(remote.id);
    } else if (this.phase === "play" || this.phase === "over") {
      this.status = direct ? "Live" : "Reconnecting…";
    }
    this.publish(true);
  }

  private fresh(msg: Wire): boolean {
    if (!msg.e) return true;
    if (this.seenE.has(msg.e)) return false;
    this.seenE.add(msg.e);
    if (this.seenE.size > 240) {
      const first = this.seenE.values().next().value;
      if (first) this.seenE.delete(first);
    }
    return true;
  }

  private onNet(data: unknown): void {
    if (!data || typeof data !== "object") return;
    const msg = data as Wire;
    if (!msg.k || !this.fresh(msg)) return;
    if (msg.k === "go") {
      if (this.phase !== "waiting") return;
      if (msg.m && !this.hosting) {
        const id = mapById(msg.m).id;
        if (id !== this.mapId) this.setMap(id);
      }
      // A countdown stamp already in the past is a leftover from an older lobby.
      if (msg.at < Date.now() - 800) return;
      if (!this.sideReady && this.peerId) this.armSide(this.peerId);
      if (!this.goAt || msg.at < this.goAt) this.goAt = msg.at;
      return;
    }
    if (msg.k === "mp") {
      if (!this.hosting && msg.m) {
        const id = mapById(msg.m).id;
        if (id !== this.mapId) this.setMap(id);
      }
      return;
    }
    if (msg.k === "re") {
      if (this.net && this.peerId && (this.phase === "play" || this.phase === "over")) this.restartLinked();
      return;
    }
    if (this.phase !== "play" && this.phase !== "over") return;
    if (msg.k === "st") {
      if (!msg.ep) return;
      if (msg.ep !== this.themEpoch) {
        this.themEpoch = msg.ep;
        this.themSeq = 0;
      }
      if (msg.seq < this.themSeq) return;
      this.themSeq = msg.seq;
      const was = this.sim.them.alive;
      this.sim.applyRemote({
        x: msg.x,
        z: msg.z,
        vx: msg.vx,
        vz: msg.vz,
        nose: msg.n,
        hp: msg.hp,
        alive: msg.a === 1,
        frags: msg.fr,
        deaths: msg.de,
        shield: msg.sh,
        rapid: msg.rp,
        spread: msg.sp,
      });
      this.remoteAt = performance.now();
      if (was && !this.sim.them.alive) this.fragBurst(CYAN, this.sim.them.x, this.sim.them.z);
      this.watchWin();
      return;
    }
    if (msg.k === "sh") {
      if (!this.sim.ingestShot(msg.id, msg.x, msg.z, msg.dx, msg.dz)) return;
      playFx("shot");
      return;
    }
    if (msg.k === "hit") {
      if (!this.sim.resolveHit(msg.id)) return;
      playFx(this.sim.them.shield > 0 ? "clang" : "hit");
      this.view.burst(this.sim.them.x, this.sim.them.z, CYAN, 10, 2.4);
      return;
    }
    if (msg.k === "dn") {
      const x = this.sim.them.x;
      const z = this.sim.them.z;
      if (this.sim.remoteDown()) this.fragBurst(CYAN, x, z);
      this.watchWin();
      return;
    }
    if (msg.k === "pw") {
      this.sim.offerPower({ id: msg.id, kind: msg.kind, x: msg.x, z: 0 });
      return;
    }
    if (msg.k === "tk") {
      this.sim.remoteTake(msg.id);
      return;
    }
    if (msg.k === "rk") {
      const hit = this.sim.strike(msg.i);
      if (!hit) return;
      if (hit.kind === "chip") {
        playFx("chip");
        this.view.burst(hit.x, hit.z, 0xd9c7a4, 6, 1.5);
      } else {
        this.rockBlast(hit.x, hit.z);
      }
    }
  }

  private frame = (now: number): void => {
    if (this.dead) return;
    const boot = window as Window & { __riftBoot?: boolean };
    if (boot.__riftBoot && this.phase === "title") {
      boot.__riftBoot = false;
      this.startSolo(this.youName);
    }
    const stub = window.__controlsTest as { touched?: boolean; keys?: string[] } | undefined;
    if (import.meta.env.DEV && stub?.touched && Array.isArray(stub.keys)) {
      this.qa = new Set(stub.keys);
    }
    const dt = Math.min(0.05, this.last ? (now - this.last) / 1000 : 0);
    this.last = now;
    if (this.phase === "waiting" && this.sideReady && this.peerId) {
      if (!this.goAt && this.selfId < this.peerId) this.goAt = Date.now() + 2800;
      if (!this.goAt && now - this.readyAt > 1200) this.goAt = Date.now() + 1600;
      if (this.goAt && this.selfId < this.peerId && now - this.goSentAt > 350) {
        this.goSentAt = now;
        this.netSend({ k: "go", at: this.goAt, m: this.hosting ? this.mapId : undefined });
      }
      if (this.hosting && now - this.mapSentAt > 450) {
        this.mapSentAt = now;
        this.netSend({ k: "mp", m: this.mapId });
      }
    }
    if (this.phase === "waiting" && this.goAt && this.sideReady) {
      const left = (this.goAt - Date.now()) / 1000;
      this.countdown = Math.max(0, left);
      if (left <= 0) {
        this.phase = "play";
        this.countdown = 0;
        this.status = "Noses in";
        this.publish(true);
      }
    }
    this.acc += dt;
    let steps = 0;
    while (this.acc >= STEP && steps < 5) {
      if (this.phase === "play") {
        this.sim.step(STEP, this.readActions());
        this.consume();
        this.watchWin();
      }
      this.acc -= STEP;
      steps += 1;
    }
    this.pumpNet(dt);
    if (this.banner && now > this.bannerUntil) {
      this.banner = "";
      this.publish(true);
    }
    const lead =
      this.net && this.remoteAt ? Math.min(0.12, (performance.now() - this.remoteAt) / 1000) : 0;
    const follow = this.phase === "play" || this.phase === "over" || (this.phase === "waiting" && this.sideReady);
    this.view.render(this.sim, dt || STEP, follow, lead);
    this.publish(false);
    this.raf = requestAnimationFrame(this.frame);
  };

  private readActions(): Actions {
    const keys = this.qa ?? this.keys;
    let strafe = 0;
    let thrust = 0;
    if (keys.has("KeyA") || keys.has("ArrowLeft")) strafe -= 1;
    if (keys.has("KeyD") || keys.has("ArrowRight")) strafe += 1;
    if (keys.has("KeyW") || keys.has("ArrowUp")) thrust += 1;
    if (keys.has("KeyS") || keys.has("ArrowDown")) thrust -= 1;
    if (this.qa === null && this.stick.on) {
      strafe = Math.max(-1, Math.min(1, this.stick.x));
      thrust = Math.max(-1, Math.min(1, this.stick.y));
    }
    if (this.qa === null) this.readPad(strafe, thrust);
    else return {
      strafe,
      thrust,
      fire: keys.has("Space") || keys.has("KeyJ"),
      boost: keys.has("ShiftLeft") || keys.has("ShiftRight") || keys.has("KeyK"),
    };
    const pad = this.pad;
    return {
      strafe: pad.used ? pad.strafe : strafe,
      thrust: pad.used ? pad.thrust : thrust,
      fire:
        keys.has("Space") ||
        keys.has("KeyJ") ||
        this.fireHeld ||
        this.pointerFire ||
        pad.fire,
      boost: keys.has("ShiftLeft") || keys.has("ShiftRight") || keys.has("KeyK") || pad.boost || this.takeShield(),
    };
  }

  private takeShield(): boolean {
    const pressed = this.boostHeld || this.shieldQueued;
    this.shieldQueued = false;
    return pressed;
  }

  private pad = { used: false, strafe: 0, thrust: 0, fire: false, boost: false };

  private readPad(strafe: number, thrust: number): void {
    this.pad.used = false;
    this.pad.strafe = strafe;
    this.pad.thrust = thrust;
    this.pad.fire = false;
    this.pad.boost = false;
    const pads = navigator.getGamepads?.();
    if (!pads) return;
    for (const pad of pads) {
      if (!pad) continue;
      const x = pad.axes[0] ?? 0;
      const y = pad.axes[1] ?? 0;
      if (Math.hypot(x, y) > 0.18) {
        this.pad.used = true;
        this.pad.strafe = Math.max(-1, Math.min(1, x));
        this.pad.thrust = Math.max(-1, Math.min(1, -y));
      }
      if (pad.buttons[0]?.pressed || pad.buttons[7]?.pressed) this.pad.fire = true;
      if (pad.buttons[1]?.pressed || pad.buttons[5]?.pressed || pad.buttons[6]?.pressed) this.pad.boost = true;
    }
  }

  private consume(): void {
    for (const im of this.sim.impacts) {
      playFx(im.kind === "clang" ? "clang" : "hit");
      const color = im.owner === "you" ? AMBER : CYAN;
      this.view.burst(im.x, im.z, color, im.kind === "hit" ? 14 : 8, im.kind === "hit" ? 3 : 2.1);
      if (im.owner === "you") this.view.kick(im.kind === "hit" ? 0.34 : 0.12);
    }
    for (const fx of this.sim.fx) {
      playFx(fx);
      if (fx === "boom") {
        this.view.kick(0.48);
        if (!this.sim.you.alive) {
          this.view.burst(this.sim.you.x, this.sim.you.z, AMBER, 30, 4.4);
          this.say("HULL LOST");
        }
        if (!this.sim.them.alive) {
          this.view.burst(this.sim.them.x, this.sim.them.z, CYAN, 30, 4.4);
          this.say("FRAG");
        }
      } else if (fx === "shot") {
        this.view.burst(this.sim.you.x, this.sim.you.z, AMBER, 3, 1);
      }
    }
    for (const ev of this.sim.events) {
      if (ev.t === "chip") this.view.burst(ev.x, ev.z, 0xd9c7a4, 6, 1.6);
      else if (ev.t === "blast") this.rockBlast(ev.x, ev.z);
      else if (ev.t === "reform") this.view.burst(ev.x, ev.z, 0xb7f3df, 8, 1.3);
    }
    if (!this.net || !this.room) {
      this.sim.events.length = 0;
      return;
    }
    for (const ev of this.sim.events) {
      if (ev.t === "shot") {
        this.netSend({ k: "sh", id: ev.id, x: ev.x, z: ev.z, dx: ev.dx, dz: ev.dz });
      } else if (ev.t === "hit") {
        this.netSend({ k: "hit", id: ev.id });
      } else if (ev.t === "down") {
        this.netSend({ k: "dn" });
      } else if (ev.t === "take") {
        this.netSend({ k: "tk", id: ev.id });
      } else if (ev.t === "power") {
        this.netSend({ k: "pw", id: ev.power.id, kind: ev.power.kind, x: ev.power.x });
      } else if (ev.t === "chip" || ev.t === "blast") {
        this.netSend({ k: "rk", i: ev.i });
      }
    }
  }

  private netSend(msg: Wire): void {
    if (!this.room) return;
    this.eid += 1;
    const wire: Wire = { ...msg, e: `${this.selfId}:${this.epoch}:${this.eid}` };
    this.room.send(wire);
    this.room.relay(wire);
  }

  private pumpNet(dt: number): void {
    if (!this.room || !this.sideReady || (this.phase !== "play" && this.phase !== "over")) return;
    this.netAcc += dt;
    if (this.netAcc < 0.05) return;
    this.netAcc = 0;
    this.seq += 1;
    const s = this.sim.you;
    const packet: Wire = {
      k: "st",
      seq: this.seq,
      x: round(s.x),
      z: round(s.z),
      vx: round(s.vx),
      vz: round(s.vz),
      n: round(s.nose),
      hp: Math.round(s.hp),
      a: s.alive ? 1 : 0,
      fr: this.sim.frags,
      de: this.sim.deaths,
      sh: round(s.shield),
      rp: round(s.rapid),
      sp: round(s.spread),
      ep: this.epoch,
    };
    if (this.link === "live") this.room.broadcast(packet);
    this.room.pushState(packet);
  }

  private rockBlast(x: number, z: number): void {
    playFx("boom");
    const dx = x - this.sim.you.x;
    const dz = z - this.sim.you.z;
    this.view.kick(dx * dx + dz * dz < 40 ? 0.3 : 0.1);
    this.view.burst(x, z, 0xe7d3ae, 26, 3.6);
  }

  private fragBurst(color: number, x: number, z: number): void {
    playFx("boom");
    this.view.kick(0.4);
    this.view.burst(x, z, color, 28, 4.2);
    this.say("FRAG");
  }

  private watchWin(): void {
    if (this.phase !== "play" || !this.sim.over) return;
    this.phase = "over";
    this.say(this.sim.over === "you" ? "LANE CLEAR" : "LANE LOST");
    if (!this.net && this.sim.over === "you" && !this.winsStored) {
      this.winsStored = true;
      this.wardenWins += 1;
      try {
        localStorage.setItem("rift-duel-wins", String(this.wardenWins));
      } catch {
        /* ignore */
      }
    }
    this.publish(true);
  }

  private say(text: string): void {
    this.banner = text;
    this.bannerUntil = performance.now() + 1200;
    this.publish(true);
  }

  private rememberName(): void {
    try {
      localStorage.setItem("rift-duel-name", this.youName);
    } catch {
      /* ignore */
    }
  }

  private closeRoom(): void {
    this.room?.close();
    this.room = null;
  }

  private publish(force: boolean): void {
    setBed(this.phase === "play" || this.phase === "over" ? "fight" : "menu");
    const now = performance.now();
    const you = this.sim.you;
    const countdown = this.phase === "waiting" ? Math.ceil(this.countdown) : 0;
    const key = [
      this.phase,
      this.link,
      this.sim.frags,
      this.sim.deaths,
      this.sim.over,
      countdown,
      this.banner,
      this.status,
      this.themName,
      this.roomCode,
      this.muted,
      Math.round(you.hp),
      Math.round(this.sim.them.hp),
      you.shield > 0 ? 1 : 0,
      you.rapid > 0 ? 1 : 0,
      you.spread > 0 ? 1 : 0,
      this.mapId,
      this.rtt ?? "",
    ].join("|");
    if (!force && key === this.hudKey && now - this.lastHud < 120) return;
    this.hudKey = key;
    this.lastHud = now;
    this.onHud({
      phase: this.phase,
      room: this.roomCode,
      youName: this.youName,
      themName: this.themName,
      youHp: you.hp,
      themHp: this.sim.them.hp,
      youFrags: this.sim.frags,
      themFrags: this.sim.deaths,
      fragsToWin: FRAGS_TO_WIN,
      shield: you.shield > 0,
      rapid: you.rapid > 0,
      spread: you.spread > 0,
      shieldCd: you.shield > 0 ? 0 : you.boostCd > 0 ? you.boostCd / SHIELD_CD : 0,
      banner: this.banner,
      status: this.status,
      winner: this.sim.over,
      rtt: this.rtt,
      link: this.link,
      muted: this.muted,
      wardenWins: this.wardenWins,
      countdown,
      net: this.net,
      map: this.mapId,
    });
  }
}

function round(n: number): number {
  return Math.round(n * 100) / 100;
}
