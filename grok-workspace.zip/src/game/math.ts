/** Shared lane math. Side +1 holds +Z (south lip). Side −1 holds −Z.
 *  Each camera sits behind its own ship, so screen-up is always toward the other pilot.
 *  Screen-left is world −X for south and world +X for north — across the table. */

export type Side = 1 | -1;

export const ARENA_X = 7.55;
export const Z_NEAR = 0.65;
export const Z_FAR = 14.7;
export const SHIP_R = 0.7;
export const BOLT_R = 0.16;
export const BOLT_SPEED = 27;
export const BOLT_LIFE = 1.7;
export const BOLT_DAMAGE = 20;
export const ROCK_DAMAGE = 8;
export const FIRE_CD = 0.2;
export const RAPID_CD = 0.095;
export const STRAFE_ACCEL = 52;
export const THRUST_ACCEL = 40;
export const DRAG = 5.4;
export const MAX_SPEED = 12.5;
export const SHIELD_TIME = 3;
export const SHIELD_CD = 6.4;
export const ROCK_HITS = 3;
export const ROCK_RESPAWN = 6.5;
export const FRAGS_TO_WIN = 4;
export const NOSE_MAX = 0.74;

export type Asteroid = { x: number; z: number; r: number; spin: number };

const ASTS: Asteroid[] = [
  { x: 0, z: 0, r: 0.98, spin: 0.45 },
  { x: 0, z: 0, r: 0.74, spin: -0.7 },
  { x: 0, z: 0, r: 1.08, spin: 0.55 },
  { x: 0, z: 0, r: 0.82, spin: -0.32 },
];

export function nowSec(): number {
  return Date.now() / 1000;
}

export function clamp(v: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, v));
}

export function asteroids(t: number): readonly Asteroid[] {
  for (let i = 0; i < ASTS.length; i += 1) {
    const phase = i * 1.65;
    ASTS[i].x = Math.sin(t * (0.28 + i * 0.04) + phase) * (5.6 - i * 0.22);
    ASTS[i].z = Math.sin(t * 0.19 + phase * 1.4) * 1.05;
  }
  return ASTS;
}

export function laneForward(side: Side): { x: number; z: number } {
  return side === 1 ? { x: 0, z: -1 } : { x: 0, z: 1 };
}

export function laneRight(side: Side): { x: number; z: number } {
  return side === 1 ? { x: 1, z: 0 } : { x: -1, z: 0 };
}

/** nose > 0 yaws the guns toward screen-left. */
export function aimDir(side: Side, nose: number): { x: number; z: number } {
  const f = laneForward(side);
  const leftX = -laneRight(side).x;
  const leftZ = -laneRight(side).z;
  const c = Math.cos(nose);
  const s = Math.sin(nose);
  return { x: f.x * c + leftX * s, z: f.z * c + leftZ * s };
}

export function clampShip(side: Side, x: number, z: number): { x: number; z: number } {
  return {
    x: clamp(x, -ARENA_X, ARENA_X),
    z: side === 1 ? clamp(z, Z_NEAR, Z_FAR) : clamp(z, -Z_FAR, -Z_NEAR),
  };
}

export function spawnFor(side: Side): { x: number; z: number } {
  return { x: 0, z: side === 1 ? 12.2 : -12.2 };
}
