import * as THREE from "three";
import { aimDir, asteroids, nowSec, SHIELD_CD, type Side } from "./math";
import { mapById, type MapId } from "./maps";
import type { Sim } from "./sim";

const AMBER = 0xf26b1d;
const CYAN = 0x2ee6c7;
const VOID = 0x07090d;

const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _x = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _c = new THREE.Color();
const _look = new THREE.Vector3();
const _cam = new THREE.Vector3();

type Craft = {
  group: THREE.Group;
  hot: THREE.MeshStandardMaterial;
  engine: THREE.Mesh;
  ring: THREE.Mesh;
  bubble: THREE.Mesh;
  halo: THREE.Mesh;
};

type Particle = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  cr: number;
  cg: number;
  cb: number;
};

function makeCraft(hex: number): Craft {
  const group = new THREE.Group();
  const hull = new THREE.MeshStandardMaterial({
    color: 0x1a221c,
    metalness: 0.72,
    roughness: 0.32,
    emissive: hex,
    emissiveIntensity: 0.06,
  });
  const hot = new THREE.MeshStandardMaterial({
    color: hex,
    emissive: hex,
    emissiveIntensity: 0.85,
    metalness: 0.35,
    roughness: 0.28,
  });
  const glass = new THREE.MeshStandardMaterial({
    color: 0x0c100e,
    metalness: 0.85,
    roughness: 0.12,
    emissive: hex,
    emissiveIntensity: 0.35,
  });
  const glow = new THREE.MeshBasicMaterial({
    color: hex,
    transparent: true,
    opacity: 0.95,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });

  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.72, 5), hot);
  nose.rotation.x = Math.PI / 2;
  nose.position.z = 0.78;
  group.add(nose);

  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.28, 1.05, 6), hull);
  body.rotation.x = Math.PI / 2;
  body.position.z = 0.05;
  group.add(body);

  const wings = new THREE.Mesh(new THREE.BoxGeometry(1.45, 0.045, 0.42), hot);
  wings.position.set(0, 0, -0.08);
  group.add(wings);

  const tail = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.035, 0.2), hull);
  tail.position.set(0, 0.1, -0.48);
  group.add(tail);

  const canopy = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 8), glass);
  canopy.scale.set(0.85, 0.62, 1.35);
  canopy.position.set(0, 0.16, 0.22);
  group.add(canopy);

  const fin = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.42, 0.34), hot);
  fin.position.set(0, 0.28, -0.32);
  group.add(fin);

  const engine = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), glow);
  engine.position.set(0, 0, -0.62);
  group.add(engine);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.62, 0.78, 20),
    new THREE.MeshBasicMaterial({
      color: hex,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.75,
    }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.04;

  const bubble = new THREE.Mesh(
    new THREE.SphereGeometry(1.05, 22, 16),
    new THREE.MeshBasicMaterial({
      color: hex,
      transparent: true,
      opacity: 0.28,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    }),
  );
  bubble.visible = false;
  bubble.renderOrder = 2;
  group.add(bubble);

  const halo = new THREE.Mesh(
    new THREE.TorusGeometry(1.2, 0.045, 8, 32),
    new THREE.MeshBasicMaterial({
      color: hex,
      transparent: true,
      opacity: 0.75,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    }),
  );
  halo.rotation.x = Math.PI / 2;
  halo.visible = false;
  group.add(halo);

  group.scale.setScalar(2.35);
  group.position.y = 0.9;
  return { group, hot, engine, ring, bubble, halo };
}

function orient(obj: THREE.Object3D, dirX: number, dirZ: number, bank: number): void {
  _fwd.set(dirX, 0, dirZ);
  if (_fwd.lengthSq() < 1e-8) return;
  _fwd.normalize();
  _up.set(0, 1, 0);
  _x.crossVectors(_up, _fwd);
  if (_x.lengthSq() < 1e-8) return;
  _x.normalize();
  _m.makeBasis(_x, _up, _fwd);
  obj.quaternion.setFromRotationMatrix(_m);
  obj.rotateZ(bank);
}

export class RiftView {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  private readonly you: Craft;
  private readonly them: Craft;
  private readonly bolts: THREE.InstancedMesh;
  private readonly rocks: THREE.Mesh[] = [];
  private readonly power: THREE.Group;
  private readonly points: THREE.Points;
  private readonly pGeom: THREE.BufferGeometry;
  private readonly particles: Particle[] = [];
  private readonly pPos: Float32Array;
  private readonly pCol: Float32Array;
  private camX = 0;
  private camY = 14;
  private camZ = 24;
  private shake = 0;
  private reduce: boolean;
  private disposed = false;
  private readonly hemi: THREE.HemisphereLight;
  private readonly sun: THREE.DirectionalLight;
  private readonly riftLight: THREE.PointLight;
  private readonly floorMat: THREE.MeshStandardMaterial;
  private readonly riftMat: THREE.MeshBasicMaterial;
  private readonly coreMat: THREE.MeshBasicMaterial;
  private readonly wallMat: THREE.MeshStandardMaterial;
  private readonly starMat: THREE.PointsMaterial;
  private readonly stars: THREE.Points;
  private readonly sunDisc: THREE.Mesh;
  private readonly snow: THREE.Points;
  private readonly snowPos: Float32Array;
  private readonly rain: THREE.Points;
  private readonly rainPos: Float32Array;
  private readonly trees: THREE.Group;
  private readonly ghosts: THREE.Group;
  private floorTex: THREE.CanvasTexture;
  private rockGlow = 0.4;

  constructor(canvas: HTMLCanvasElement) {
    this.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.setClearColor(VOID, 1);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.camera = new THREE.PerspectiveCamera(48, 1, 0.1, 180);
    this.scene.fog = new THREE.FogExp2(VOID, 0.022);
    this.scene.background = new THREE.Color(VOID);

    this.hemi = new THREE.HemisphereLight(0xc8e6dc, 0x07090d, 0.55);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xf4f0e4, 1.35);
    this.sun.position.set(6, 14, 8);
    this.scene.add(this.sun);
    this.riftLight = new THREE.PointLight(CYAN, 8, 18, 2);
    this.riftLight.position.set(0, 1.5, 0);
    this.scene.add(this.riftLight);
    this.sunDisc = new THREE.Mesh(
      new THREE.SphereGeometry(1.4, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xfff1c4 }),
    );
    this.sunDisc.position.set(10, 24, 6);
    this.sunDisc.visible = false;
    this.scene.add(this.sunDisc);

    this.floorTex = gridTexture("#0c110e", "#1a2c24");
    this.floorMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: this.floorTex,
      roughness: 1,
      metalness: 0.05,
    });
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(70, 80), this.floorMat);
    floor.rotation.x = -Math.PI / 2;
    this.scene.add(floor);

    this.riftMat = new THREE.MeshBasicMaterial({
      color: CYAN,
      transparent: true,
      opacity: 0.18,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const rift = new THREE.Mesh(new THREE.PlaneGeometry(16.4, 2.2), this.riftMat);
    rift.rotation.x = -Math.PI / 2;
    rift.position.y = 0.03;
    this.scene.add(rift);

    this.coreMat = new THREE.MeshBasicMaterial({
      color: 0xd7fff6,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const core = new THREE.Mesh(new THREE.PlaneGeometry(16.4, 0.07), this.coreMat);
    core.rotation.x = -Math.PI / 2;
    core.position.y = 0.04;
    this.scene.add(core);

    const deck = (z: number, color: number) => {
      const mesh = new THREE.Mesh(
        new THREE.PlaneGeometry(3.2, 0.08),
        new THREE.MeshBasicMaterial({
          color,
          transparent: true,
          opacity: 0.55,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          side: THREE.DoubleSide,
        }),
      );
      mesh.rotation.x = -Math.PI / 2;
      mesh.position.set(0, 0.05, z);
      this.scene.add(mesh);
    };
    deck(15.05, AMBER);
    deck(-15.05, CYAN);

    this.wallMat = new THREE.MeshStandardMaterial({
      color: 0x121814,
      emissive: 0x14584c,
      emissiveIntensity: 0.55,
      metalness: 0.45,
      roughness: 0.4,
    });
    const addWall = (x: number, z: number, sx: number, sz: number) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, 0.55, sz), this.wallMat);
      mesh.position.set(x, 0.28, z);
      this.scene.add(mesh);
    };
    addWall(-8.15, 0, 0.16, 31);
    addWall(8.15, 0, 0.16, 31);
    addWall(0, 15.6, 16.2, 0.16);
    addWall(0, -15.6, 16.2, 0.16);

    const starPos = new Float32Array(900 * 3);
    for (let i = 0; i < 900; i += 1) {
      starPos[i * 3] = (Math.random() - 0.5) * 90;
      starPos[i * 3 + 1] = Math.random() * 28 + 2;
      starPos[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute("position", new THREE.BufferAttribute(starPos, 3));
    this.starMat = new THREE.PointsMaterial({ color: 0xd5e6dc, size: 0.08, transparent: true, opacity: 0.8 });
    this.stars = new THREE.Points(starGeo, this.starMat);
    this.scene.add(this.stars);

    this.snowPos = new Float32Array(240 * 3);
    for (let i = 0; i < 240; i += 1) {
      this.snowPos[i * 3] = (Math.random() - 0.5) * 28;
      this.snowPos[i * 3 + 1] = Math.random() * 16;
      this.snowPos[i * 3 + 2] = (Math.random() - 0.5) * 36;
    }
    const snowGeo = new THREE.BufferGeometry();
    snowGeo.setAttribute("position", new THREE.BufferAttribute(this.snowPos, 3));
    this.snow = new THREE.Points(
      snowGeo,
      new THREE.PointsMaterial({ color: 0xffffff, size: 0.14, transparent: true, opacity: 0.9 }),
    );
    this.snow.visible = false;
    this.scene.add(this.snow);

    this.rainPos = new Float32Array(420 * 3);
    for (let i = 0; i < 420; i += 1) {
      this.rainPos[i * 3] = (Math.random() - 0.5) * 30;
      this.rainPos[i * 3 + 1] = Math.random() * 18;
      this.rainPos[i * 3 + 2] = (Math.random() - 0.5) * 40;
    }
    const rainGeo = new THREE.BufferGeometry();
    rainGeo.setAttribute("position", new THREE.BufferAttribute(this.rainPos, 3));
    this.rain = new THREE.Points(
      rainGeo,
      new THREE.PointsMaterial({
        color: 0xd4f4ff,
        size: 0.055,
        transparent: true,
        opacity: 0.75,
        depthWrite: false,
      }),
    );
    this.rain.visible = false;
    this.scene.add(this.rain);

    this.trees = new THREE.Group();
    const pine = new THREE.MeshStandardMaterial({ color: 0x1d6b3a, roughness: 0.8 });
    const trunk = new THREE.MeshStandardMaterial({ color: 0x6b3a22, roughness: 0.9 });
    for (const [x, z] of [
      [-11.2, -10],
      [11.2, -4],
      [-11.4, 3],
      [11.3, 9],
      [-10.8, 14],
    ] as const) {
      const tree = new THREE.Group();
      const cone = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.8, 6), pine);
      cone.position.y = 1.3;
      const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 0.5, 5), trunk);
      stick.position.y = 0.25;
      tree.add(cone, stick);
      tree.position.set(x, 0, z);
      this.trees.add(tree);
    }
    this.trees.visible = false;
    this.scene.add(this.trees);

    this.ghosts = new THREE.Group();
    const sheet = new THREE.MeshBasicMaterial({
      color: 0xf4f0ff,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
    });
    for (let i = 0; i < 5; i += 1) {
      const ghost = new THREE.Group();
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.38, 10, 8), sheet);
      body.scale.set(1, 1.25, 1);
      const tail = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.55, 7), sheet);
      tail.rotation.x = Math.PI;
      tail.position.y = -0.42;
      ghost.add(body, tail);
      ghost.position.set(i % 2 === 0 ? -6.2 : 6.2, 2.2, -12 + i * 5.5);
      ghost.userData.phase = i * 1.3;
      this.ghosts.add(ghost);
    }
    this.ghosts.visible = false;
    this.scene.add(this.ghosts);

    this.you = makeCraft(AMBER);
    this.them = makeCraft(CYAN);
    this.scene.add(this.you.group, this.you.ring, this.them.group, this.them.ring);

    const boltGeo = new THREE.BoxGeometry(0.1, 0.1, 0.7);
    const boltMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.bolts = new THREE.InstancedMesh(boltGeo, boltMat, 72);
    this.bolts.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.bolts.count = 0;
    this.scene.add(this.bolts);

    const rockGeo = new THREE.IcosahedronGeometry(1, 0);
    for (let i = 0; i < 4; i += 1) {
      const mesh = new THREE.Mesh(
        rockGeo,
        new THREE.MeshStandardMaterial({
          color: 0x24302a,
          flatShading: true,
          roughness: 0.92,
          metalness: 0.08,
          emissive: 0x102820,
          emissiveIntensity: 0.4,
        }),
      );
      this.rocks.push(mesh);
      this.scene.add(mesh);
    }

    const crystalMat = new THREE.MeshStandardMaterial({
      color: 0xd8b4fe,
      emissive: 0xa855f7,
      emissiveIntensity: 1.35,
      metalness: 0.42,
      roughness: 0.16,
    });
    this.power = new THREE.Group();
    const shard = new THREE.Mesh(new THREE.OctahedronGeometry(0.36, 0), crystalMat);
    shard.scale.set(0.7, 1.9, 0.7);
    const flake = new THREE.Mesh(new THREE.OctahedronGeometry(0.2, 0), crystalMat);
    flake.scale.set(0.55, 1.15, 0.55);
    flake.rotation.y = 0.7;
    flake.position.y = 0.12;
    this.power.add(shard, flake);
    this.power.visible = false;
    this.scene.add(this.power);

    const MAX = 180;
    this.pPos = new Float32Array(MAX * 3);
    this.pCol = new Float32Array(MAX * 3);
    this.pGeom = new THREE.BufferGeometry();
    this.pGeom.setAttribute("position", new THREE.BufferAttribute(this.pPos, 3));
    this.pGeom.setAttribute("color", new THREE.BufferAttribute(this.pCol, 3));
    this.points = new THREE.Points(
      this.pGeom,
      new THREE.PointsMaterial({
        size: 0.16,
        vertexColors: true,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    this.scene.add(this.points);
    for (let i = 0; i < MAX; i += 1) {
      this.particles.push({
        x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, max: 1, cr: 1, cg: 1, cb: 1,
      });
    }

    this.resize();
  }

  setMap(id: MapId): void {
    const theme = mapById(id);
    this.rockGlow = theme.rockGlowAmt;
    this.renderer.setClearColor(theme.sky, 1);
    const fog = this.scene.fog as THREE.FogExp2;
    fog.color.set(theme.fog);
    fog.density = theme.fogDensity;
    (this.scene.background as THREE.Color).set(theme.sky);
    this.hemi.color.set(theme.hemiSky);
    this.hemi.groundColor.set(theme.hemiGround);
    this.hemi.intensity = theme.hemi;
    this.sun.color.set(theme.sun);
    this.sun.intensity = theme.sunIntensity;
    this.sun.position.set(theme.sunPos[0], theme.sunPos[1], theme.sunPos[2]);
    this.sunDisc.visible = theme.disc;
    this.sunDisc.scale.setScalar(theme.disc ? 2.6 : 1);
    this.sunDisc.position.set(theme.sunPos[0], theme.sunPos[1], theme.sunPos[2]);
    (this.sunDisc.material as THREE.MeshBasicMaterial).color.set(theme.discColor);
    this.riftLight.color.set(theme.rift);
    this.riftLight.intensity = theme.riftIntensity;
    this.riftMat.color.set(theme.rift);
    this.coreMat.color.set(theme.riftCore);
    this.wallMat.color.set(theme.wall);
    this.wallMat.emissive.set(theme.wallGlow);
    this.wallMat.emissiveIntensity = theme.wallGlowAmt;
    this.starMat.color.set(theme.stars);
    this.starMat.opacity = theme.starOpacity;
    this.stars.visible = theme.starOpacity > 0.02;
    const next = gridTexture(theme.floor, theme.grid);
    this.floorTex.dispose();
    this.floorTex = next;
    this.floorMat.map = next;
    this.floorMat.needsUpdate = true;
    for (const mesh of this.rocks) {
      const mat = mesh.material as THREE.MeshStandardMaterial;
      mat.color.set(theme.rock);
      mat.emissive.set(theme.rockGlow);
      mat.emissiveIntensity = theme.rockGlowAmt;
    }
    this.snow.visible = id === "snow";
    this.trees.visible = id === "snow";
    this.ghosts.visible = id === "haunt";
    this.rain.visible = id === "rain";
    if (id === "snow") this.starMat.opacity = 0.35;
  }

  resize(): void {
    const canvas = this.renderer.domElement;
    const w = canvas.clientWidth || 1;
    const h = canvas.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    const vfov = 48 * (Math.PI / 180);
    const hfov = 2 * Math.atan(Math.tan(vfov / 2) * this.camera.aspect);
    const minH = 62 * (Math.PI / 180);
    if (hfov < minH) {
      this.camera.fov = (2 * Math.atan(Math.tan(minH / 2) / this.camera.aspect) * 180) / Math.PI;
    } else {
      this.camera.fov = 48;
    }
    this.camera.updateProjectionMatrix();
  }

  kick(amount: number): void {
    if (this.reduce) return;
    this.shake = Math.min(0.55, this.shake + amount);
  }

  burst(x: number, z: number, color: number, count: number, speed: number): void {
    _c.set(color);
    let left = count;
    for (const p of this.particles) {
      if (left <= 0) break;
      if (p.life > 0) continue;
      const a = Math.random() * Math.PI * 2;
      const u = Math.random();
      p.x = x;
      p.y = 0.4 + Math.random() * 0.4;
      p.z = z;
      p.vx = Math.cos(a) * speed * (0.4 + u);
      p.vz = Math.sin(a) * speed * (0.4 + u);
      p.vy = 1.2 + Math.random() * 2.4;
      p.life = 0.35 + Math.random() * 0.4;
      p.max = p.life;
      p.cr = _c.r;
      p.cg = _c.g;
      p.cb = _c.b;
      left -= 1;
    }
  }

  render(sim: Sim, dt: number, follow: boolean, themLead: number): void {
    if (this.disposed) return;
    const t = nowSec();
    this.shake *= Math.exp(-3.2 * dt);
    this.placeShips(sim, t, themLead);
    this.placeBolts(sim);
    this.placeRocks(t, sim);
    this.placePower(sim, t);
    this.stepMood(dt, t);
    this.stepParticles(dt);
    this.placeCamera(sim, dt, follow, t);
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void {
    this.disposed = true;
    this.renderer.dispose();
    this.floorTex.dispose();
    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = mesh.material;
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
      else if (mat) mat.dispose();
    });
  }

  private stepMood(dt: number, t: number): void {
    if (this.snow.visible) {
      const pos = this.snowPos;
      for (let i = 0; i < pos.length; i += 3) {
        pos[i + 1] -= dt * (1.6 + (i % 7) * 0.15);
        pos[i] += Math.sin(t + i) * dt * 0.15;
        if (pos[i + 1] < 0) {
          pos[i + 1] = 14 + Math.random() * 2;
          pos[i] = (Math.random() - 0.5) * 28;
          pos[i + 2] = (Math.random() - 0.5) * 36;
        }
      }
      const attr = this.snow.geometry.getAttribute("position") as THREE.BufferAttribute;
      attr.needsUpdate = true;
    }
    if (this.rain.visible) {
      const pos = this.rainPos;
      for (let i = 0; i < pos.length; i += 3) {
        pos[i + 1] -= dt * (14 + (i % 5) * 1.6);
        pos[i] += dt * 2.4;
        if (pos[i + 1] < 0) {
          pos[i + 1] = 14 + Math.random() * 4;
          pos[i] = (Math.random() - 0.5) * 30;
          pos[i + 2] = (Math.random() - 0.5) * 40;
        }
      }
      const attr = this.rain.geometry.getAttribute("position") as THREE.BufferAttribute;
      attr.needsUpdate = true;
    }
    if (this.ghosts.visible) {
      this.ghosts.children.forEach((ghost, i) => {
        const phase = (ghost.userData.phase as number) || 0;
        ghost.position.y = 1.8 + Math.sin(t * 1.3 + phase) * 0.45;
        ghost.position.x = (i % 2 === 0 ? -6.2 : 6.2) + Math.sin(t * 0.6 + phase) * 0.6;
        ghost.rotation.y = Math.sin(t + phase) * 0.4;
      });
    }
  }

  private placeShips(sim: Sim, t: number, themLead: number): void {
    const bob = this.reduce ? 0 : Math.sin(t * 2.1) * 0.035;
    placeCraft(
      this.you,
      sim.you.side,
      sim.you.x,
      sim.you.z,
      sim.you.nose,
      sim.you.vx,
      sim.you.alive,
      sim.you.invuln,
      sim.you.flash,
      sim.you.shield,
      sim.you.boostCd,
      t,
      bob,
    );
    const tx = sim.them.x + sim.them.vx * themLead;
    const tz = sim.them.z + sim.them.vz * themLead;
    placeCraft(
      this.them,
      sim.them.side,
      tx,
      tz,
      sim.them.nose,
      sim.them.vx,
      sim.them.alive,
      sim.them.invuln,
      sim.them.flash,
      sim.them.shield,
      sim.them.boostCd,
      t,
      -bob,
    );
  }

  private placeBolts(sim: Sim): void {
    const n = Math.min(sim.bolts.length, 72);
    this.bolts.count = n;
    for (let i = 0; i < n; i += 1) {
      const b = sim.bolts[i];
      _fwd.set(b.dx, 0, b.dz);
      if (_fwd.lengthSq() < 1e-8) _fwd.set(0, 0, 1);
      _fwd.normalize();
      _up.set(0, 1, 0);
      _x.crossVectors(_up, _fwd).normalize();
      _m.makeBasis(_x, _up, _fwd);
      _m.setPosition(b.x, 0.46, b.z);
      this.bolts.setMatrixAt(i, _m);
      _c.set(b.owner === "you" ? AMBER : CYAN);
      this.bolts.setColorAt(i, _c);
    }
    this.bolts.instanceMatrix.needsUpdate = true;
    if (this.bolts.instanceColor) this.bolts.instanceColor.needsUpdate = true;
  }

  private placeRocks(t: number, sim: Sim): void {
    const rocks = asteroids(t);
    for (let i = 0; i < this.rocks.length; i += 1) {
      const a = rocks[i];
      const mesh = this.rocks[i];
      const state = sim.rocks[i];
      if (!a || !state || state.down > 0) {
        mesh.visible = false;
        continue;
      }
      mesh.visible = true;
      const intro = state.pop > 0 ? Math.max(0.15, 1 - state.pop / 0.45) : 1;
      mesh.position.set(a.x, a.r * 0.45 * intro, a.z);
      mesh.scale.setScalar(a.r * intro);
      mesh.rotation.y = t * a.spin;
      mesh.rotation.x = t * a.spin * 0.6;
      const mat = mesh.material as THREE.MeshStandardMaterial;
      const hurt = 1 - state.hp / state.max;
      mat.emissiveIntensity = this.rockGlow + hurt * 1.1;
    }
  }

  private placePower(sim: Sim, t: number): void {
    if (!sim.power) {
      this.power.visible = false;
      return;
    }
    this.power.visible = true;
    this.power.position.set(sim.power.x, 1.05 + Math.sin(t * 3) * 0.14, sim.power.z);
    this.power.rotation.y = t * 1.4;
  }

  private stepParticles(dt: number): void {
    let write = 0;
    for (const p of this.particles) {
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) continue;
      p.vy -= 3.2 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      const fade = p.life / p.max;
      this.pPos[write * 3] = p.x;
      this.pPos[write * 3 + 1] = p.y;
      this.pPos[write * 3 + 2] = p.z;
      this.pCol[write * 3] = p.cr * fade;
      this.pCol[write * 3 + 1] = p.cg * fade;
      this.pCol[write * 3 + 2] = p.cb * fade;
      write += 1;
    }
    for (let i = write * 3; i < this.pPos.length; i += 1) this.pPos[i] = 0;
    this.pGeom.attributes.position.needsUpdate = true;
    this.pGeom.attributes.color.needsUpdate = true;
    this.pGeom.setDrawRange(0, write);
  }

  private placeCamera(sim: Sim, dt: number, follow: boolean, t: number): void {
    if (!follow) {
      const drift = this.reduce ? 0 : Math.sin(t * 0.35) * 0.8;
      _cam.set(drift, 6.8, 17.6);
      _look.set(0, 0.8, 6);
    } else {
      const ship = sim.you;
      const back = ship.side === 1 ? 1 : -1;
      _cam.set(ship.x * 0.28, 7.6, ship.z + back * 6.4);
      _look.set(ship.x * 0.08, 0.55, ship.z - back * 13.5);
    }
    const k = 1 - Math.exp(-4.5 * dt);
    this.camX += (_cam.x - this.camX) * k;
    this.camY += (_cam.y - this.camY) * k;
    this.camZ += (_cam.z - this.camZ) * k;
    const jx = this.reduce ? 0 : (Math.random() - 0.5) * this.shake;
    const jy = this.reduce ? 0 : (Math.random() - 0.5) * this.shake;
    this.camera.position.set(this.camX + jx, this.camY + jy, this.camZ);
    this.camera.lookAt(_look);
  }
}

function placeCraft(
  craft: Craft,
  side: Side,
  x: number,
  z: number,
  nose: number,
  vx: number,
  alive: boolean,
  invuln: number,
  flash: number,
  shield: number,
  shieldCd: number,
  t: number,
  bob: number,
): void {
  craft.group.visible = alive;
  craft.ring.visible = alive;
  craft.bubble.visible = false;
  craft.halo.visible = false;
  if (!alive) return;
  const blink = invuln > 0 && Math.sin(t * 28) > 0;
  craft.group.visible = !blink;
  craft.ring.visible = !blink;
  const dir = aimDir(side, nose);
  const bank = clampBank(-Math.sign(nose) * Math.min(0.45, Math.abs(nose) * 0.7 + Math.abs(vx) * 0.01));
  orient(craft.group, dir.x, dir.z, bank);
  craft.group.position.set(x, 0.95 + bob, z);
  craft.ring.position.set(x, 0.05, z);
  craft.ring.scale.setScalar(2.1);
  craft.hot.emissiveIntensity = 0.75 + flash * 2.4;
  const eng = 1 + Math.min(0.45, Math.abs(vx) * 0.04);
  craft.engine.scale.setScalar(eng);

  const bubbleMat = craft.bubble.material as THREE.MeshBasicMaterial;
  const haloMat = craft.halo.material as THREE.MeshBasicMaterial;
  if (shield > 0) {
    const pulse = 0.9 + Math.sin(t * 8) * 0.08;
    const fade = Math.min(1, shield / 0.4);
    craft.bubble.visible = !blink;
    craft.bubble.scale.setScalar(pulse);
    bubbleMat.opacity = (0.18 + Math.sin(t * 6) * 0.08) * fade;
    craft.halo.visible = !blink;
    craft.halo.scale.setScalar(1);
    craft.halo.rotation.z = t * 2.4;
    haloMat.opacity = 0.45 + Math.sin(t * 9) * 0.2;
  } else if (shieldCd > 0) {
    const regen = 1 - Math.min(1, shieldCd / SHIELD_CD);
    craft.halo.visible = !blink;
    craft.halo.scale.setScalar(0.28 + regen * 0.72);
    craft.halo.rotation.z = t * 0.8;
    haloMat.opacity = 0.15 + regen * 0.45;
  }
}

function clampBank(v: number): number {
  return Math.max(-0.5, Math.min(0.5, v));
}

function gridTexture(fill: string, line: string): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 512;
  const g = c.getContext("2d");
  if (!g) return new THREE.CanvasTexture(c);
  g.fillStyle = fill;
  g.fillRect(0, 0, 512, 512);
  g.strokeStyle = line;
  g.lineWidth = 2;
  for (let i = 0; i <= 512; i += 32) {
    g.beginPath();
    g.moveTo(i, 0);
    g.lineTo(i, 512);
    g.stroke();
    g.beginPath();
    g.moveTo(0, i);
    g.lineTo(512, i);
    g.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(8, 10);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}
