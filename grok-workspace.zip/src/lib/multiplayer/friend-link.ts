/**
 * Phone-to-phone lane that does not depend on this app's own server.
 * Two browsers with the same code meet on public relays over a normal
 * secure web connection (port 443), so a duel still starts on cell data
 * when a direct phone-to-phone link never opens.
 * A page cannot open a Bluetooth game between two phones.
 */
import type { PeerInfo } from "./p2p";
import { schnorr } from "@noble/curves/secp256k1.js";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, hexToBytes, utf8ToBytes } from "@noble/hashes/utils.js";

const RELAYS = ["wss://relay.damus.io", "wss://nos.lol", "wss://relay.primal.net"];
const HI_MS = 1200;
const DROP_MS = 7000;
const KIND = 20000;

type LaneMsg =
  | { t: "hi"; id: string; name: string; n: number }
  | { t: "pong"; id: string; to: string; n: number }
  | { t: "bye"; id: string }
  | { t: "ev"; id: string; d: unknown }
  | { t: "st"; id: string; d: unknown };

export interface FriendLinkOptions {
  room: string;
  selfId: string;
  name: string;
  onPeersChanged?: (peers: PeerInfo[]) => void;
  onMessage?: (from: string, data: unknown) => void;
  onSignaling?: (ok: boolean) => void;
}

type Sock = { url: string; ws: WebSocket | null; open: boolean };

export class FriendLink {
  private readonly tag: string;
  private readonly priv: Uint8Array;
  private readonly pub: string;
  private closed = false;
  private signaled = false;
  private hiTimer: ReturnType<typeof setInterval> | null = null;
  private dropTimer: ReturnType<typeof setInterval> | null = null;
  private stateTimer: ReturnType<typeof setTimeout> | null = null;
  private pendingState: unknown;
  private pendingEvents: unknown[] = [];
  private readonly remotes = new Map<string, { name: string; seen: number; rtt: number | null }>();
  private readonly socks = new Map<string, Sock>();
  private readonly seen = new Set<string>();
  private readonly seenOrder: string[] = [];
  private relayCursor = 0;
  private fingerprint = "";

  constructor(private readonly opts: FriendLinkOptions) {
    this.tag = `riftduel${opts.room}`;
    this.priv = schnorr.utils.randomSecretKey();
    this.pub = bytesToHex(schnorr.getPublicKey(this.priv));
  }

  async join(): Promise<void> {
    if (this.closed) return;
    for (const url of RELAYS) this.connect(url);
  }

  close(): void {
    this.closed = true;
    if (this.hiTimer) clearInterval(this.hiTimer);
    if (this.dropTimer) clearInterval(this.dropTimer);
    if (this.stateTimer) clearTimeout(this.stateTimer);
    this.hiTimer = null;
    this.dropTimer = null;
    this.publish({ t: "bye", id: this.opts.selfId });
    for (const sock of this.socks.values()) {
      sock.open = false;
      try {
        sock.ws?.close();
      } catch {
        /* already gone */
      }
      sock.ws = null;
    }
  }

  /** Game event (shot, hit, countdown). Queued until a relay is up. */
  send(data: unknown): void {
    if (this.closed) return;
    if (this.live() === 0) {
      this.pendingEvents.push(data);
      if (this.pendingEvents.length > 40) this.pendingEvents.shift();
      return;
    }
    this.publish({ t: "ev", id: this.opts.selfId, d: data });
  }

  /** Latest ship snapshot, coalesced. */
  pushState(data: unknown): void {
    if (this.closed) return;
    this.pendingState = data;
    if (this.stateTimer) return;
    this.stateTimer = setTimeout(() => {
      this.stateTimer = null;
      const payload = this.pendingState;
      this.pendingState = undefined;
      if (payload === undefined || this.closed) return;
      if (this.live() === 0) {
        this.pendingState = payload;
        return;
      }
      this.publish({ t: "st", id: this.opts.selfId, d: payload }, "one");
    }, 100);
  }

  private live(): number {
    let n = 0;
    for (const sock of this.socks.values()) if (sock.open) n += 1;
    return n;
  }

  private connect(url: string): void {
    if (this.closed) return;
    const prev = this.socks.get(url);
    if (prev?.ws && (prev.ws.readyState === WebSocket.CONNECTING || prev.ws.readyState === WebSocket.OPEN)) return;
    let ws: WebSocket;
    try {
      ws = new WebSocket(url);
    } catch {
      this.schedule(url);
      return;
    }
    const sock: Sock = { url, ws, open: false };
    this.socks.set(url, sock);
    const giveUp = setTimeout(() => {
      if (!sock.open) {
        try {
          ws.close();
        } catch {
          /* ignore */
        }
      }
    }, 8000);
    ws.onopen = () => {
      clearTimeout(giveUp);
      if (this.closed || this.socks.get(url) !== sock) {
        ws.close();
        return;
      }
      sock.open = true;
      const since = Math.floor(Date.now() / 1000) - 4;
      ws.send(JSON.stringify(["REQ", "lane", { kinds: [KIND], "#t": [this.tag], since }]));
      this.noteLane();
      this.ensureTimers();
      this.flush();
      this.hello();
    };
    ws.onmessage = (ev) => {
      if (this.socks.get(url) !== sock) return;
      this.onFrame(typeof ev.data === "string" ? ev.data : "");
    };
    ws.onerror = () => {
      /* close follows */
    };
    ws.onclose = () => {
      clearTimeout(giveUp);
      if (this.socks.get(url) !== sock) return;
      sock.open = false;
      sock.ws = null;
      this.noteLane();
      this.schedule(url);
    };
  }

  private schedule(url: string): void {
    if (this.closed) return;
    setTimeout(() => this.connect(url), 900);
  }

  private ensureTimers(): void {
    if (this.hiTimer) return;
    this.hiTimer = setInterval(() => this.hello(), HI_MS);
    this.dropTimer = setInterval(() => this.prune(), 1000);
  }

  private noteLane(): void {
    const ok = this.live() > 0;
    if (ok === this.signaled) return;
    this.signaled = ok;
    this.opts.onSignaling?.(ok);
  }

  private hello(): void {
    this.publish({ t: "hi", id: this.opts.selfId, name: this.opts.name, n: Date.now() });
  }

  private publish(msg: LaneMsg, fanout: "all" | "one" = "all"): void {
    if (this.closed && msg.t !== "bye") return;
    const event = this.sign(JSON.stringify(msg));
    const frame = JSON.stringify(["EVENT", event]);
    const open = [...this.socks.values()].filter((sock) => sock.open && sock.ws);
    const targets =
      fanout === "one" && open.length > 0 ? [open[this.relayCursor++ % open.length]!] : open;
    for (const sock of targets) {
      try {
        sock.ws?.send(frame);
      } catch {
        /* next snapshot retries */
      }
    }
  }

  private sign(content: string): {
    id: string;
    pubkey: string;
    created_at: number;
    kind: number;
    tags: string[][];
    content: string;
    sig: string;
  } {
    const created_at = Math.floor(Date.now() / 1000);
    const tags = [["t", this.tag]];
    const id = bytesToHex(sha256(utf8ToBytes(JSON.stringify([0, this.pub, created_at, KIND, tags, content]))));
    const sig = bytesToHex(schnorr.sign(hexToBytes(id), this.priv));
    return { id, pubkey: this.pub, created_at, kind: KIND, tags, content, sig };
  }

  private flush(): void {
    for (const ev of this.pendingEvents) this.publish({ t: "ev", id: this.opts.selfId, d: ev });
    this.pendingEvents = [];
    if (this.pendingState !== undefined) {
      const payload = this.pendingState;
      this.pendingState = undefined;
      this.publish({ t: "st", id: this.opts.selfId, d: payload }, "one");
    }
  }

  private onFrame(raw: string): void {
    if (!raw) return;
    let msg: unknown;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    if (!Array.isArray(msg) || msg[0] !== "EVENT") return;
    const ev = (
      typeof msg[1] === "string" ? msg[2] : msg[1]
    ) as { id?: string; content?: string; pubkey?: string } | undefined;
    if (!ev?.id || ev.pubkey === this.pub || typeof ev.content !== "string") return;
    if (this.seen.has(ev.id)) return;
    this.seen.add(ev.id);
    this.seenOrder.push(ev.id);
    if (this.seenOrder.length > 500) {
      const old = this.seenOrder.shift();
      if (old) this.seen.delete(old);
    }
    let body: LaneMsg;
    try {
      body = JSON.parse(ev.content) as LaneMsg;
    } catch {
      return;
    }
    this.onMsg(body);
  }

  private onMsg(msg: LaneMsg): void {
    if (!msg || typeof msg !== "object" || !("id" in msg) || msg.id === this.opts.selfId) return;
    if (msg.t === "hi") {
      this.touch(msg.id, msg.name);
      this.publish({ t: "pong", id: this.opts.selfId, to: msg.id, n: msg.n });
      return;
    }
    if (msg.t === "pong") {
      if (msg.to !== this.opts.selfId) return;
      const rtt = Math.max(0, Math.min(9999, Date.now() - msg.n));
      const row = this.remotes.get(msg.id);
      if (row) row.rtt = rtt;
      else this.remotes.set(msg.id, { name: "", seen: Date.now(), rtt });
      this.emit();
      return;
    }
    if (msg.t === "bye") {
      if (this.remotes.delete(msg.id)) this.emit();
      return;
    }
    if (msg.t === "ev" || msg.t === "st") {
      this.touch(msg.id, this.remotes.get(msg.id)?.name ?? "");
      this.opts.onMessage?.(msg.id, msg.d);
    }
  }

  private touch(id: string, name: string): void {
    const row = this.remotes.get(id);
    if (row) {
      row.seen = Date.now();
      if (name) row.name = name;
    } else {
      this.remotes.set(id, { name, seen: Date.now(), rtt: null });
    }
    this.emit();
  }

  private prune(): void {
    const now = Date.now();
    let changed = false;
    for (const [id, row] of this.remotes) {
      if (now - row.seen > DROP_MS) {
        this.remotes.delete(id);
        changed = true;
      }
    }
    if (changed) this.emit();
  }

  private emit(): void {
    const peers: PeerInfo[] = [...this.remotes.entries()].map(([id, row]) => ({
      id,
      name: row.name,
      connectionState: "connected",
      candidateType: null,
      rttMs: row.rtt,
    }));
    const fingerprint = JSON.stringify(peers.map((p) => [p.id, p.name, p.rttMs]));
    if (fingerprint === this.fingerprint) return;
    this.fingerprint = fingerprint;
    this.opts.onPeersChanged?.(peers);
  }
}
