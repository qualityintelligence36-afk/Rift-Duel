import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "../styles.css?url";

const APP_NAME = "Rift Duel";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover",
      },
      { title: APP_NAME },
      { name: "theme-color", content: "#07090d" },
      {
        name: "description",
        content: "Arcade 1v1 spacecraft duel. You hold the bottom of the screen. So do they.",
      },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Oxanium:wght@500;600;700&family=Sora:wght@400;500;600&display=swap",
      },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: () => (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        {import.meta.env.DEV ? (
          <script
            dangerouslySetInnerHTML={{
              __html:
                "window.__controlsTest=window.__controlsTest||{keys:[],touched:false,getYaw:function(){return 0},getSpeed:function(){return 0},setKeys:function(c){this.keys=c||[];this.touched=true}};document.addEventListener('click',function(e){var el=e.target&&e.target.closest&&e.target.closest('[data-rift=go]');if(el)window.__riftBoot=true},true);",
            }}
          />
        ) : null}
        <AuthProvider>
          <Outlet />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
