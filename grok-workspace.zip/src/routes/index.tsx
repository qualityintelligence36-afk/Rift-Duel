import { createFileRoute } from "@tanstack/react-router";
import { RiftApp } from "@/components/rift-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <RiftApp />;
}
