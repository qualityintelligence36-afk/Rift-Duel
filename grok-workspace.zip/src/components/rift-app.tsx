import { useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { unlockAudio } from "@/game/audio";
import { FRAGS_TO_WIN } from "@/game/math";
import { MAPS } from "@/game/maps";
import { INITIAL_HUD, RiftSession, type Hud } from "@/game/session";

function clearRiftQuery(): void {
  const url = new URL(window.location.href);
  if (!url.searchParams.has("rift")) return;
  url.searchParams.delete("rift");
  window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
}

export function RiftApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<RiftSession | null>(null);
  const [hud, setHud] = useState<Hud>(INITIAL_HUD);
  const [name, setName] = useState("YOU");
  const [touch, setTouch] = useState(false);
  const [live, setLive] = useState(false);
  const [code, setCode] = useState("");

  useLayoutEffect(() => {
    setLive(true);
    const saved = localStorage.getItem("rift-duel-name");
    if (saved && saved.toUpperCase() !== "PILOT") setName(saved.slice(0, 12));
    const canvas = canvasRef.current;
    if (!canvas) return;
    const session = new RiftSession(canvas, setHud);
    sessionRef.current = session;
    session.start();
    clearRiftQuery();
    const unlock = () => unlockAudio();
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("keydown", unlock);
    const mq = window.matchMedia("(pointer: coarse)");
    const apply = () => setTouch(mq.matches || window.innerWidth < 840);
    apply();
    mq.addEventListener("change", apply);
    window.addEventListener("resize", apply);
    return () => {
      session.dispose();
      sessionRef.current = null;
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
      mq.removeEventListener("change", apply);
      window.removeEventListener("resize", apply);
    };
  }, []);

  const playing = hud.phase === "play" || hud.phase === "over";

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg select-none">
      <canvas ref={canvasRef} className="absolute inset-0 z-0 h-full w-full touch-none" />
      <div className="vignette pointer-events-none absolute inset-0" data-sky={hud.map} />

      {hud.phase === "title" ? (
        <Center>
          <p className="font-display text-xs font-semibold tracking-widest text-accent">ARCADE LANE</p>
          <h1 className="mt-2 font-display text-5xl font-semibold tracking-wide text-fg">Rift Duel</h1>
          <p className="mt-3 text-sm leading-relaxed text-muted">Don't let your problems Win. get Busy!</p>
          <MapPick map={hud.map} onPick={(id) => sessionRef.current?.setMap(id)} />
          {live ? (
            <Field label="Callsign" value={name} onChange={setName} maxLength={12} />
          ) : (
            <div className="mt-4 h-[4.75rem]" />
          )}
          <button
            type="button"
            data-rift="go"
            className="relative z-20 mt-4 h-12 w-full bg-primary font-display text-base font-semibold tracking-wide text-bg"
            onClick={() => sessionRef.current?.startSolo(name)}
          >
            Start
          </button>
          <p className="mt-1 text-center text-xs text-muted">Against Your Problem. It's not easy.</p>
          <button
            type="button"
            className="mt-3 h-11 w-full bg-accent font-display text-sm font-semibold tracking-wide text-bg"
            onClick={() => sessionRef.current?.host(makeCode(), name)}
          >
            Create room
          </button>
          <Field label="Room code" value={code} onChange={setCode} maxLength={4} wide />
          <button
            type="button"
            className="mt-3 h-11 w-full border border-accent font-display text-sm font-semibold tracking-wide text-accent"
            onClick={() => sessionRef.current?.join(code, name)}
          >
            Join room
          </button>
          {hud.phase === "title" && hud.status ? (
            <p className="mt-2 text-center text-xs text-muted">{hud.status}</p>
          ) : null}
          {hud.wardenWins > 0 ? (
            <p className="mt-3 text-center text-xs text-muted">Problems down {hud.wardenWins}</p>
          ) : null}
        </Center>
      ) : null}

      {hud.phase === "waiting" ? (
        <Center>
          <p className="font-display text-xs font-semibold tracking-widest text-accent">
            {hud.link === "lost" ? "RECONNECTING" : hud.status.startsWith("Connecting") ? "CONNECTING" : "IN ROOM"}
          </p>
          <p className="mt-3 text-center font-display text-5xl font-semibold tracking-[0.28em] text-fg">{hud.room}</p>
          <p className="mt-3 text-center text-sm leading-relaxed text-muted">{hud.status}</p>
          <p className="mt-2 text-center text-xs text-muted">Both phones open this same page. Different Wi-Fi is fine.</p>
          <button
            type="button"
            className="mt-5 h-11 w-full border border-border font-display text-sm font-semibold text-fg"
            onClick={() => sessionRef.current?.leave()}
          >
            Back
          </button>
        </Center>
      ) : null}

      {hud.countdown > 0 ? (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <p className="font-display text-8xl font-semibold text-fg">{hud.countdown}</p>
        </div>
      ) : null}

      {playing ? (
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3">
          <Score
            name={hud.youName}
            frags={hud.youFrags}
            hp={hud.youHp}
            tone="primary"
            align="start"
          />
          <div className="pointer-events-auto flex flex-col items-center gap-2 pt-1">
            <p className="font-display text-xs tracking-widest text-muted">FIRST TO {FRAGS_TO_WIN}</p>
            <p className="font-display text-xs tracking-widest text-accent">
              {MAPS.find((m) => m.id === hud.map)?.name ?? "Night"}
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                className="h-11 border border-border bg-surface px-3 font-display text-xs font-semibold text-fg"
                onClick={() => {
                  clearRiftQuery();
                  sessionRef.current?.leave();
                }}
              >
                Bay
              </button>
              <button
                type="button"
                aria-label={hud.muted ? "Unmute" : "Mute"}
                className="flex h-11 w-11 items-center justify-center border border-border bg-surface text-fg"
                onClick={() => sessionRef.current?.toggleMute()}
              >
                {hud.muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
              </button>
            </div>
          </div>
          <Score
            name={hud.themName}
            frags={hud.themFrags}
            hp={hud.themHp}
            tone="accent"
            align="end"
          />
        </div>
      ) : null}

      {hud.phase === "play" && hud.banner ? (
        <p className="pointer-events-none absolute top-28 left-1/2 -translate-x-1/2 font-display text-2xl font-semibold tracking-widest text-fg">
          {hud.banner}
        </p>
      ) : null}

      {hud.phase === "play" ? (
        <div className="pointer-events-none absolute top-24 left-3 flex gap-2">
          {hud.rapid ? <Chip>RAPID</Chip> : null}
          {hud.spread ? <Chip>SPREAD</Chip> : null}
          {hud.shield ? <Chip>SHIELD</Chip> : null}
        </div>
      ) : null}

      {hud.phase === "play" && !touch ? (
        <p className="pointer-events-none absolute bottom-4 left-1/2 -translate-x-1/2 text-center text-xs text-muted">
          A D slide · W S push · Space fire · Shift shield
        </p>
      ) : null}

      {hud.phase === "play" && hud.net ? (
        <p className="pointer-events-none absolute right-3 bottom-4 font-display text-xs text-muted">
          {hud.link === "live" && hud.rtt !== null
            ? `${hud.rtt} ms`
            : hud.link === "live"
              ? "LIVE"
              : hud.link === "lost"
                ? "RECONNECTING"
                : "WAITING"}
        </p>
      ) : null}

      {hud.phase === "over" ? (
        <Center pin="center">
          <p className="font-display text-xs tracking-widest text-accent">
            {hud.winner === "you" ? "YOU HOLD THE RIFT" : "RIFT LOST"}
          </p>
          <h2 className="mt-2 font-display text-4xl font-semibold text-fg">
            {hud.winner === "you" ? "Lane clear" : "Lane lost"}
          </h2>
          <p className="mt-2 font-display text-2xl text-fg">
            <span className="text-primary">{hud.youFrags}</span>
            <span className="text-muted"> — </span>
            <span className="text-accent">{hud.themFrags}</span>
          </p>
          <button
            type="button"
            className="mt-5 h-12 w-full bg-primary font-display text-base font-semibold text-bg"
            onClick={() => sessionRef.current?.rematch()}
          >
            Rematch
          </button>
          <button
            type="button"
            className="mt-3 h-11 w-full text-sm text-muted"
            onClick={() => {
              clearRiftQuery();
              sessionRef.current?.leave();
            }}
          >
            Back to bay
          </button>
        </Center>
      ) : null}

      {touch && hud.phase === "play" ? (
        <div className="dock pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between px-4">
          <div className="pointer-events-auto">
            <Stick
              onChange={(x, y, active) => sessionRef.current?.setStick(x, y, active)}
            />
          </div>
          <div className="pointer-events-auto flex flex-col items-end gap-3">
            <button
              type="button"
              className={
                hud.shield
                  ? "relative h-12 w-24 overflow-hidden border border-accent bg-accent font-display text-xs font-semibold text-bg"
                  : hud.shieldCd > 0
                    ? "relative h-12 w-24 overflow-hidden border border-border bg-surface font-display text-xs font-semibold text-muted"
                    : "relative h-12 w-24 overflow-hidden bg-accent font-display text-xs font-semibold text-bg"
              }
              onPointerDown={(e) => {
                e.preventDefault();
                e.currentTarget.setPointerCapture(e.pointerId);
                sessionRef.current?.setBoost(true);
              }}
              onPointerUp={() => sessionRef.current?.setBoost(false)}
              onPointerCancel={() => sessionRef.current?.setBoost(false)}
            >
              {hud.shieldCd > 0 && !hud.shield ? (
                <span
                  className="absolute inset-y-0 left-0 bg-accent/30"
                  style={{ width: `${Math.round((1 - hud.shieldCd) * 100)}%` }}
                />
              ) : null}
              <span className="relative">{hud.shield ? "Up" : hud.shieldCd > 0 ? "Regen" : "Shield"}</span>
            </button>
            <button
              type="button"
              className="h-20 w-20 bg-primary font-display text-sm font-semibold text-bg"
              onPointerDown={(e) => {
                e.preventDefault();
                e.currentTarget.setPointerCapture(e.pointerId);
                sessionRef.current?.setFire(true);
              }}
              onPointerUp={() => sessionRef.current?.setFire(false)}
              onPointerCancel={() => sessionRef.current?.setFire(false)}
            >
              Fire
            </button>
          </div>
        </div>
      ) : null}
    </main>
  );
}

function makeCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 4; i += 1) code += alphabet[Math.floor(Math.random() * alphabet.length)];
  return code;
}

function Center({ children, pin = "top" }: { children: ReactNode; pin?: "top" | "center" }) {
  const place = pin === "center" ? "items-center" : "items-start pt-4 sm:items-center sm:pt-4";
  return (
    <div className={`pointer-events-none absolute inset-0 z-10 flex justify-center p-4 ${place}`}>
      <section className="pointer-events-auto max-h-dvh w-full max-w-md overflow-y-auto border border-border bg-surface p-5">{children}</section>
    </div>
  );
}

function MapPick({ map, onPick }: { map: Hud["map"]; onPick: (id: Hud["map"]) => void }) {
  const current = MAPS.find((m) => m.id === map) ?? MAPS[0];
  return (
    <div className="mt-4">
      <p className="text-xs font-medium tracking-widest text-muted uppercase">Map</p>
      <div className="mt-1 grid grid-cols-3 gap-2">
        {MAPS.map((m) => (
          <button
            key={m.id}
            type="button"
            className={
              m.id === map
                ? "h-11 border border-accent bg-bg px-1 font-display text-[11px] font-semibold text-accent"
                : "h-11 border border-border bg-bg px-1 font-display text-[11px] font-semibold text-muted"
            }
            onClick={() => onPick(m.id)}
          >
            {m.name}
          </button>
        ))}
      </div>
      <p className="mt-2 text-xs text-muted">{current.blurb}</p>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  maxLength,
  wide,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  maxLength: number;
  wide?: boolean;
}) {
  return (
    <label className="mt-4 block">
      <span className="text-xs font-medium tracking-widest text-muted uppercase">{label}</span>
      <input
        value={value}
        maxLength={maxLength}
        autoCapitalize={wide ? "characters" : "words"}
        autoComplete="off"
        spellCheck={false}
        onChange={(e) => onChange(e.target.value)}
        className={`mt-1 h-12 w-full border border-border bg-bg px-3 text-fg outline-none select-text focus:border-accent ${wide ? "font-display text-2xl tracking-widest" : "text-base"}`}
      />
    </label>
  );
}

function Score({
  name,
  frags,
  hp,
  tone,
  align,
}: {
  name: string;
  frags: number;
  hp: number;
  tone: "primary" | "accent";
  align: "start" | "end";
}) {
  const bar = tone === "primary" ? "bg-primary" : "bg-accent";
  const num = tone === "primary" ? "text-primary" : "text-accent";
  return (
    <div className={`max-w-[7.2rem] ${align === "end" ? "text-right" : "text-left"}`}>
      <p className="text-xs leading-tight tracking-wide text-muted">{name}</p>
      <p className={`font-display text-3xl font-semibold ${num}`}>{frags}</p>
      <div className={`mt-1 flex gap-1 ${align === "end" ? "justify-end" : ""}`}>
        {Array.from({ length: FRAGS_TO_WIN }, (_, i) => (
          <span key={i} className={`h-1.5 w-3 ${i < frags ? bar : "bg-border"}`} />
        ))}
      </div>
      <div className="mt-2 h-1.5 w-full bg-border">
        <div className={`h-full ${bar}`} style={{ width: `${Math.max(0, Math.min(100, hp))}%` }} />
      </div>
    </div>
  );
}

function Chip({ children }: { children: ReactNode }) {
  return (
    <span className="border border-accent bg-bg px-2 py-1 font-display text-xs font-semibold tracking-widest text-accent">
      {children}
    </span>
  );
}

function Stick({ onChange }: { onChange: (x: number, y: number, active: boolean) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  function move(clientX: number, clientY: number) {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const max = rect.width * 0.34;
    let x = (clientX - (rect.left + rect.width / 2)) / max;
    let y = -(clientY - (rect.top + rect.height / 2)) / max;
    const mag = Math.hypot(x, y);
    if (mag > 1) {
      x /= mag;
      y /= mag;
    }
    setKnob({ x: x * max, y: -y * max });
    onChange(x, y, true);
  }

  function release() {
    setKnob({ x: 0, y: 0 });
    onChange(0, 0, false);
  }

  return (
    <div
      ref={ref}
      className="relative h-32 w-32 touch-none rounded-full border border-border bg-bg/80"
      onPointerDown={(e) => {
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        move(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) move(e.clientX, e.clientY);
      }}
      onPointerUp={release}
      onPointerCancel={release}
    >
      <span
        className="absolute top-1/2 left-1/2 h-12 w-12 rounded-full bg-primary"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}
