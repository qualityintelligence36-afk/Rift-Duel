import { Room, type Client } from "colyseus";
import { Pilot, RiftState } from "./state.ts";

const CODES = new Set<string>();

function cleanCode(raw: unknown): string {
  return String(raw ?? "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .slice(0, 4);
}

function cleanName(raw: unknown): string {
  const s = String(raw ?? "")
    .replace(/[^a-zA-Z0-9 ]/g, "")
    .trim()
    .slice(0, 12);
  return s || "YOU";
}

function num(raw: unknown, fallback = 0): number {
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

type StateMsg = {
  x?: number;
  z?: number;
  vx?: number;
  vz?: number;
  n?: number;
  hp?: number;
  a?: number;
  fr?: number;
  de?: number;
  sh?: number;
  rp?: number;
  sp?: number;
  seq?: number;
};

export class RiftRoom extends Room {
  state = new RiftState();
  maxClients = 2;

  onCreate(options: { code?: string; map?: string }): void {
    const code = cleanCode(options?.code);
    if (!/^[A-Z0-9]{4}$/.test(code)) throw new Error("Code needs 4 letters");
    if (CODES.has(code)) throw new Error("That code is already in use");
    CODES.add(code);
    this.state.code = code;
    const map = String(options?.map ?? "night").slice(0, 16);
    this.state.map = map || "night";
    this.setSeatReservationTime(20);
    this.setPatchRate(50);

    this.onMessage("st", (client, payload: StateMsg) => {
      const pilot = this.state.pilots.get(client.sessionId);
      if (pilot && payload && typeof payload === "object") {
        pilot.x = num(payload.x);
        pilot.z = num(payload.z);
        pilot.vx = num(payload.vx);
        pilot.vz = num(payload.vz);
        pilot.nose = num(payload.n);
        pilot.hp = num(payload.hp, 100);
        pilot.alive = payload.a === 0 ? 0 : 1;
        pilot.frags = num(payload.fr);
        pilot.deaths = num(payload.de);
        pilot.shield = num(payload.sh);
        pilot.rapid = num(payload.rp);
        pilot.spread = num(payload.sp);
        pilot.seq = num(payload.seq);
      }
      this.broadcast("st", payload, { except: client });
    });

    this.onMessage("ev", (client, payload: unknown) => {
      this.broadcast("ev", payload, { except: client });
    });

    this.onMessage("ping", (client, sent: unknown) => {
      client.send("pong", sent);
    });

    this.onMessage("hello", (client) => {
      client.send("ev", { k: "mp", m: this.state.map, e: `map:${this.state.code}:${client.sessionId}` });
      this.pushRoster();
    });
  }

  onJoin(client: Client, options: { name?: string }): void {
    const pilot = new Pilot();
    pilot.name = cleanName(options?.name);
    this.state.pilots.set(client.sessionId, pilot);
    this.pushRoster();
    client.send("ev", { k: "mp", m: this.state.map, e: `map:${this.state.code}` });
  }

  async onLeave(client: Client, consented: boolean): Promise<void> {
    if (!consented) {
      try {
        await this.allowReconnection(client, 30);
        this.pushRoster();
        return;
      } catch {
        /* reservation expired */
      }
    }
    this.state.pilots.delete(client.sessionId);
    this.pushRoster();
  }

  onDispose(): void {
    CODES.delete(this.state.code);
  }

  private pushRoster(): void {
    const roster = [...this.state.pilots.entries()].map(([id, pilot]) => ({
      id,
      name: pilot.name,
    }));
    this.broadcast("roster", roster);
  }
}
