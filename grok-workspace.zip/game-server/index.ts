import http from "node:http";
import { Server } from "colyseus";
import { WebSocketTransport } from "@colyseus/ws-transport";
import { RiftRoom } from "./rift-room.ts";

const port = Number(process.env.PORT || 2567);
const host = process.env.GAME_HOST || "0.0.0.0";

const httpServer = http.createServer((req, res) => {
  const path = (req.url ?? "").split("?")[0];
  res.setHeader("access-control-allow-origin", "*");
  res.setHeader("access-control-allow-methods", "GET,POST,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type");
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }
  if (path === "/health") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ ok: true, game: "rift" }));
    return;
  }
  res.writeHead(426, { "content-type": "text/plain" });
  res.end("rift game server");
});

const gameServer = new Server({
  transport: new WebSocketTransport({ server: httpServer }),
});

gameServer.define("rift", RiftRoom).filterBy(["code"]);

gameServer
  .listen(port, host)
  .then(() => {
    console.log(`[rift] Colyseus listening on ${host}:${port}`);
  })
  .catch((err: unknown) => {
    console.error("[rift] server failed", err);
    process.exit(1);
  });
