import { schema } from "@colyseus/schema";

/** Authoritative mirror of one pilot. Gameplay still travels as `st` / `ev` messages. */
export const Pilot = schema({
  name: { type: "string", default: "" },
  x: { type: "float32", default: 0 },
  z: { type: "float32", default: 0 },
  vx: { type: "float32", default: 0 },
  vz: { type: "float32", default: 0 },
  nose: { type: "float32", default: 0 },
  hp: { type: "float32", default: 100 },
  alive: { type: "uint8", default: 1 },
  frags: { type: "uint8", default: 0 },
  deaths: { type: "uint8", default: 0 },
  shield: { type: "float32", default: 0 },
  rapid: { type: "float32", default: 0 },
  spread: { type: "float32", default: 0 },
  seq: { type: "uint32", default: 0 },
});

export const RiftState = schema({
  code: { type: "string", default: "" },
  map: { type: "string", default: "night" },
  pilots: { map: Pilot },
});
