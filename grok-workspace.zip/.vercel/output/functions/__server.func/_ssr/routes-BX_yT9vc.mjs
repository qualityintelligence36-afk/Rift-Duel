import { o as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Volume2, t as VolumeX } from "../_libs/lucide-react.mjs";
import { n as MatchMakeError, r as getStateCallbacks, t as Client } from "../_libs/colyseus.js.mjs";
import { A as SphereGeometry, C as PointLight, D as RingGeometry, E as RepeatWrapping, M as Vector3, O as SRGBColorSpace, S as PlaneGeometry, T as PointsMaterial, _ as Mesh, a as CanvasTexture, b as OctahedronGeometry, c as CylinderGeometry, d as FogExp2, f as Group, g as Matrix4, h as InstancedMesh, i as BufferGeometry, j as TorusGeometry, k as Scene, l as DirectionalLight, m as IcosahedronGeometry, n as BoxGeometry, o as Color, p as HemisphereLight, r as BufferAttribute, s as ConeGeometry, t as WebGLRenderer, u as DynamicDrawUsage, v as MeshBasicMaterial, w as Points, x as PerspectiveCamera, y as MeshStandardMaterial } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BX_yT9vc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
var master = null;
var music = null;
var muted = false;
var MENU_LEAD = [
	0,
	4,
	7,
	12,
	7,
	4,
	9,
	7,
	5,
	9,
	12,
	9,
	7,
	4,
	2,
	0
];
var MENU_BASS = [
	0,
	-1,
	-5,
	-1,
	5,
	-1,
	7,
	-1,
	9,
	-1,
	5,
	-1,
	7,
	-1,
	0,
	-1
];
var FIGHT_LEAD = [
	0,
	-1,
	7,
	3,
	-1,
	10,
	-1,
	7,
	12,
	-1,
	10,
	8,
	-1,
	7,
	3,
	-1
];
var FIGHT_BASS = [
	0,
	-1,
	0,
	-1,
	7,
	-1,
	5,
	-1,
	3,
	-1,
	5,
	-1,
	7,
	-1,
	0,
	-1
];
var bed = "menu";
var step = 0;
var nextAt = 0;
var timer = 0;
var hat = null;
function context() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return null;
		ctx = new AC({ latencyHint: "interactive" });
		master = ctx.createGain();
		master.gain.value = muted ? 0 : .32;
		master.connect(ctx.destination);
		music = ctx.createGain();
		music.gain.value = .62;
		music.connect(master);
		const n = Math.floor(ctx.sampleRate * .04);
		hat = ctx.createBuffer(1, n, ctx.sampleRate);
		const data = hat.getChannelData(0);
		for (let i = 0; i < n; i += 1) data[i] = (Math.random() * 2 - 1) * (1 - i / n);
	}
	return ctx;
}
/** Call from a pointer/key handler so iOS actually makes noise. */
function unlockAudio() {
	const audio = context();
	if (audio && audio.state === "suspended") audio.resume();
	ensureLoop();
}
function setBed(next) {
	if (next === bed && timer) return;
	bed = next;
	step = 0;
	if (ctx) nextAt = ctx.currentTime + .03;
	if (music && ctx) music.gain.setTargetAtTime(next === "menu" ? .7 : .48, ctx.currentTime, .06);
	if (ctx) ensureLoop();
}
function setMuted(next) {
	muted = next;
	if (!master || !ctx) return;
	master.gain.setTargetAtTime(next ? 0 : .32, ctx.currentTime, .02);
}
function tone(freq, dur, type, gain, slideTo) {
	const audio = context();
	if (!audio || !master || muted) return;
	const osc = audio.createOscillator();
	const g = audio.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, audio.currentTime);
	if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(40, slideTo), audio.currentTime + dur);
	g.gain.setValueAtTime(gain, audio.currentTime);
	g.gain.exponentialRampToValueAtTime(1e-4, audio.currentTime + dur);
	osc.connect(g);
	g.connect(master);
	osc.start();
	osc.stop(audio.currentTime + dur + .02);
	osc.onended = () => {
		osc.disconnect();
		g.disconnect();
	};
}
function noise(dur, gain, fromHz, toHz, kind) {
	const audio = context();
	if (!audio || !master || muted) return;
	const length = Math.floor(audio.sampleRate * dur);
	const buffer = audio.createBuffer(1, length, audio.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < length; i += 1) data[i] = Math.random() * 2 - 1;
	const src = audio.createBufferSource();
	src.buffer = buffer;
	const filter = audio.createBiquadFilter();
	filter.type = kind;
	filter.Q.value = kind === "bandpass" ? 3.2 : .7;
	filter.frequency.setValueAtTime(fromHz, audio.currentTime);
	filter.frequency.exponentialRampToValueAtTime(Math.max(40, toHz), audio.currentTime + dur);
	const g = audio.createGain();
	g.gain.setValueAtTime(gain, audio.currentTime);
	g.gain.exponentialRampToValueAtTime(1e-4, audio.currentTime + dur);
	src.connect(filter);
	filter.connect(g);
	g.connect(master);
	src.start();
	src.onended = () => {
		src.disconnect();
		filter.disconnect();
		g.disconnect();
	};
}
function playFx(kind) {
	const jitter = .94 + Math.random() * .12;
	if (kind === "shot") {
		tone(720 * jitter, .07, "square", .08, 280);
		tone(180 * jitter, .05, "sine", .06);
	} else if (kind === "hit") {
		noise(.2, .42, 1600, 140, "bandpass");
		tone(160 * jitter, .22, "sawtooth", .12, 42);
		tone(620 * jitter, .08, "square", .07, 140);
		tone(240, .16, "triangle", .08, 70);
	} else if (kind === "boom") {
		noise(.38, .28, 900, 80, "lowpass");
		tone(90, .32, "sawtooth", .08, 40);
	} else if (kind === "dash") tone(220, .12, "sawtooth", .06, 640);
	else if (kind === "pick") {
		tone(523, .08, "square", .07);
		tone(659, .09, "square", .06);
		tone(784, .12, "square", .06);
	} else if (kind === "shield") {
		noise(.18, .16, 400, 1400, "bandpass");
		tone(280, .22, "sine", .08, 880);
		tone(520, .16, "triangle", .05, 1240);
	} else if (kind === "clang") {
		noise(.07, .2, 2200, 700, "bandpass");
		tone(1180 * jitter, .09, "square", .07, 420);
		tone(1860 * jitter, .12, "sine", .05, 640);
	} else if (kind === "chip") {
		noise(.1, .22, 900, 160, "lowpass");
		tone(130 * jitter, .1, "square", .06, 55);
	} else if (kind === "reform") {
		tone(196, .1, "sine", .05, 392);
		tone(294, .14, "triangle", .04, 588);
	}
}
function resumeAudio() {
	if (ctx && ctx.state === "suspended") ctx.resume();
	if (ctx) ensureLoop();
}
function hz(root, semi) {
	return root * 2 ** (semi / 12);
}
function blip(when, freq, dur, type, gain) {
	if (!ctx || !music || freq <= 0) return;
	const osc = ctx.createOscillator();
	const g = ctx.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, when);
	g.gain.setValueAtTime(1e-4, when);
	g.gain.exponentialRampToValueAtTime(gain, when + .008);
	g.gain.exponentialRampToValueAtTime(1e-4, when + Math.max(.02, dur));
	osc.connect(g);
	g.connect(music);
	osc.start(when);
	osc.stop(when + dur + .02);
	osc.onended = () => {
		osc.disconnect();
		g.disconnect();
	};
}
function tick(when, gain) {
	if (!ctx || !music || !hat) return;
	const src = ctx.createBufferSource();
	src.buffer = hat;
	const filter = ctx.createBiquadFilter();
	filter.type = "highpass";
	filter.frequency.value = 1800;
	const g = ctx.createGain();
	g.gain.setValueAtTime(gain, when);
	src.connect(filter);
	filter.connect(g);
	g.connect(music);
	src.start(when);
	src.onended = () => {
		src.disconnect();
		filter.disconnect();
		g.disconnect();
	};
}
function ensureLoop() {
	if (!ctx) return;
	if (!timer) {
		nextAt = ctx.currentTime + .05;
		timer = window.setInterval(pump, 50);
		ctx.addEventListener("statechange", () => {
			if (ctx?.state === "running") pump();
		});
	}
}
function pump() {
	if (!ctx || !music) return;
	if (muted || ctx.state !== "running") {
		nextAt = 0;
		return;
	}
	if (nextAt < ctx.currentTime) nextAt = ctx.currentTime + .04;
	const stepDur = bed === "menu" ? 60 / 116 / 2 : 60 / 126 / 2;
	const horizon = ctx.currentTime + .12;
	while (nextAt < horizon) {
		const i = step % 16;
		if (bed === "menu") {
			const lead = MENU_LEAD[i];
			const bass = MENU_BASS[i];
			if (lead >= 0) blip(nextAt, hz(523.25, lead), stepDur * .42, "square", .07);
			if (lead >= 0) blip(nextAt, hz(523.25, lead - 12), stepDur * .36, "triangle", .04);
			if (bass >= 0) blip(nextAt, hz(130.81, bass), stepDur * .7, "square", .05);
			if (i % 4 === 0) blip(nextAt, 78, .09, "sine", .04);
		} else {
			const lead = FIGHT_LEAD[i];
			const bass = FIGHT_BASS[i];
			if (lead >= 0) blip(nextAt, hz(440, lead), stepDur * .28, "square", .05);
			if (bass >= 0) blip(nextAt, hz(110, bass), stepDur * .55, "triangle", .055);
			if (i % 4 === 2) tick(nextAt, .03);
		}
		step += 1;
		nextAt += stepDur;
	}
}
var ARENA_X = 7.55;
var Z_NEAR = .65;
var Z_FAR = 14.7;
var SHIP_R = .7;
var BOLT_R = .16;
var BOLT_LIFE = 1.7;
var FIRE_CD = .2;
var RAPID_CD = .095;
var DRAG = 5.4;
var MAX_SPEED = 12.5;
var SHIELD_CD = 6.4;
var ROCK_RESPAWN = 6.5;
var NOSE_MAX = .74;
var ASTS = [
	{
		x: 0,
		z: 0,
		r: .98,
		spin: .45
	},
	{
		x: 0,
		z: 0,
		r: .74,
		spin: -.7
	},
	{
		x: 0,
		z: 0,
		r: 1.08,
		spin: .55
	},
	{
		x: 0,
		z: 0,
		r: .82,
		spin: -.32
	}
];
function nowSec() {
	return Date.now() / 1e3;
}
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function asteroids(t) {
	for (let i = 0; i < ASTS.length; i += 1) {
		const phase = i * 1.65;
		ASTS[i].x = Math.sin(t * (.28 + i * .04) + phase) * (5.6 - i * .22);
		ASTS[i].z = Math.sin(t * .19 + phase * 1.4) * 1.05;
	}
	return ASTS;
}
function laneForward(side) {
	return side === 1 ? {
		x: 0,
		z: -1
	} : {
		x: 0,
		z: 1
	};
}
function laneRight(side) {
	return side === 1 ? {
		x: 1,
		z: 0
	} : {
		x: -1,
		z: 0
	};
}
/** nose > 0 yaws the guns toward screen-left. */
function aimDir(side, nose) {
	const f = laneForward(side);
	const leftX = -laneRight(side).x;
	const leftZ = -laneRight(side).z;
	const c = Math.cos(nose);
	const s = Math.sin(nose);
	return {
		x: f.x * c + leftX * s,
		z: f.z * c + leftZ * s
	};
}
function clampShip(side, x, z) {
	return {
		x: clamp(x, -7.55, ARENA_X),
		z: side === 1 ? clamp(z, Z_NEAR, Z_FAR) : clamp(z, -14.7, -.65)
	};
}
function spawnFor(side) {
	return {
		x: 0,
		z: side === 1 ? 12.2 : -12.2
	};
}
var MAPS = [
	{
		id: "night",
		name: "Night",
		blurb: "Black glass and a cyan rift.",
		sky: 461069,
		fog: 461069,
		fogDensity: .022,
		hemiSky: 13166300,
		hemiGround: 461069,
		hemi: .55,
		sun: 16052452,
		sunIntensity: 1.35,
		sunPos: [
			6,
			14,
			8
		],
		disc: false,
		discColor: 16052452,
		rift: 3073735,
		riftCore: 14155766,
		riftIntensity: 8,
		floor: "#0c110e",
		grid: "#1a2c24",
		wall: 1185812,
		wallGlow: 1333324,
		wallGlowAmt: .55,
		rock: 2371626,
		rockGlow: 1058848,
		rockGlowAmt: .4,
		stars: 14018268,
		starOpacity: .8
	},
	{
		id: "day1",
		name: "Day 1",
		blurb: "First light. Same corridor, open sky.",
		sky: 9354462,
		fog: 12967149,
		fogDensity: .011,
		hemiSky: 16774879,
		hemiGround: 11569496,
		hemi: 1.25,
		sun: 16769184,
		sunIntensity: 2.35,
		sunPos: [
			10,
			24,
			6
		],
		disc: true,
		discColor: 16773572,
		rift: 15774761,
		riftCore: 16774354,
		riftIntensity: 6,
		floor: "#d5c7aa",
		grid: "#7d705c",
		wall: 14997442,
		wallGlow: 12876338,
		wallGlowAmt: .18,
		rock: 9401172,
		rockGlow: 5913116,
		rockGlowAmt: .22,
		stars: 16777215,
		starOpacity: 0
	},
	{
		id: "dusk",
		name: "Dusk",
		blurb: "Violet glass and a low sun.",
		sky: 1444386,
		fog: 2757688,
		fogDensity: .02,
		hemiSky: 15184127,
		hemiGround: 2756640,
		hemi: .7,
		sun: 16742972,
		sunIntensity: 1.7,
		sunPos: [
			-12,
			6,
			10
		],
		disc: true,
		discColor: 16747082,
		rift: 14969855,
		riftCore: 16766719,
		riftIntensity: 9,
		floor: "#140e1c",
		grid: "#5a3470",
		wall: 1839656,
		wallGlow: 10504916,
		wallGlowAmt: .55,
		rock: 3811914,
		rockGlow: 6959248,
		rockGlowAmt: .45,
		stars: 15784191,
		starOpacity: .9
	},
	{
		id: "snow",
		name: "Christmas",
		blurb: "Snow on the lane. Don't slow down.",
		sky: 10400969,
		fog: 14017775,
		fogDensity: .016,
		hemiSky: 16055295,
		hemiGround: 9085104,
		hemi: 1.15,
		sun: 16774368,
		sunIntensity: 1.9,
		sunPos: [
			4,
			18,
			-8
		],
		disc: true,
		discColor: 16775146,
		rift: 14826299,
		riftCore: 16769162,
		riftIntensity: 7,
		floor: "#e7eef2",
		grid: "#8aa0ad",
		wall: 14016744,
		wallGlow: 12729147,
		wallGlowAmt: .22,
		rock: 16054264,
		rockGlow: 12047556,
		rockGlowAmt: .35,
		stars: 16777215,
		starOpacity: .15
	},
	{
		id: "haunt",
		name: "Halloween",
		blurb: "Ghosts in the fog. It's not easy.",
		sky: 1050648,
		fog: 2363432,
		fogDensity: .028,
		hemiSky: 16757082,
		hemiGround: 1312784,
		hemi: .62,
		sun: 16742938,
		sunIntensity: 1.15,
		sunPos: [
			-8,
			10,
			12
		],
		disc: true,
		discColor: 16762218,
		rift: 16738816,
		riftCore: 16769704,
		riftIntensity: 10,
		floor: "#120c14",
		grid: "#5a2418",
		wall: 1708056,
		wallGlow: 16734738,
		wallGlowAmt: .62,
		rock: 14708768,
		rockGlow: 16756736,
		rockGlowAmt: .55,
		stars: 16765088,
		starOpacity: .55
	},
	{
		id: "rain",
		name: "Water",
		blurb: "Rain on the water. Stay in the lane.",
		sky: 464928,
		fog: 798784,
		fogDensity: .02,
		hemiSky: 12047588,
		hemiGround: 401448,
		hemi: .7,
		sun: 13691124,
		sunIntensity: .85,
		sunPos: [
			2,
			18,
			6
		],
		disc: false,
		discColor: 13691124,
		rift: 4114656,
		riftCore: 14220287,
		riftIntensity: 7,
		floor: "#073848",
		grid: "#1a8aaa",
		wall: 796724,
		wallGlow: 1341592,
		wallGlowAmt: .5,
		rock: 1722968,
		rockGlow: 667712,
		rockGlowAmt: .45,
		stars: 12970228,
		starOpacity: .12
	}
];
function mapById(id) {
	return MAPS.find((m) => m.id === id) ?? MAPS[0];
}
/** Same origin in the preview (proxied to the Colyseus process). Override with VITE_GAME_SERVER. */
function gameServerEndpoint() {
	if (typeof window === "undefined") return "http://127.0.0.1:2567";
	return window.location.origin;
}
function explain(err) {
	const message = err instanceof Error ? err.message : String(err);
	const code = err instanceof MatchMakeError ? err.code : 0;
	if (code === 4211 || code === 4212 || /no rooms|not found/i.test(message)) return "No room with that code. Your friend taps Create room first.";
	if (/already in use/i.test(message)) return "That code is already in use. Create another.";
	if (/4 letters/i.test(message)) return "Code needs 4 letters.";
	if (/full|maxClients|locked/i.test(message)) return "That room is full.";
	if (/failed to fetch|network|econnrefused|offline|reset|timed out/i.test(message)) return "Can't reach the game server. Leave this open — it keeps trying.";
	return message || "The room didn't open.";
}
function shouldRetry(err) {
	const message = err instanceof Error ? err.message : String(err);
	const code = err instanceof MatchMakeError ? err.code : 0;
	if (code === 4211 || code === 4212) return false;
	if (/already in use|4 letters|full|maxClients|locked|no rooms|not found/i.test(message)) return false;
	return true;
}
var ColyseusLink = class {
	opts;
	client = null;
	room = null;
	closed = false;
	pingTimer = 0;
	pingSent = 0;
	rtt = null;
	roster = [];
	token = "";
	constructor(opts) {
		this.opts = opts;
	}
	async start() {
		this.opts.onStatus?.("connecting");
		const endpoint = gameServerEndpoint();
		this.client = new Client(endpoint);
		let last = "Can't reach the game server.";
		while (!this.closed) try {
			const options = {
				code: this.opts.code,
				name: this.opts.name,
				map: this.opts.map
			};
			this.room = this.opts.hosting ? await this.client.create("rift", options) : await this.client.join("rift", options);
			if (this.closed) {
				this.room.leave(true);
				return;
			}
			this.bind(this.room);
			return;
		} catch (err) {
			last = explain(err);
			if (!shouldRetry(err)) break;
			await new Promise((resolve) => setTimeout(resolve, 1e3));
		}
		if (!this.closed) this.opts.onStatus?.("error", last);
	}
	send(data) {
		this.dispatch(data);
	}
	relay(_data) {}
	pushState(data) {
		this.dispatch(data);
	}
	broadcast(_data) {}
	close() {
		this.closed = true;
		if (this.pingTimer) window.clearInterval(this.pingTimer);
		this.pingTimer = 0;
		const room = this.room;
		this.room = null;
		if (room) room.leave(true);
	}
	dispatch(data) {
		const room = this.room;
		if (!room || data == null || typeof data !== "object") return;
		if (data.k === "st") room.send("st", data);
		else room.send("ev", data);
	}
	bind(room) {
		this.token = room.reconnectionToken;
		this.opts.onReady?.(room.sessionId);
		this.opts.onStatus?.("open");
		room.onMessage("roster", (rows) => {
			this.roster = Array.isArray(rows) ? rows : [];
			this.emitPeers("connected");
		});
		room.onMessage("ev", (payload) => {
			const from = this.otherId();
			if (from) this.opts.onMessage?.(from, payload);
		});
		room.onMessage("st", (payload) => {
			const from = this.otherId();
			if (from) this.opts.onMessage?.(from, payload);
		});
		room.onMessage("pong", (sent) => {
			const t = Number(sent);
			if (Number.isFinite(t)) this.rtt = Math.max(0, Date.now() - t);
			this.emitPeers("connected");
		});
		try {
			getStateCallbacks(room)(room.state).pilots.onAdd((_pilot, id) => {
				if (!this.roster.some((row) => row.id === id)) {
					this.roster = [...this.roster, {
						id,
						name: _pilot?.name || ""
					}];
					this.emitPeers("connected");
				}
			});
		} catch {}
		this.pingTimer = window.setInterval(() => {
			if (!this.room) return;
			this.pingSent = Date.now();
			this.room.send("ping", this.pingSent);
		}, 2e3);
		room.send("hello");
		room.onLeave((code) => {
			if (this.closed) return;
			if (this.pingTimer) window.clearInterval(this.pingTimer);
			this.pingTimer = 0;
			if (code === 4e3) return;
			this.restore();
		});
		room.onError((code, message) => {
			if (!this.closed) this.opts.onStatus?.("error", message || `Connection error ${code}`);
		});
	}
	async restore() {
		if (this.closed || !this.client || !this.token) return;
		this.opts.onStatus?.("reconnecting", "Reconnecting…");
		this.emitPeers("connecting");
		try {
			const room = await this.client.reconnect(this.token);
			if (this.closed) {
				room.leave(true);
				return;
			}
			this.room = room;
			this.bind(room);
		} catch {
			if (this.closed) return;
			this.room = null;
			this.opts.onStatus?.("error", "The link dropped. Head back and create the room again.");
			this.emitPeers("failed");
		}
	}
	otherId() {
		const self = this.room?.sessionId;
		return this.roster.find((row) => row.id !== self)?.id ?? null;
	}
	emitPeers(state) {
		const peers = this.roster.map((row) => ({
			id: row.id,
			name: row.name,
			connectionState: state,
			rttMs: row.id === this.room?.sessionId ? null : this.rtt,
			candidateType: null
		}));
		this.opts.onPeers?.(peers);
	}
};
var IDLE_ACTIONS = {
	strafe: 0,
	thrust: 0,
	fire: false,
	boost: false
};
function makeShip(side) {
	const p = spawnFor(side);
	return {
		side,
		x: p.x,
		z: p.z,
		vx: 0,
		vz: 0,
		nose: 0,
		hp: 100,
		alive: true,
		invuln: 0,
		respawn: 0,
		shield: 0,
		rapid: 0,
		spread: 0,
		boostCd: 0,
		fireCd: 0,
		flash: 0,
		hurtCd: 0
	};
}
function freshRocks() {
	return asteroids(0).map(() => ({
		hp: 3,
		max: 3,
		down: 0,
		pop: 0
	}));
}
var Sim = class {
	you = makeShip(1);
	them = makeShip(-1);
	bolts = [];
	power = null;
	rocks = freshRocks();
	frags = 0;
	deaths = 0;
	over = null;
	time = 0;
	nextBolt = 1;
	nextPowerId = 1;
	nextPowerAt = 7;
	fx = [];
	impacts = [];
	events = [];
	authority = true;
	net = false;
	diorama() {
		this.you = makeShip(1);
		this.them = makeShip(-1);
		this.bolts = [];
		this.power = null;
		this.rocks = freshRocks();
		this.frags = 0;
		this.deaths = 0;
		this.over = null;
		this.time = 0;
		this.nextPowerAt = 7;
		this.net = false;
		this.authority = true;
		this.fx = [];
		this.impacts = [];
		this.events = [];
	}
	prepare(side, net, authority) {
		this.diorama();
		this.you = makeShip(side);
		this.them = makeShip(side === 1 ? -1 : 1);
		this.you.invuln = 1.15;
		this.them.invuln = 1.15;
		this.net = net;
		this.authority = authority;
	}
	step(dt, actions) {
		this.fx = [];
		this.impacts = [];
		this.events = [];
		if (this.over) return;
		this.time += dt;
		const themActions = this.net ? IDLE_ACTIONS : this.warden();
		this.integrate(this.you, actions, dt);
		if (!this.net) this.integrate(this.them, themActions, dt);
		this.tick(this.you, dt);
		this.tick(this.them, dt);
		this.shoot(this.you, actions, true, dt);
		if (!this.net) this.shoot(this.them, themActions, false, dt);
		this.advanceBolts(dt);
		this.collide();
		this.bumpRocks();
		this.bumpShips();
		this.powerups();
		this.tickRocks(dt);
		this.respawn(this.you, dt);
		if (!this.net) this.respawn(this.them, dt);
	}
	applyRemote(s) {
		this.them.x = s.x;
		this.them.z = s.z;
		this.them.vx = s.vx;
		this.them.vz = s.vz;
		this.them.nose = s.nose;
		this.them.hp = s.hp;
		this.them.shield = s.shield;
		this.them.rapid = s.rapid;
		this.them.spread = s.spread;
		const wasAlive = this.them.alive;
		this.them.alive = s.alive;
		if (wasAlive && !s.alive) this.them.respawn = 2.2;
		this.deaths = Math.max(this.deaths, s.frags);
		this.frags = Math.max(this.frags, s.deaths);
		this.checkWin();
	}
	ingestShot(id, x, z, dx, dz) {
		if (this.bolts.some((b) => b.owner === "them" && b.id === id)) return false;
		this.bolts.push({
			id,
			owner: "them",
			x,
			z,
			dx,
			dz,
			life: BOLT_LIFE
		});
		return true;
	}
	resolveHit(id) {
		const i = this.bolts.findIndex((b) => b.owner === "you" && b.id === id);
		if (i < 0) return false;
		this.bolts.splice(i, 1);
		return true;
	}
	remoteDown() {
		if (!this.them.alive) return false;
		this.them.alive = false;
		this.them.hp = 0;
		this.them.respawn = 2.2;
		this.frags += 1;
		this.checkWin();
		return true;
	}
	offerPower(power) {
		this.power = power;
		this.nextPowerId = Math.max(this.nextPowerId, power.id + 1);
	}
	remoteTake(id) {
		if (this.power && this.power.id === id) {
			this.power = null;
			this.nextPowerAt = this.time + 10;
		}
	}
	/** One missile hit on a center rock. Returns null if it was already rubble. */
	strike(i) {
		const rock = this.rocks[i];
		if (!rock || rock.down > 0 || rock.hp <= 0) return null;
		const spot = asteroids(nowSec())[i];
		if (!spot) return null;
		rock.hp -= 1;
		if (rock.hp > 0) return {
			kind: "chip",
			x: spot.x,
			z: spot.z
		};
		rock.hp = 0;
		rock.down = ROCK_RESPAWN;
		return {
			kind: "blast",
			x: spot.x,
			z: spot.z
		};
	}
	warden() {
		const ai = this.them;
		const player = this.you;
		if (!ai.alive) return IDLE_ACTIONS;
		let dodge = 0;
		let incoming = false;
		let soonest = 99;
		for (const b of this.bolts) {
			if (b.owner !== "you") continue;
			const vz = b.dz * 27;
			if (Math.abs(vz) < .01) continue;
			const t = (ai.z - b.z) / vz;
			if (t > 0 && t < .92 && t < soonest) {
				const ix = b.x + b.dx * 27 * t;
				if (Math.abs(ix - ai.x) < 2.15) {
					incoming = true;
					soonest = t;
					dodge = (ai.x >= ix ? 1 : -1) * laneRight(ai.side).x;
				}
			}
		}
		const right = laneRight(ai.side).x;
		const lead = player.x + player.vx * .24;
		let strafe = clamp((lead - ai.x) * right * 1.9, -1, 1);
		if (dodge) strafe = clamp(dodge * 1, -1, 1);
		const thrust = clamp(((ai.side === 1 ? 8.6 : -8.6) - ai.z) * laneForward(ai.side).z * .7, -1, 1);
		const aligned = player.alive && Math.abs(lead - ai.x) < 1.05;
		const burst = this.time > .4 && Math.sin(this.time * 7.2) > -.42;
		const boost = incoming && ai.shield <= 0 && ai.boostCd <= 0;
		return {
			strafe,
			thrust,
			fire: aligned && burst && !dodge,
			boost
		};
	}
	integrate(ship, a, dt) {
		if (!ship.alive) return;
		const f = laneForward(ship.side);
		const r = laneRight(ship.side);
		const ax = r.x * a.strafe * 52 + f.x * a.thrust * 40;
		const az = r.z * a.strafe * 52 + f.z * a.thrust * 40;
		ship.vx += ax * dt;
		ship.vz += az * dt;
		const damp = Math.exp(-DRAG * dt);
		ship.vx *= damp;
		ship.vz *= damp;
		const sp = Math.hypot(ship.vx, ship.vz);
		if (sp > 12.5) {
			const s = MAX_SPEED / sp;
			ship.vx *= s;
			ship.vz *= s;
		}
		ship.x += ship.vx * dt;
		ship.z += ship.vz * dt;
		const c = clampShip(ship.side, ship.x, ship.z);
		if (c.x !== ship.x) ship.vx *= -.2;
		if (c.z !== ship.z) ship.vz *= -.2;
		ship.x = c.x;
		ship.z = c.z;
		const targetNose = clamp(-a.strafe, -1, 1) * NOSE_MAX;
		ship.nose += (targetNose - ship.nose) * (1 - Math.exp(-12 * dt));
		if (a.boost && ship.shield <= 0 && ship.boostCd <= 0) {
			ship.shield = 3;
			ship.boostCd = SHIELD_CD;
			this.fx.push("shield");
		}
	}
	tick(ship, dt) {
		ship.invuln = Math.max(0, ship.invuln - dt);
		ship.shield = Math.max(0, ship.shield - dt);
		ship.rapid = Math.max(0, ship.rapid - dt);
		ship.spread = Math.max(0, ship.spread - dt);
		ship.boostCd = Math.max(0, ship.boostCd - dt);
		ship.flash = Math.max(0, ship.flash - dt);
		ship.hurtCd = Math.max(0, ship.hurtCd - dt);
	}
	shoot(ship, a, local, dt) {
		ship.fireCd = Math.max(0, ship.fireCd - dt);
		if (!ship.alive || !a.fire) return;
		const cd = ship.rapid > 0 ? RAPID_CD : FIRE_CD;
		if (ship.fireCd > 0) return;
		ship.fireCd = cd;
		const angles = ship.spread > 0 ? [
			ship.nose - .22,
			ship.nose,
			ship.nose + .22
		] : [ship.nose];
		for (const n of angles) {
			const d = aimDir(ship.side, n);
			const id = this.nextBolt++;
			const x = ship.x + d.x * 1.2;
			const z = ship.z + d.z * 1.2;
			this.bolts.push({
				id,
				owner: local ? "you" : "them",
				x,
				z,
				dx: d.x,
				dz: d.z,
				life: BOLT_LIFE
			});
			if (local) this.events.push({
				t: "shot",
				id,
				x,
				z,
				dx: d.x,
				dz: d.z
			});
		}
		if (local) this.fx.push("shot");
	}
	advanceBolts(dt) {
		for (let i = this.bolts.length - 1; i >= 0; i -= 1) {
			const b = this.bolts[i];
			b.x += b.dx * 27 * dt;
			b.z += b.dz * 27 * dt;
			b.life -= dt;
			if (b.life <= 0 || Math.abs(b.x) > 18 || Math.abs(b.z) > 22) this.bolts.splice(i, 1);
		}
	}
	collide() {
		const rocks = asteroids(nowSec());
		for (let i = this.bolts.length - 1; i >= 0; i -= 1) {
			const b = this.bolts[i];
			let dead = false;
			for (let ri = 0; ri < rocks.length; ri += 1) {
				const rock = rocks[ri];
				const state = this.rocks[ri];
				if (state && state.down > 0) continue;
				const dx = b.x - rock.x;
				const dz = b.z - rock.z;
				const reach = rock.r + BOLT_R;
				if (dx * dx + dz * dz < reach * reach) {
					dead = true;
					if (!this.net || b.owner === "you") {
						const hit = this.strike(ri);
						if (hit?.kind === "chip") this.fx.push("chip");
						if (hit) this.events.push({
							t: hit.kind,
							i: ri,
							x: hit.x,
							z: hit.z
						});
					}
					break;
				}
			}
			if (!dead) {
				const target = b.owner === "you" ? this.them : this.you;
				const dx = b.x - target.x;
				const dz = b.z - target.z;
				const reach = SHIP_R + BOLT_R;
				if (target.alive && target.invuln <= 0 && dx * dx + dz * dz < reach * reach) {
					dead = true;
					if (!(this.net && target === this.them)) this.hurt(target, 20, b.id);
				}
			}
			if (dead) this.bolts.splice(i, 1);
		}
	}
	hurt(ship, dmg, boltId) {
		if (!ship.alive || ship.invuln > 0) return;
		const owner = ship === this.you ? "you" : "them";
		if (ship.shield > 0) {
			ship.flash = .18;
			this.impacts.push({
				owner,
				x: ship.x,
				z: ship.z,
				kind: "clang"
			});
			if (boltId !== null && ship === this.you) this.events.push({
				t: "hit",
				id: boltId
			});
			return;
		}
		ship.hp -= dmg;
		ship.flash = .28;
		if (ship.hp <= 0) {
			ship.hp = 0;
			ship.alive = false;
			ship.respawn = 2.2;
			ship.vx = 0;
			ship.vz = 0;
			this.fx.push("boom");
			if (ship === this.you) {
				this.deaths += 1;
				this.events.push({ t: "down" });
				if (boltId !== null) this.events.push({
					t: "hit",
					id: boltId
				});
			} else this.frags += 1;
			this.checkWin();
		} else {
			this.impacts.push({
				owner,
				x: ship.x,
				z: ship.z,
				kind: "hit"
			});
			if (boltId !== null && ship === this.you) this.events.push({
				t: "hit",
				id: boltId
			});
		}
	}
	bumpRocks() {
		const rocks = asteroids(nowSec());
		const ships = this.net ? [this.you] : [this.you, this.them];
		for (const ship of ships) {
			if (!ship.alive) continue;
			for (let ri = 0; ri < rocks.length; ri += 1) {
				const rock = rocks[ri];
				const state = this.rocks[ri];
				if (state && state.down > 0) continue;
				const dx = ship.x - rock.x;
				const dz = ship.z - rock.z;
				const min = rock.r + SHIP_R;
				const d2 = dx * dx + dz * dz;
				if (d2 >= min * min || d2 < 1e-8) continue;
				const d = Math.sqrt(d2);
				ship.x = rock.x + dx / d * (min + .04);
				ship.z = rock.z + dz / d * (min + .04);
				const c = clampShip(ship.side, ship.x, ship.z);
				ship.x = c.x;
				ship.z = c.z;
				ship.vx *= .35;
				ship.vz *= .35;
				if (ship.hurtCd <= 0) {
					ship.hurtCd = .7;
					this.hurt(ship, 8, null);
				}
			}
		}
	}
	bumpShips() {
		if (!this.you.alive || !this.them.alive) return;
		const dx = this.you.x - this.them.x;
		const dz = this.you.z - this.them.z;
		const min = SHIP_R * 2;
		const d2 = dx * dx + dz * dz;
		if (d2 >= min * min || d2 < 1e-8) return;
		const d = Math.sqrt(d2);
		const push = (min - d) / 2 + .02;
		const nx = dx / d;
		const nz = dz / d;
		this.you.x += nx * (this.net ? push * 2 : push);
		this.you.z += nz * (this.net ? push * 2 : push);
		if (!this.net) {
			this.them.x -= nx * push;
			this.them.z -= nz * push;
			const ct = clampShip(this.them.side, this.them.x, this.them.z);
			this.them.x = ct.x;
			this.them.z = ct.z;
		}
		const cy = clampShip(this.you.side, this.you.x, this.you.z);
		this.you.x = cy.x;
		this.you.z = cy.z;
	}
	powerups() {
		if (!this.over && !this.power && this.time >= this.nextPowerAt && (this.authority || !this.net)) {
			const kind = this.nextPowerId % 3;
			const power = {
				id: this.nextPowerId,
				kind,
				x: 0,
				z: 0
			};
			this.nextPowerId += 1;
			this.power = power;
			this.nextPowerAt = this.time + 12;
			if (this.net) this.events.push({
				t: "power",
				power
			});
		}
		if (!this.power) return;
		const reach = (SHIP_R + .95) ** 2;
		const youD = (this.you.x - this.power.x) ** 2 + (this.you.z - this.power.z) ** 2;
		const themD = (this.them.x - this.power.x) ** 2 + (this.them.z - this.power.z) ** 2;
		const youHit = this.you.alive && youD < reach;
		const themHit = !this.net && this.them.alive && themD < reach;
		if (!youHit && !themHit) return;
		const youWins = youHit && (!themHit || youD <= themD);
		const power = this.power;
		this.power = null;
		this.nextPowerAt = this.time + 10;
		if (youWins) {
			this.grant(this.you, power.kind);
			this.fx.push("pick");
			this.events.push({
				t: "take",
				id: power.id
			});
		} else this.grant(this.them, power.kind);
	}
	grant(ship, kind) {
		if (kind === 0) ship.rapid = 7.5;
		else if (kind === 1) ship.spread = 7.5;
		else ship.shield = Math.max(ship.shield, 8);
	}
	tickRocks(dt) {
		const spots = asteroids(nowSec());
		for (let i = 0; i < this.rocks.length; i += 1) {
			const rock = this.rocks[i];
			if (rock.pop > 0) rock.pop = Math.max(0, rock.pop - dt);
			if (rock.down <= 0) continue;
			rock.down = Math.max(0, rock.down - dt);
			if (rock.down > 0) continue;
			rock.hp = rock.max;
			rock.pop = .45;
			this.fx.push("reform");
			const spot = spots[i];
			if (spot) this.events.push({
				t: "reform",
				i,
				x: spot.x,
				z: spot.z
			});
		}
	}
	respawn(ship, dt) {
		if (ship.alive || this.over) return;
		ship.respawn -= dt;
		if (ship.respawn > 0) return;
		const p = spawnFor(ship.side);
		ship.x = p.x;
		ship.z = p.z;
		ship.vx = 0;
		ship.vz = 0;
		ship.nose = 0;
		ship.hp = 100;
		ship.alive = true;
		ship.invuln = 1.35;
		ship.shield = 0;
		ship.boostCd = 0;
		ship.rapid = 0;
		ship.spread = 0;
	}
	checkWin() {
		if (this.over) return;
		if (this.frags >= 4) this.over = "you";
		else if (this.deaths >= 4) this.over = "them";
	}
};
var AMBER$1 = 15887133;
var CYAN$1 = 3073735;
var VOID = 461069;
var _fwd = new Vector3();
var _up = new Vector3(0, 1, 0);
var _x = new Vector3();
var _m = new Matrix4();
var _c = new Color();
var _look = new Vector3();
var _cam = new Vector3();
function makeCraft(hex) {
	const group = new Group();
	const hull = new MeshStandardMaterial({
		color: 1712668,
		metalness: .72,
		roughness: .32,
		emissive: hex,
		emissiveIntensity: .06
	});
	const hot = new MeshStandardMaterial({
		color: hex,
		emissive: hex,
		emissiveIntensity: .85,
		metalness: .35,
		roughness: .28
	});
	const glass = new MeshStandardMaterial({
		color: 790542,
		metalness: .85,
		roughness: .12,
		emissive: hex,
		emissiveIntensity: .35
	});
	const glow = new MeshBasicMaterial({
		color: hex,
		transparent: true,
		opacity: .95,
		blending: 2,
		depthWrite: false
	});
	const nose = new Mesh(new ConeGeometry(.2, .72, 5), hot);
	nose.rotation.x = Math.PI / 2;
	nose.position.z = .78;
	group.add(nose);
	const body = new Mesh(new CylinderGeometry(.16, .28, 1.05, 6), hull);
	body.rotation.x = Math.PI / 2;
	body.position.z = .05;
	group.add(body);
	const wings = new Mesh(new BoxGeometry(1.45, .045, .42), hot);
	wings.position.set(0, 0, -.08);
	group.add(wings);
	const tail = new Mesh(new BoxGeometry(.62, .035, .2), hull);
	tail.position.set(0, .1, -.48);
	group.add(tail);
	const canopy = new Mesh(new SphereGeometry(.14, 12, 8), glass);
	canopy.scale.set(.85, .62, 1.35);
	canopy.position.set(0, .16, .22);
	group.add(canopy);
	const fin = new Mesh(new BoxGeometry(.07, .42, .34), hot);
	fin.position.set(0, .28, -.32);
	group.add(fin);
	const engine = new Mesh(new SphereGeometry(.18, 10, 8), glow);
	engine.position.set(0, 0, -.62);
	group.add(engine);
	const ring = new Mesh(new RingGeometry(.62, .78, 20), new MeshBasicMaterial({
		color: hex,
		side: 2,
		transparent: true,
		opacity: .75
	}));
	ring.rotation.x = -Math.PI / 2;
	ring.position.y = .04;
	const bubble = new Mesh(new SphereGeometry(1.05, 22, 16), new MeshBasicMaterial({
		color: hex,
		transparent: true,
		opacity: .28,
		depthWrite: false,
		blending: 2,
		side: 2
	}));
	bubble.visible = false;
	bubble.renderOrder = 2;
	group.add(bubble);
	const halo = new Mesh(new TorusGeometry(1.2, .045, 8, 32), new MeshBasicMaterial({
		color: hex,
		transparent: true,
		opacity: .75,
		depthWrite: false,
		blending: 2,
		side: 2
	}));
	halo.rotation.x = Math.PI / 2;
	halo.visible = false;
	group.add(halo);
	group.scale.setScalar(2.35);
	group.position.y = .9;
	return {
		group,
		hot,
		engine,
		ring,
		bubble,
		halo
	};
}
function orient(obj, dirX, dirZ, bank) {
	_fwd.set(dirX, 0, dirZ);
	if (_fwd.lengthSq() < 1e-8) return;
	_fwd.normalize();
	_up.set(0, 1, 0);
	_x.crossVectors(_up, _fwd);
	if (_x.lengthSq() < 1e-8) return;
	_x.normalize();
	_m.makeBasis(_x, _up, _fwd);
	obj.quaternion.setFromRotationMatrix(_m);
	obj.rotateZ(bank);
}
var RiftView = class {
	renderer;
	scene = new Scene();
	camera;
	you;
	them;
	bolts;
	rocks = [];
	power;
	points;
	pGeom;
	particles = [];
	pPos;
	pCol;
	camX = 0;
	camY = 14;
	camZ = 24;
	shake = 0;
	reduce;
	disposed = false;
	hemi;
	sun;
	riftLight;
	floorMat;
	riftMat;
	coreMat;
	wallMat;
	starMat;
	stars;
	sunDisc;
	snow;
	snowPos;
	rain;
	rainPos;
	trees;
	ghosts;
	floorTex;
	rockGlow = .4;
	constructor(canvas) {
		this.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: true,
			alpha: false,
			powerPreference: "high-performance"
		});
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
		this.renderer.setClearColor(VOID, 1);
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.camera = new PerspectiveCamera(48, 1, .1, 180);
		this.scene.fog = new FogExp2(VOID, .022);
		this.scene.background = new Color(VOID);
		this.hemi = new HemisphereLight(13166300, 461069, .55);
		this.scene.add(this.hemi);
		this.sun = new DirectionalLight(16052452, 1.35);
		this.sun.position.set(6, 14, 8);
		this.scene.add(this.sun);
		this.riftLight = new PointLight(CYAN$1, 8, 18, 2);
		this.riftLight.position.set(0, 1.5, 0);
		this.scene.add(this.riftLight);
		this.sunDisc = new Mesh(new SphereGeometry(1.4, 16, 12), new MeshBasicMaterial({ color: 16773572 }));
		this.sunDisc.position.set(10, 24, 6);
		this.sunDisc.visible = false;
		this.scene.add(this.sunDisc);
		this.floorTex = gridTexture("#0c110e", "#1a2c24");
		this.floorMat = new MeshStandardMaterial({
			color: 16777215,
			map: this.floorTex,
			roughness: 1,
			metalness: .05
		});
		const floor = new Mesh(new PlaneGeometry(70, 80), this.floorMat);
		floor.rotation.x = -Math.PI / 2;
		this.scene.add(floor);
		this.riftMat = new MeshBasicMaterial({
			color: CYAN$1,
			transparent: true,
			opacity: .18,
			blending: 2,
			depthWrite: false,
			side: 2
		});
		const rift = new Mesh(new PlaneGeometry(16.4, 2.2), this.riftMat);
		rift.rotation.x = -Math.PI / 2;
		rift.position.y = .03;
		this.scene.add(rift);
		this.coreMat = new MeshBasicMaterial({
			color: 14155766,
			transparent: true,
			opacity: .85,
			blending: 2,
			depthWrite: false,
			side: 2
		});
		const core = new Mesh(new PlaneGeometry(16.4, .07), this.coreMat);
		core.rotation.x = -Math.PI / 2;
		core.position.y = .04;
		this.scene.add(core);
		const deck = (z, color) => {
			const mesh = new Mesh(new PlaneGeometry(3.2, .08), new MeshBasicMaterial({
				color,
				transparent: true,
				opacity: .55,
				blending: 2,
				depthWrite: false,
				side: 2
			}));
			mesh.rotation.x = -Math.PI / 2;
			mesh.position.set(0, .05, z);
			this.scene.add(mesh);
		};
		deck(15.05, AMBER$1);
		deck(-15.05, CYAN$1);
		this.wallMat = new MeshStandardMaterial({
			color: 1185812,
			emissive: 1333324,
			emissiveIntensity: .55,
			metalness: .45,
			roughness: .4
		});
		const addWall = (x, z, sx, sz) => {
			const mesh = new Mesh(new BoxGeometry(sx, .55, sz), this.wallMat);
			mesh.position.set(x, .28, z);
			this.scene.add(mesh);
		};
		addWall(-8.15, 0, .16, 31);
		addWall(8.15, 0, .16, 31);
		addWall(0, 15.6, 16.2, .16);
		addWall(0, -15.6, 16.2, .16);
		const starPos = /* @__PURE__ */ new Float32Array(2700);
		for (let i = 0; i < 900; i += 1) {
			starPos[i * 3] = (Math.random() - .5) * 90;
			starPos[i * 3 + 1] = Math.random() * 28 + 2;
			starPos[i * 3 + 2] = (Math.random() - .5) * 90;
		}
		const starGeo = new BufferGeometry();
		starGeo.setAttribute("position", new BufferAttribute(starPos, 3));
		this.starMat = new PointsMaterial({
			color: 14018268,
			size: .08,
			transparent: true,
			opacity: .8
		});
		this.stars = new Points(starGeo, this.starMat);
		this.scene.add(this.stars);
		this.snowPos = /* @__PURE__ */ new Float32Array(720);
		for (let i = 0; i < 240; i += 1) {
			this.snowPos[i * 3] = (Math.random() - .5) * 28;
			this.snowPos[i * 3 + 1] = Math.random() * 16;
			this.snowPos[i * 3 + 2] = (Math.random() - .5) * 36;
		}
		const snowGeo = new BufferGeometry();
		snowGeo.setAttribute("position", new BufferAttribute(this.snowPos, 3));
		this.snow = new Points(snowGeo, new PointsMaterial({
			color: 16777215,
			size: .14,
			transparent: true,
			opacity: .9
		}));
		this.snow.visible = false;
		this.scene.add(this.snow);
		this.rainPos = /* @__PURE__ */ new Float32Array(1260);
		for (let i = 0; i < 420; i += 1) {
			this.rainPos[i * 3] = (Math.random() - .5) * 30;
			this.rainPos[i * 3 + 1] = Math.random() * 18;
			this.rainPos[i * 3 + 2] = (Math.random() - .5) * 40;
		}
		const rainGeo = new BufferGeometry();
		rainGeo.setAttribute("position", new BufferAttribute(this.rainPos, 3));
		this.rain = new Points(rainGeo, new PointsMaterial({
			color: 13956351,
			size: .055,
			transparent: true,
			opacity: .75,
			depthWrite: false
		}));
		this.rain.visible = false;
		this.scene.add(this.rain);
		this.trees = new Group();
		const pine = new MeshStandardMaterial({
			color: 1927994,
			roughness: .8
		});
		const trunk = new MeshStandardMaterial({
			color: 7027234,
			roughness: .9
		});
		for (const [x, z] of [
			[-11.2, -10],
			[11.2, -4],
			[-11.4, 3],
			[11.3, 9],
			[-10.8, 14]
		]) {
			const tree = new Group();
			const cone = new Mesh(new ConeGeometry(.7, 1.8, 6), pine);
			cone.position.y = 1.3;
			const stick = new Mesh(new CylinderGeometry(.12, .14, .5, 5), trunk);
			stick.position.y = .25;
			tree.add(cone, stick);
			tree.position.set(x, 0, z);
			this.trees.add(tree);
		}
		this.trees.visible = false;
		this.scene.add(this.trees);
		this.ghosts = new Group();
		const sheet = new MeshBasicMaterial({
			color: 16052479,
			transparent: true,
			opacity: .72,
			depthWrite: false
		});
		for (let i = 0; i < 5; i += 1) {
			const ghost = new Group();
			const body = new Mesh(new SphereGeometry(.38, 10, 8), sheet);
			body.scale.set(1, 1.25, 1);
			const tail = new Mesh(new ConeGeometry(.28, .55, 7), sheet);
			tail.rotation.x = Math.PI;
			tail.position.y = -.42;
			ghost.add(body, tail);
			ghost.position.set(i % 2 === 0 ? -6.2 : 6.2, 2.2, -12 + i * 5.5);
			ghost.userData.phase = i * 1.3;
			this.ghosts.add(ghost);
		}
		this.ghosts.visible = false;
		this.scene.add(this.ghosts);
		this.you = makeCraft(AMBER$1);
		this.them = makeCraft(CYAN$1);
		this.scene.add(this.you.group, this.you.ring, this.them.group, this.them.ring);
		const boltGeo = new BoxGeometry(.1, .1, .7);
		const boltMat = new MeshBasicMaterial({ color: 16777215 });
		this.bolts = new InstancedMesh(boltGeo, boltMat, 72);
		this.bolts.instanceMatrix.setUsage(DynamicDrawUsage);
		this.bolts.count = 0;
		this.scene.add(this.bolts);
		const rockGeo = new IcosahedronGeometry(1, 0);
		for (let i = 0; i < 4; i += 1) {
			const mesh = new Mesh(rockGeo, new MeshStandardMaterial({
				color: 2371626,
				flatShading: true,
				roughness: .92,
				metalness: .08,
				emissive: 1058848,
				emissiveIntensity: .4
			}));
			this.rocks.push(mesh);
			this.scene.add(mesh);
		}
		const crystalMat = new MeshStandardMaterial({
			color: 14202110,
			emissive: 11032055,
			emissiveIntensity: 1.35,
			metalness: .42,
			roughness: .16
		});
		this.power = new Group();
		const shard = new Mesh(new OctahedronGeometry(.36, 0), crystalMat);
		shard.scale.set(.7, 1.9, .7);
		const flake = new Mesh(new OctahedronGeometry(.2, 0), crystalMat);
		flake.scale.set(.55, 1.15, .55);
		flake.rotation.y = .7;
		flake.position.y = .12;
		this.power.add(shard, flake);
		this.power.visible = false;
		this.scene.add(this.power);
		const MAX = 180;
		this.pPos = /* @__PURE__ */ new Float32Array(540);
		this.pCol = /* @__PURE__ */ new Float32Array(540);
		this.pGeom = new BufferGeometry();
		this.pGeom.setAttribute("position", new BufferAttribute(this.pPos, 3));
		this.pGeom.setAttribute("color", new BufferAttribute(this.pCol, 3));
		this.points = new Points(this.pGeom, new PointsMaterial({
			size: .16,
			vertexColors: true,
			transparent: true,
			depthWrite: false,
			blending: 2
		}));
		this.scene.add(this.points);
		for (let i = 0; i < MAX; i += 1) this.particles.push({
			x: 0,
			y: 0,
			z: 0,
			vx: 0,
			vy: 0,
			vz: 0,
			life: 0,
			max: 1,
			cr: 1,
			cg: 1,
			cb: 1
		});
		this.resize();
	}
	setMap(id) {
		const theme = mapById(id);
		this.rockGlow = theme.rockGlowAmt;
		this.renderer.setClearColor(theme.sky, 1);
		const fog = this.scene.fog;
		fog.color.set(theme.fog);
		fog.density = theme.fogDensity;
		this.scene.background.set(theme.sky);
		this.hemi.color.set(theme.hemiSky);
		this.hemi.groundColor.set(theme.hemiGround);
		this.hemi.intensity = theme.hemi;
		this.sun.color.set(theme.sun);
		this.sun.intensity = theme.sunIntensity;
		this.sun.position.set(theme.sunPos[0], theme.sunPos[1], theme.sunPos[2]);
		this.sunDisc.visible = theme.disc;
		this.sunDisc.scale.setScalar(theme.disc ? 2.6 : 1);
		this.sunDisc.position.set(theme.sunPos[0], theme.sunPos[1], theme.sunPos[2]);
		this.sunDisc.material.color.set(theme.discColor);
		this.riftLight.color.set(theme.rift);
		this.riftLight.intensity = theme.riftIntensity;
		this.riftMat.color.set(theme.rift);
		this.coreMat.color.set(theme.riftCore);
		this.wallMat.color.set(theme.wall);
		this.wallMat.emissive.set(theme.wallGlow);
		this.wallMat.emissiveIntensity = theme.wallGlowAmt;
		this.starMat.color.set(theme.stars);
		this.starMat.opacity = theme.starOpacity;
		this.stars.visible = theme.starOpacity > .02;
		const next = gridTexture(theme.floor, theme.grid);
		this.floorTex.dispose();
		this.floorTex = next;
		this.floorMat.map = next;
		this.floorMat.needsUpdate = true;
		for (const mesh of this.rocks) {
			const mat = mesh.material;
			mat.color.set(theme.rock);
			mat.emissive.set(theme.rockGlow);
			mat.emissiveIntensity = theme.rockGlowAmt;
		}
		this.snow.visible = id === "snow";
		this.trees.visible = id === "snow";
		this.ghosts.visible = id === "haunt";
		this.rain.visible = id === "rain";
		if (id === "snow") this.starMat.opacity = .35;
	}
	resize() {
		const canvas = this.renderer.domElement;
		const w = canvas.clientWidth || 1;
		const h = canvas.clientHeight || 1;
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / Math.max(1, h);
		const hfov = 2 * Math.atan(Math.tan(48 * (Math.PI / 180) / 2) * this.camera.aspect);
		const minH = 62 * (Math.PI / 180);
		if (hfov < minH) this.camera.fov = 2 * Math.atan(Math.tan(minH / 2) / this.camera.aspect) * 180 / Math.PI;
		else this.camera.fov = 48;
		this.camera.updateProjectionMatrix();
	}
	kick(amount) {
		if (this.reduce) return;
		this.shake = Math.min(.55, this.shake + amount);
	}
	burst(x, z, color, count, speed) {
		_c.set(color);
		let left = count;
		for (const p of this.particles) {
			if (left <= 0) break;
			if (p.life > 0) continue;
			const a = Math.random() * Math.PI * 2;
			const u = Math.random();
			p.x = x;
			p.y = .4 + Math.random() * .4;
			p.z = z;
			p.vx = Math.cos(a) * speed * (.4 + u);
			p.vz = Math.sin(a) * speed * (.4 + u);
			p.vy = 1.2 + Math.random() * 2.4;
			p.life = .35 + Math.random() * .4;
			p.max = p.life;
			p.cr = _c.r;
			p.cg = _c.g;
			p.cb = _c.b;
			left -= 1;
		}
	}
	render(sim, dt, follow, themLead) {
		if (this.disposed) return;
		const t = nowSec();
		this.shake *= Math.exp(-3.2 * dt);
		this.placeShips(sim, t, themLead);
		this.placeBolts(sim);
		this.placeRocks(t, sim);
		this.placePower(sim, t);
		this.stepMood(dt, t);
		this.stepParticles(dt);
		this.placeCamera(sim, dt, follow, t);
		this.renderer.render(this.scene, this.camera);
	}
	dispose() {
		this.disposed = true;
		this.renderer.dispose();
		this.floorTex.dispose();
		this.scene.traverse((obj) => {
			const mesh = obj;
			if (mesh.geometry) mesh.geometry.dispose();
			const mat = mesh.material;
			if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
			else if (mat) mat.dispose();
		});
	}
	stepMood(dt, t) {
		if (this.snow.visible) {
			const pos = this.snowPos;
			for (let i = 0; i < pos.length; i += 3) {
				pos[i + 1] -= dt * (1.6 + i % 7 * .15);
				pos[i] += Math.sin(t + i) * dt * .15;
				if (pos[i + 1] < 0) {
					pos[i + 1] = 14 + Math.random() * 2;
					pos[i] = (Math.random() - .5) * 28;
					pos[i + 2] = (Math.random() - .5) * 36;
				}
			}
			const attr = this.snow.geometry.getAttribute("position");
			attr.needsUpdate = true;
		}
		if (this.rain.visible) {
			const pos = this.rainPos;
			for (let i = 0; i < pos.length; i += 3) {
				pos[i + 1] -= dt * (14 + i % 5 * 1.6);
				pos[i] += dt * 2.4;
				if (pos[i + 1] < 0) {
					pos[i + 1] = 14 + Math.random() * 4;
					pos[i] = (Math.random() - .5) * 30;
					pos[i + 2] = (Math.random() - .5) * 40;
				}
			}
			const attr = this.rain.geometry.getAttribute("position");
			attr.needsUpdate = true;
		}
		if (this.ghosts.visible) this.ghosts.children.forEach((ghost, i) => {
			const phase = ghost.userData.phase || 0;
			ghost.position.y = 1.8 + Math.sin(t * 1.3 + phase) * .45;
			ghost.position.x = (i % 2 === 0 ? -6.2 : 6.2) + Math.sin(t * .6 + phase) * .6;
			ghost.rotation.y = Math.sin(t + phase) * .4;
		});
	}
	placeShips(sim, t, themLead) {
		const bob = this.reduce ? 0 : Math.sin(t * 2.1) * .035;
		placeCraft(this.you, sim.you.side, sim.you.x, sim.you.z, sim.you.nose, sim.you.vx, sim.you.alive, sim.you.invuln, sim.you.flash, sim.you.shield, sim.you.boostCd, t, bob);
		const tx = sim.them.x + sim.them.vx * themLead;
		const tz = sim.them.z + sim.them.vz * themLead;
		placeCraft(this.them, sim.them.side, tx, tz, sim.them.nose, sim.them.vx, sim.them.alive, sim.them.invuln, sim.them.flash, sim.them.shield, sim.them.boostCd, t, -bob);
	}
	placeBolts(sim) {
		const n = Math.min(sim.bolts.length, 72);
		this.bolts.count = n;
		for (let i = 0; i < n; i += 1) {
			const b = sim.bolts[i];
			_fwd.set(b.dx, 0, b.dz);
			if (_fwd.lengthSq() < 1e-8) _fwd.set(0, 0, 1);
			_fwd.normalize();
			_up.set(0, 1, 0);
			_x.crossVectors(_up, _fwd).normalize();
			_m.makeBasis(_x, _up, _fwd);
			_m.setPosition(b.x, .46, b.z);
			this.bolts.setMatrixAt(i, _m);
			_c.set(b.owner === "you" ? AMBER$1 : CYAN$1);
			this.bolts.setColorAt(i, _c);
		}
		this.bolts.instanceMatrix.needsUpdate = true;
		if (this.bolts.instanceColor) this.bolts.instanceColor.needsUpdate = true;
	}
	placeRocks(t, sim) {
		const rocks = asteroids(t);
		for (let i = 0; i < this.rocks.length; i += 1) {
			const a = rocks[i];
			const mesh = this.rocks[i];
			const state = sim.rocks[i];
			if (!a || !state || state.down > 0) {
				mesh.visible = false;
				continue;
			}
			mesh.visible = true;
			const intro = state.pop > 0 ? Math.max(.15, 1 - state.pop / .45) : 1;
			mesh.position.set(a.x, a.r * .45 * intro, a.z);
			mesh.scale.setScalar(a.r * intro);
			mesh.rotation.y = t * a.spin;
			mesh.rotation.x = t * a.spin * .6;
			const mat = mesh.material;
			const hurt = 1 - state.hp / state.max;
			mat.emissiveIntensity = this.rockGlow + hurt * 1.1;
		}
	}
	placePower(sim, t) {
		if (!sim.power) {
			this.power.visible = false;
			return;
		}
		this.power.visible = true;
		this.power.position.set(sim.power.x, 1.05 + Math.sin(t * 3) * .14, sim.power.z);
		this.power.rotation.y = t * 1.4;
	}
	stepParticles(dt) {
		let write = 0;
		for (const p of this.particles) {
			if (p.life <= 0) continue;
			p.life -= dt;
			if (p.life <= 0) continue;
			p.vy -= 3.2 * dt;
			p.x += p.vx * dt;
			p.y += p.vy * dt;
			p.z += p.vz * dt;
			const fade = p.life / p.max;
			this.pPos[write * 3] = p.x;
			this.pPos[write * 3 + 1] = p.y;
			this.pPos[write * 3 + 2] = p.z;
			this.pCol[write * 3] = p.cr * fade;
			this.pCol[write * 3 + 1] = p.cg * fade;
			this.pCol[write * 3 + 2] = p.cb * fade;
			write += 1;
		}
		for (let i = write * 3; i < this.pPos.length; i += 1) this.pPos[i] = 0;
		this.pGeom.attributes.position.needsUpdate = true;
		this.pGeom.attributes.color.needsUpdate = true;
		this.pGeom.setDrawRange(0, write);
	}
	placeCamera(sim, dt, follow, t) {
		if (!follow) {
			const drift = this.reduce ? 0 : Math.sin(t * .35) * .8;
			_cam.set(drift, 6.8, 17.6);
			_look.set(0, .8, 6);
		} else {
			const ship = sim.you;
			const back = ship.side === 1 ? 1 : -1;
			_cam.set(ship.x * .28, 7.6, ship.z + back * 6.4);
			_look.set(ship.x * .08, .55, ship.z - back * 13.5);
		}
		const k = 1 - Math.exp(-4.5 * dt);
		this.camX += (_cam.x - this.camX) * k;
		this.camY += (_cam.y - this.camY) * k;
		this.camZ += (_cam.z - this.camZ) * k;
		const jx = this.reduce ? 0 : (Math.random() - .5) * this.shake;
		const jy = this.reduce ? 0 : (Math.random() - .5) * this.shake;
		this.camera.position.set(this.camX + jx, this.camY + jy, this.camZ);
		this.camera.lookAt(_look);
	}
};
function placeCraft(craft, side, x, z, nose, vx, alive, invuln, flash, shield, shieldCd, t, bob) {
	craft.group.visible = alive;
	craft.ring.visible = alive;
	craft.bubble.visible = false;
	craft.halo.visible = false;
	if (!alive) return;
	const blink = invuln > 0 && Math.sin(t * 28) > 0;
	craft.group.visible = !blink;
	craft.ring.visible = !blink;
	const dir = aimDir(side, nose);
	const bank = clampBank(-Math.sign(nose) * Math.min(.45, Math.abs(nose) * .7 + Math.abs(vx) * .01));
	orient(craft.group, dir.x, dir.z, bank);
	craft.group.position.set(x, .95 + bob, z);
	craft.ring.position.set(x, .05, z);
	craft.ring.scale.setScalar(2.1);
	craft.hot.emissiveIntensity = .75 + flash * 2.4;
	const eng = 1 + Math.min(.45, Math.abs(vx) * .04);
	craft.engine.scale.setScalar(eng);
	const bubbleMat = craft.bubble.material;
	const haloMat = craft.halo.material;
	if (shield > 0) {
		const pulse = .9 + Math.sin(t * 8) * .08;
		const fade = Math.min(1, shield / .4);
		craft.bubble.visible = !blink;
		craft.bubble.scale.setScalar(pulse);
		bubbleMat.opacity = (.18 + Math.sin(t * 6) * .08) * fade;
		craft.halo.visible = !blink;
		craft.halo.scale.setScalar(1);
		craft.halo.rotation.z = t * 2.4;
		haloMat.opacity = .45 + Math.sin(t * 9) * .2;
	} else if (shieldCd > 0) {
		const regen = 1 - Math.min(1, shieldCd / SHIELD_CD);
		craft.halo.visible = !blink;
		craft.halo.scale.setScalar(.28 + regen * .72);
		craft.halo.rotation.z = t * .8;
		haloMat.opacity = .15 + regen * .45;
	}
}
function clampBank(v) {
	return Math.max(-.5, Math.min(.5, v));
}
function gridTexture(fill, line) {
	const c = document.createElement("canvas");
	c.width = 512;
	c.height = 512;
	const g = c.getContext("2d");
	if (!g) return new CanvasTexture(c);
	g.fillStyle = fill;
	g.fillRect(0, 0, 512, 512);
	g.strokeStyle = line;
	g.lineWidth = 2;
	for (let i = 0; i <= 512; i += 32) {
		g.beginPath();
		g.moveTo(i, 0);
		g.lineTo(i, 512);
		g.stroke();
		g.beginPath();
		g.moveTo(0, i);
		g.lineTo(512, i);
		g.stroke();
	}
	const tex = new CanvasTexture(c);
	tex.wrapS = RepeatWrapping;
	tex.wrapT = RepeatWrapping;
	tex.repeat.set(8, 10);
	tex.colorSpace = SRGBColorSpace;
	tex.anisotropy = 4;
	return tex;
}
var INITIAL_HUD = {
	phase: "title",
	room: "",
	youName: "YOU",
	themName: "Your Problem",
	youHp: 100,
	themHp: 100,
	youFrags: 0,
	themFrags: 0,
	fragsToWin: 4,
	shield: false,
	rapid: false,
	spread: false,
	shieldCd: 0,
	banner: "",
	status: "",
	winner: null,
	rtt: null,
	link: "off",
	muted: false,
	wardenWins: 0,
	countdown: 0,
	net: false,
	map: "night"
};
var STEP = 1 / 60;
var AMBER = 15887133;
var CYAN = 3073735;
function cleanName(raw) {
	const s = raw.replace(/[^a-zA-Z0-9 ]/g, "").trim().slice(0, 12);
	return s.length > 0 ? s : "YOU";
}
function loadPeerId() {
	const key = "rift-duel-peer";
	try {
		const existing = sessionStorage.getItem(key);
		if (existing && /^[a-zA-Z0-9_-]{1,64}$/.test(existing)) return existing;
		const id = `p${crypto.randomUUID().replace(/-/g, "").slice(0, 16)}`;
		sessionStorage.setItem(key, id);
		return id;
	} catch {
		return `p${Math.random().toString(36).slice(2, 12)}`;
	}
}
function loadWins() {
	try {
		return Number(localStorage.getItem("rift-duel-wins") ?? "0") || 0;
	} catch {
		return 0;
	}
}
function loadMap() {
	try {
		return mapById(localStorage.getItem("rift-duel-map")).id;
	} catch {
		return "night";
	}
}
function loadMute() {
	try {
		return localStorage.getItem("rift-duel-mute") === "1";
	} catch {
		return false;
	}
}
var RiftSession = class {
	onHud;
	sim = new Sim();
	view;
	keys = /* @__PURE__ */ new Set();
	qa = null;
	stick = {
		x: 0,
		y: 0,
		on: false
	};
	fireHeld = false;
	boostHeld = false;
	shieldQueued = false;
	pointerFire = false;
	phase = "title";
	link = "off";
	roomCode = "";
	youName = "YOU";
	themName = "Your Problem";
	net = false;
	muted = loadMute();
	mapId = loadMap();
	wardenWins = loadWins();
	winsStored = false;
	banner = "";
	bannerUntil = 0;
	status = "";
	countdown = 0;
	goAt = 0;
	goSentAt = 0;
	mapSentAt = 0;
	readyAt = 0;
	sideReady = false;
	hosting = false;
	signalingOk = true;
	selfId = "local";
	peerId = null;
	room = null;
	rtt = null;
	seq = 0;
	epoch = 0;
	eid = 0;
	seenE = /* @__PURE__ */ new Set();
	themSeq = 0;
	themEpoch = 0;
	remoteAt = 0;
	netAcc = 0;
	acc = 0;
	last = 0;
	lastHud = 0;
	hudKey = "";
	raf = 0;
	dead = false;
	resizeObserver;
	onKeyDown;
	onKeyUp;
	onBlur;
	onVis;
	onPointerDown;
	onPointerUp;
	constructor(canvas, onHud) {
		this.onHud = onHud;
		this.view = new RiftView(canvas);
		this.view.setMap(this.mapId);
		setMuted(this.muted);
		this.resizeObserver = new ResizeObserver(() => this.view.resize());
		this.resizeObserver.observe(canvas);
		this.onKeyDown = (e) => {
			const target = e.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
			if (this.qa) return;
			this.keys.add(e.code);
			if (this.phase === "play" && [
				"Space",
				"ArrowUp",
				"ArrowDown",
				"ArrowLeft",
				"ArrowRight"
			].includes(e.code)) e.preventDefault();
		};
		this.onKeyUp = (e) => {
			this.keys.delete(e.code);
		};
		this.onBlur = () => this.keys.clear();
		this.onVis = () => {
			if (document.visibilityState === "visible") resumeAudio();
			else this.keys.clear();
		};
		this.onPointerDown = () => {
			if (this.phase === "play") this.pointerFire = true;
		};
		this.onPointerUp = () => {
			this.pointerFire = false;
		};
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onVis);
		canvas.addEventListener("pointerdown", this.onPointerDown);
		window.addEventListener("pointerup", this.onPointerUp);
		window.addEventListener("pagehide", () => this.closeRoom());
		this.publish(true);
	}
	start() {
		this.last = performance.now();
		this.raf = requestAnimationFrame(this.frame);
	}
	setStick(x, y, on) {
		this.stick.x = x;
		this.stick.y = y;
		this.stick.on = on;
	}
	setFire(on) {
		this.fireHeld = on;
	}
	setBoost(on) {
		this.boostHeld = on;
		if (on) this.shieldQueued = true;
	}
	setMap(id) {
		this.mapId = mapById(id).id;
		this.view.setMap(this.mapId);
		try {
			localStorage.setItem("rift-duel-map", this.mapId);
		} catch {}
		this.publish(true);
	}
	toggleMute() {
		this.muted = !this.muted;
		setMuted(this.muted);
		try {
			localStorage.setItem("rift-duel-mute", this.muted ? "1" : "0");
		} catch {}
		this.publish(true);
	}
	startSolo(name) {
		this.closeRoom();
		this.youName = cleanName(name);
		this.themName = "Your Problem";
		this.rememberName();
		this.net = false;
		this.link = "off";
		this.peerId = null;
		this.sideReady = false;
		this.goAt = 0;
		this.countdown = 0;
		this.winsStored = false;
		this.roomCode = "";
		this.status = "Your Problem holds the far lip";
		this.banner = "";
		this.sim.prepare(1, false, true);
		this.phase = "play";
		this.rtt = null;
		this.publish(true);
	}
	host(code, name) {
		return this.open(code, name, true);
	}
	join(code, name) {
		return this.open(code, name, false);
	}
	leave() {
		this.closeRoom();
		this.phase = "title";
		this.net = false;
		this.link = "off";
		this.peerId = null;
		this.sideReady = false;
		this.goAt = 0;
		this.countdown = 0;
		this.banner = "";
		this.status = "";
		this.roomCode = "";
		this.themName = "Your Problem";
		this.sim.diorama();
		this.publish(true);
	}
	rematch() {
		if (this.phase !== "over" && this.phase !== "play") return;
		if (this.net && this.peerId) {
			this.netSend({ k: "re" });
			this.restartLinked();
			return;
		}
		this.startSolo(this.youName);
	}
	dispose() {
		this.dead = true;
		cancelAnimationFrame(this.raf);
		this.closeRoom();
		this.resizeObserver.disconnect();
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onVis);
		this.view.renderer.domElement.removeEventListener("pointerdown", this.onPointerDown);
		window.removeEventListener("pointerup", this.onPointerUp);
		this.view.dispose();
		if (window.__controlsTest) delete window.__controlsTest;
	}
	open(code, name, hosting) {
		const room = code.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 4);
		if (!/^[A-Z0-9]{4}$/.test(room)) {
			this.status = "Code needs 4 letters";
			this.publish(true);
			return false;
		}
		this.closeRoom();
		this.youName = cleanName(name);
		this.rememberName();
		this.themName = "Your Problem";
		this.roomCode = room;
		this.net = true;
		this.link = "waiting";
		this.phase = "waiting";
		this.peerId = null;
		this.sideReady = false;
		this.goAt = 0;
		this.readyAt = 0;
		this.countdown = 0;
		this.winsStored = false;
		this.banner = "";
		this.rtt = null;
		this.themSeq = 0;
		this.themEpoch = 0;
		this.seq = 0;
		this.epoch = Date.now();
		this.seenE.clear();
		this.hosting = hosting;
		this.signalingOk = true;
		this.status = "Connecting to the game server…";
		this.sim.diorama();
		this.selfId = loadPeerId();
		this.mapSentAt = 0;
		this.room = new ColyseusLink({
			code: room,
			name: this.youName,
			map: this.mapId,
			hosting,
			onReady: (sessionId) => {
				this.selfId = sessionId;
				this.status = hosting ? "Tell your friend this code. They tap Join room on this same game." : "In the room. Waiting for the other phone.";
				this.publish(true);
			},
			onPeers: (peers) => this.onPeers(peers),
			onMessage: (_from, data) => this.onNet(data),
			onStatus: (kind, detail) => {
				if (kind === "error") {
					this.signalingOk = false;
					this.link = this.peerId ? "lost" : "waiting";
					this.status = detail || "Can't reach the game server.";
					this.publish(true);
					return;
				}
				if (kind === "reconnecting") {
					this.link = "waiting";
					this.status = detail || "Reconnecting…";
					this.publish(true);
					return;
				}
				if (kind === "connecting") {
					this.status = "Connecting to the game server…";
					this.publish(true);
					return;
				}
				this.onSignaling(true);
			}
		});
		this.room.start();
		this.publish(true);
		return true;
	}
	restartLinked() {
		if (!this.peerId) return;
		const side = this.selfId < this.peerId ? 1 : -1;
		this.sim.prepare(side, true, this.selfId < this.peerId);
		this.sideReady = true;
		this.readyAt = performance.now();
		this.phase = "play";
		this.countdown = 0;
		this.goAt = 0;
		this.banner = "";
		this.winsStored = false;
		this.status = "Rematch";
		this.publish(true);
	}
	onSignaling(ok) {
		if (ok === this.signalingOk) return;
		this.signalingOk = ok;
		if (this.phase !== "waiting" || this.peerId) return;
		this.status = ok ? this.hosting ? "Tell your friend this code. They tap Join room on this same game." : "In the room. Waiting for the other phone." : "Can't reach the game server. Leave this open — it keeps trying.";
		this.publish(true);
	}
	armSide(remoteId) {
		const side = this.selfId < remoteId ? 1 : -1;
		this.sim.prepare(side, true, this.selfId < remoteId);
		this.sideReady = true;
		this.readyAt = performance.now();
		this.status = `${this.themName} is in. Hold still — the lane opens.`;
	}
	onPeers(peers) {
		const remote = peers.find((p) => p.id !== this.selfId);
		if (!remote) {
			if (this.peerId && (this.phase === "play" || this.phase === "waiting" || this.phase === "over")) {
				this.link = "lost";
				this.status = "Pilot dropped. The lane is yours — or head back to the bay.";
				this.say("LINK LOST");
			}
			this.publish(true);
			return;
		}
		this.peerId = remote.id;
		if (remote.name) this.themName = cleanName(remote.name);
		this.rtt = remote.rttMs;
		const direct = remote.connectionState === "connected";
		this.link = direct ? "live" : "waiting";
		if (!this.sideReady && (this.phase === "waiting" || this.phase === "title")) this.armSide(remote.id);
		else if (this.phase === "play" || this.phase === "over") this.status = direct ? "Live" : "Reconnecting…";
		this.publish(true);
	}
	fresh(msg) {
		if (!msg.e) return true;
		if (this.seenE.has(msg.e)) return false;
		this.seenE.add(msg.e);
		if (this.seenE.size > 240) {
			const first = this.seenE.values().next().value;
			if (first) this.seenE.delete(first);
		}
		return true;
	}
	onNet(data) {
		if (!data || typeof data !== "object") return;
		const msg = data;
		if (!msg.k || !this.fresh(msg)) return;
		if (msg.k === "go") {
			if (this.phase !== "waiting") return;
			if (msg.m && !this.hosting) {
				const id = mapById(msg.m).id;
				if (id !== this.mapId) this.setMap(id);
			}
			if (msg.at < Date.now() - 800) return;
			if (!this.sideReady && this.peerId) this.armSide(this.peerId);
			if (!this.goAt || msg.at < this.goAt) this.goAt = msg.at;
			return;
		}
		if (msg.k === "mp") {
			if (!this.hosting && msg.m) {
				const id = mapById(msg.m).id;
				if (id !== this.mapId) this.setMap(id);
			}
			return;
		}
		if (msg.k === "re") {
			if (this.net && this.peerId && (this.phase === "play" || this.phase === "over")) this.restartLinked();
			return;
		}
		if (this.phase !== "play" && this.phase !== "over") return;
		if (msg.k === "st") {
			if (!msg.ep) return;
			if (msg.ep !== this.themEpoch) {
				this.themEpoch = msg.ep;
				this.themSeq = 0;
			}
			if (msg.seq < this.themSeq) return;
			this.themSeq = msg.seq;
			const was = this.sim.them.alive;
			this.sim.applyRemote({
				x: msg.x,
				z: msg.z,
				vx: msg.vx,
				vz: msg.vz,
				nose: msg.n,
				hp: msg.hp,
				alive: msg.a === 1,
				frags: msg.fr,
				deaths: msg.de,
				shield: msg.sh,
				rapid: msg.rp,
				spread: msg.sp
			});
			this.remoteAt = performance.now();
			if (was && !this.sim.them.alive) this.fragBurst(CYAN, this.sim.them.x, this.sim.them.z);
			this.watchWin();
			return;
		}
		if (msg.k === "sh") {
			if (!this.sim.ingestShot(msg.id, msg.x, msg.z, msg.dx, msg.dz)) return;
			playFx("shot");
			return;
		}
		if (msg.k === "hit") {
			if (!this.sim.resolveHit(msg.id)) return;
			playFx(this.sim.them.shield > 0 ? "clang" : "hit");
			this.view.burst(this.sim.them.x, this.sim.them.z, CYAN, 10, 2.4);
			return;
		}
		if (msg.k === "dn") {
			const x = this.sim.them.x;
			const z = this.sim.them.z;
			if (this.sim.remoteDown()) this.fragBurst(CYAN, x, z);
			this.watchWin();
			return;
		}
		if (msg.k === "pw") {
			this.sim.offerPower({
				id: msg.id,
				kind: msg.kind,
				x: msg.x,
				z: 0
			});
			return;
		}
		if (msg.k === "tk") {
			this.sim.remoteTake(msg.id);
			return;
		}
		if (msg.k === "rk") {
			const hit = this.sim.strike(msg.i);
			if (!hit) return;
			if (hit.kind === "chip") {
				playFx("chip");
				this.view.burst(hit.x, hit.z, 14272420, 6, 1.5);
			} else this.rockBlast(hit.x, hit.z);
		}
	}
	frame = (now) => {
		if (this.dead) return;
		const boot = window;
		if (boot.__riftBoot && this.phase === "title") {
			boot.__riftBoot = false;
			this.startSolo(this.youName);
		}
		window.__controlsTest;
		const dt = Math.min(.05, this.last ? (now - this.last) / 1e3 : 0);
		this.last = now;
		if (this.phase === "waiting" && this.sideReady && this.peerId) {
			if (!this.goAt && this.selfId < this.peerId) this.goAt = Date.now() + 2800;
			if (!this.goAt && now - this.readyAt > 1200) this.goAt = Date.now() + 1600;
			if (this.goAt && this.selfId < this.peerId && now - this.goSentAt > 350) {
				this.goSentAt = now;
				this.netSend({
					k: "go",
					at: this.goAt,
					m: this.hosting ? this.mapId : void 0
				});
			}
			if (this.hosting && now - this.mapSentAt > 450) {
				this.mapSentAt = now;
				this.netSend({
					k: "mp",
					m: this.mapId
				});
			}
		}
		if (this.phase === "waiting" && this.goAt && this.sideReady) {
			const left = (this.goAt - Date.now()) / 1e3;
			this.countdown = Math.max(0, left);
			if (left <= 0) {
				this.phase = "play";
				this.countdown = 0;
				this.status = "Noses in";
				this.publish(true);
			}
		}
		this.acc += dt;
		let steps = 0;
		while (this.acc >= STEP && steps < 5) {
			if (this.phase === "play") {
				this.sim.step(STEP, this.readActions());
				this.consume();
				this.watchWin();
			}
			this.acc -= STEP;
			steps += 1;
		}
		this.pumpNet(dt);
		if (this.banner && now > this.bannerUntil) {
			this.banner = "";
			this.publish(true);
		}
		const lead = this.net && this.remoteAt ? Math.min(.12, (performance.now() - this.remoteAt) / 1e3) : 0;
		const follow = this.phase === "play" || this.phase === "over" || this.phase === "waiting" && this.sideReady;
		this.view.render(this.sim, dt || STEP, follow, lead);
		this.publish(false);
		this.raf = requestAnimationFrame(this.frame);
	};
	readActions() {
		const keys = this.qa ?? this.keys;
		let strafe = 0;
		let thrust = 0;
		if (keys.has("KeyA") || keys.has("ArrowLeft")) strafe -= 1;
		if (keys.has("KeyD") || keys.has("ArrowRight")) strafe += 1;
		if (keys.has("KeyW") || keys.has("ArrowUp")) thrust += 1;
		if (keys.has("KeyS") || keys.has("ArrowDown")) thrust -= 1;
		if (this.qa === null && this.stick.on) {
			strafe = Math.max(-1, Math.min(1, this.stick.x));
			thrust = Math.max(-1, Math.min(1, this.stick.y));
		}
		if (this.qa === null) this.readPad(strafe, thrust);
		else return {
			strafe,
			thrust,
			fire: keys.has("Space") || keys.has("KeyJ"),
			boost: keys.has("ShiftLeft") || keys.has("ShiftRight") || keys.has("KeyK")
		};
		const pad = this.pad;
		return {
			strafe: pad.used ? pad.strafe : strafe,
			thrust: pad.used ? pad.thrust : thrust,
			fire: keys.has("Space") || keys.has("KeyJ") || this.fireHeld || this.pointerFire || pad.fire,
			boost: keys.has("ShiftLeft") || keys.has("ShiftRight") || keys.has("KeyK") || pad.boost || this.takeShield()
		};
	}
	takeShield() {
		const pressed = this.boostHeld || this.shieldQueued;
		this.shieldQueued = false;
		return pressed;
	}
	pad = {
		used: false,
		strafe: 0,
		thrust: 0,
		fire: false,
		boost: false
	};
	readPad(strafe, thrust) {
		this.pad.used = false;
		this.pad.strafe = strafe;
		this.pad.thrust = thrust;
		this.pad.fire = false;
		this.pad.boost = false;
		const pads = navigator.getGamepads?.();
		if (!pads) return;
		for (const pad of pads) {
			if (!pad) continue;
			const x = pad.axes[0] ?? 0;
			const y = pad.axes[1] ?? 0;
			if (Math.hypot(x, y) > .18) {
				this.pad.used = true;
				this.pad.strafe = Math.max(-1, Math.min(1, x));
				this.pad.thrust = Math.max(-1, Math.min(1, -y));
			}
			if (pad.buttons[0]?.pressed || pad.buttons[7]?.pressed) this.pad.fire = true;
			if (pad.buttons[1]?.pressed || pad.buttons[5]?.pressed || pad.buttons[6]?.pressed) this.pad.boost = true;
		}
	}
	consume() {
		for (const im of this.sim.impacts) {
			playFx(im.kind === "clang" ? "clang" : "hit");
			const color = im.owner === "you" ? AMBER : CYAN;
			this.view.burst(im.x, im.z, color, im.kind === "hit" ? 14 : 8, im.kind === "hit" ? 3 : 2.1);
			if (im.owner === "you") this.view.kick(im.kind === "hit" ? .34 : .12);
		}
		for (const fx of this.sim.fx) {
			playFx(fx);
			if (fx === "boom") {
				this.view.kick(.48);
				if (!this.sim.you.alive) {
					this.view.burst(this.sim.you.x, this.sim.you.z, AMBER, 30, 4.4);
					this.say("HULL LOST");
				}
				if (!this.sim.them.alive) {
					this.view.burst(this.sim.them.x, this.sim.them.z, CYAN, 30, 4.4);
					this.say("FRAG");
				}
			} else if (fx === "shot") this.view.burst(this.sim.you.x, this.sim.you.z, AMBER, 3, 1);
		}
		for (const ev of this.sim.events) if (ev.t === "chip") this.view.burst(ev.x, ev.z, 14272420, 6, 1.6);
		else if (ev.t === "blast") this.rockBlast(ev.x, ev.z);
		else if (ev.t === "reform") this.view.burst(ev.x, ev.z, 12055519, 8, 1.3);
		if (!this.net || !this.room) {
			this.sim.events.length = 0;
			return;
		}
		for (const ev of this.sim.events) if (ev.t === "shot") this.netSend({
			k: "sh",
			id: ev.id,
			x: ev.x,
			z: ev.z,
			dx: ev.dx,
			dz: ev.dz
		});
		else if (ev.t === "hit") this.netSend({
			k: "hit",
			id: ev.id
		});
		else if (ev.t === "down") this.netSend({ k: "dn" });
		else if (ev.t === "take") this.netSend({
			k: "tk",
			id: ev.id
		});
		else if (ev.t === "power") this.netSend({
			k: "pw",
			id: ev.power.id,
			kind: ev.power.kind,
			x: ev.power.x
		});
		else if (ev.t === "chip" || ev.t === "blast") this.netSend({
			k: "rk",
			i: ev.i
		});
	}
	netSend(msg) {
		if (!this.room) return;
		this.eid += 1;
		const wire = {
			...msg,
			e: `${this.selfId}:${this.epoch}:${this.eid}`
		};
		this.room.send(wire);
		this.room.relay(wire);
	}
	pumpNet(dt) {
		if (!this.room || !this.sideReady || this.phase !== "play" && this.phase !== "over") return;
		this.netAcc += dt;
		if (this.netAcc < .05) return;
		this.netAcc = 0;
		this.seq += 1;
		const s = this.sim.you;
		const packet = {
			k: "st",
			seq: this.seq,
			x: round(s.x),
			z: round(s.z),
			vx: round(s.vx),
			vz: round(s.vz),
			n: round(s.nose),
			hp: Math.round(s.hp),
			a: s.alive ? 1 : 0,
			fr: this.sim.frags,
			de: this.sim.deaths,
			sh: round(s.shield),
			rp: round(s.rapid),
			sp: round(s.spread),
			ep: this.epoch
		};
		if (this.link === "live") this.room.broadcast(packet);
		this.room.pushState(packet);
	}
	rockBlast(x, z) {
		playFx("boom");
		const dx = x - this.sim.you.x;
		const dz = z - this.sim.you.z;
		this.view.kick(dx * dx + dz * dz < 40 ? .3 : .1);
		this.view.burst(x, z, 15193006, 26, 3.6);
	}
	fragBurst(color, x, z) {
		playFx("boom");
		this.view.kick(.4);
		this.view.burst(x, z, color, 28, 4.2);
		this.say("FRAG");
	}
	watchWin() {
		if (this.phase !== "play" || !this.sim.over) return;
		this.phase = "over";
		this.say(this.sim.over === "you" ? "LANE CLEAR" : "LANE LOST");
		if (!this.net && this.sim.over === "you" && !this.winsStored) {
			this.winsStored = true;
			this.wardenWins += 1;
			try {
				localStorage.setItem("rift-duel-wins", String(this.wardenWins));
			} catch {}
		}
		this.publish(true);
	}
	say(text) {
		this.banner = text;
		this.bannerUntil = performance.now() + 1200;
		this.publish(true);
	}
	rememberName() {
		try {
			localStorage.setItem("rift-duel-name", this.youName);
		} catch {}
	}
	closeRoom() {
		this.room?.close();
		this.room = null;
	}
	publish(force) {
		setBed(this.phase === "play" || this.phase === "over" ? "fight" : "menu");
		const now = performance.now();
		const you = this.sim.you;
		const countdown = this.phase === "waiting" ? Math.ceil(this.countdown) : 0;
		const key = [
			this.phase,
			this.link,
			this.sim.frags,
			this.sim.deaths,
			this.sim.over,
			countdown,
			this.banner,
			this.status,
			this.themName,
			this.roomCode,
			this.muted,
			Math.round(you.hp),
			Math.round(this.sim.them.hp),
			you.shield > 0 ? 1 : 0,
			you.rapid > 0 ? 1 : 0,
			you.spread > 0 ? 1 : 0,
			this.mapId,
			this.rtt ?? ""
		].join("|");
		if (!force && key === this.hudKey && now - this.lastHud < 120) return;
		this.hudKey = key;
		this.lastHud = now;
		this.onHud({
			phase: this.phase,
			room: this.roomCode,
			youName: this.youName,
			themName: this.themName,
			youHp: you.hp,
			themHp: this.sim.them.hp,
			youFrags: this.sim.frags,
			themFrags: this.sim.deaths,
			fragsToWin: 4,
			shield: you.shield > 0,
			rapid: you.rapid > 0,
			spread: you.spread > 0,
			shieldCd: you.shield > 0 ? 0 : you.boostCd > 0 ? you.boostCd / SHIELD_CD : 0,
			banner: this.banner,
			status: this.status,
			winner: this.sim.over,
			rtt: this.rtt,
			link: this.link,
			muted: this.muted,
			wardenWins: this.wardenWins,
			countdown,
			net: this.net,
			map: this.mapId
		});
	}
};
function round(n) {
	return Math.round(n * 100) / 100;
}
function clearRiftQuery() {
	const url = new URL(window.location.href);
	if (!url.searchParams.has("rift")) return;
	url.searchParams.delete("rift");
	window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
}
function RiftApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const sessionRef = (0, import_react.useRef)(null);
	const [hud, setHud] = (0, import_react.useState)(INITIAL_HUD);
	const [name, setName] = (0, import_react.useState)("YOU");
	const [touch, setTouch] = (0, import_react.useState)(false);
	const [live, setLive] = (0, import_react.useState)(false);
	const [code, setCode] = (0, import_react.useState)("");
	(0, import_react.useLayoutEffect)(() => {
		setLive(true);
		const saved = localStorage.getItem("rift-duel-name");
		if (saved && saved.toUpperCase() !== "PILOT") setName(saved.slice(0, 12));
		const canvas = canvasRef.current;
		if (!canvas) return;
		const session = new RiftSession(canvas, setHud);
		sessionRef.current = session;
		session.start();
		clearRiftQuery();
		const unlock = () => unlockAudio();
		window.addEventListener("pointerdown", unlock);
		window.addEventListener("keydown", unlock);
		const mq = window.matchMedia("(pointer: coarse)");
		const apply = () => setTouch(mq.matches || window.innerWidth < 840);
		apply();
		mq.addEventListener("change", apply);
		window.addEventListener("resize", apply);
		return () => {
			session.dispose();
			sessionRef.current = null;
			window.removeEventListener("pointerdown", unlock);
			window.removeEventListener("keydown", unlock);
			mq.removeEventListener("change", apply);
			window.removeEventListener("resize", apply);
		};
	}, []);
	const playing = hud.phase === "play" || hud.phase === "over";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg select-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 z-0 h-full w-full touch-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "vignette pointer-events-none absolute inset-0",
				"data-sky": hud.map
			}),
			hud.phase === "title" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Center, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs font-semibold tracking-widest text-accent",
					children: "ARCADE LANE"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-5xl font-semibold tracking-wide text-fg",
					children: "Rift Duel"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: "Don't let your problems Win. get Busy!"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPick, {
					map: hud.map,
					onPick: (id) => sessionRef.current?.setMap(id)
				}),
				live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Callsign",
					value: name,
					onChange: setName,
					maxLength: 12
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-[4.75rem]" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"data-rift": "go",
					className: "relative z-20 mt-4 h-12 w-full bg-primary font-display text-base font-semibold tracking-wide text-bg",
					onClick: () => sessionRef.current?.startSolo(name),
					children: "Start"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-center text-xs text-muted",
					children: "Against Your Problem. It's not easy."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 h-11 w-full bg-accent font-display text-sm font-semibold tracking-wide text-bg",
					onClick: () => sessionRef.current?.host(makeCode(), name),
					children: "Create room"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Room code",
					value: code,
					onChange: setCode,
					maxLength: 4,
					wide: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 h-11 w-full border border-accent font-display text-sm font-semibold tracking-wide text-accent",
					onClick: () => sessionRef.current?.join(code, name),
					children: "Join room"
				}),
				hud.phase === "title" && hud.status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-center text-xs text-muted",
					children: hud.status
				}) : null,
				hud.wardenWins > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-center text-xs text-muted",
					children: ["Problems down ", hud.wardenWins]
				}) : null
			] }) : null,
			hud.phase === "waiting" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Center, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs font-semibold tracking-widest text-accent",
					children: hud.link === "lost" ? "RECONNECTING" : hud.status.startsWith("Connecting") ? "CONNECTING" : "IN ROOM"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center font-display text-5xl font-semibold tracking-[0.28em] text-fg",
					children: hud.room
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-sm leading-relaxed text-muted",
					children: hud.status
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-center text-xs text-muted",
					children: "Both phones open this same page. Different Wi-Fi is fine."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-5 h-11 w-full border border-border font-display text-sm font-semibold text-fg",
					onClick: () => sessionRef.current?.leave(),
					children: "Back"
				})
			] }) : null,
			hud.countdown > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-8xl font-semibold text-fg",
					children: hud.countdown
				})
			}) : null,
			playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
						name: hud.youName,
						frags: hud.youFrags,
						hp: hud.youHp,
						tone: "primary",
						align: "start"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-auto flex flex-col items-center gap-2 pt-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-xs tracking-widest text-muted",
								children: ["FIRST TO ", 4]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xs tracking-widest text-accent",
								children: MAPS.find((m) => m.id === hud.map)?.name ?? "Night"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 border border-border bg-surface px-3 font-display text-xs font-semibold text-fg",
									onClick: () => {
										clearRiftQuery();
										sessionRef.current?.leave();
									},
									children: "Bay"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": hud.muted ? "Unmute" : "Mute",
									className: "flex h-11 w-11 items-center justify-center border border-border bg-surface text-fg",
									onClick: () => sessionRef.current?.toggleMute(),
									children: hud.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
						name: hud.themName,
						frags: hud.themFrags,
						hp: hud.themHp,
						tone: "accent",
						align: "end"
					})
				]
			}) : null,
			hud.phase === "play" && hud.banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pointer-events-none absolute top-28 left-1/2 -translate-x-1/2 font-display text-2xl font-semibold tracking-widest text-fg",
				children: hud.banner
			}) : null,
			hud.phase === "play" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute top-24 left-3 flex gap-2",
				children: [
					hud.rapid ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: "RAPID" }) : null,
					hud.spread ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: "SPREAD" }) : null,
					hud.shield ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: "SHIELD" }) : null
				]
			}) : null,
			hud.phase === "play" && !touch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pointer-events-none absolute bottom-4 left-1/2 -translate-x-1/2 text-center text-xs text-muted",
				children: "A D slide · W S push · Space fire · Shift shield"
			}) : null,
			hud.phase === "play" && hud.net ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pointer-events-none absolute right-3 bottom-4 font-display text-xs text-muted",
				children: hud.link === "live" && hud.rtt !== null ? `${hud.rtt} ms` : hud.link === "live" ? "LIVE" : hud.link === "lost" ? "RECONNECTING" : "WAITING"
			}) : null,
			hud.phase === "over" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Center, {
				pin: "center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs tracking-widest text-accent",
						children: hud.winner === "you" ? "YOU HOLD THE RIFT" : "RIFT LOST"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-4xl font-semibold text-fg",
						children: hud.winner === "you" ? "Lane clear" : "Lane lost"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-display text-2xl text-fg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: hud.youFrags
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: " — "
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-accent",
								children: hud.themFrags
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-5 h-12 w-full bg-primary font-display text-base font-semibold text-bg",
						onClick: () => sessionRef.current?.rematch(),
						children: "Rematch"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 h-11 w-full text-sm text-muted",
						onClick: () => {
							clearRiftQuery();
							sessionRef.current?.leave();
						},
						children: "Back to bay"
					})
				]
			}) : null,
			touch && hud.phase === "play" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dock pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, { onChange: (x, y, active) => sessionRef.current?.setStick(x, y, active) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex flex-col items-end gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: hud.shield ? "relative h-12 w-24 overflow-hidden border border-accent bg-accent font-display text-xs font-semibold text-bg" : hud.shieldCd > 0 ? "relative h-12 w-24 overflow-hidden border border-border bg-surface font-display text-xs font-semibold text-muted" : "relative h-12 w-24 overflow-hidden bg-accent font-display text-xs font-semibold text-bg",
						onPointerDown: (e) => {
							e.preventDefault();
							e.currentTarget.setPointerCapture(e.pointerId);
							sessionRef.current?.setBoost(true);
						},
						onPointerUp: () => sessionRef.current?.setBoost(false),
						onPointerCancel: () => sessionRef.current?.setBoost(false),
						children: [hud.shieldCd > 0 && !hud.shield ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute inset-y-0 left-0 bg-accent/30",
							style: { width: `${Math.round((1 - hud.shieldCd) * 100)}%` }
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "relative",
							children: hud.shield ? "Up" : hud.shieldCd > 0 ? "Regen" : "Shield"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-20 w-20 bg-primary font-display text-sm font-semibold text-bg",
						onPointerDown: (e) => {
							e.preventDefault();
							e.currentTarget.setPointerCapture(e.pointerId);
							sessionRef.current?.setFire(true);
						},
						onPointerUp: () => sessionRef.current?.setFire(false),
						onPointerCancel: () => sessionRef.current?.setFire(false),
						children: "Fire"
					})]
				})]
			}) : null
		]
	});
}
function makeCode() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	let code = "";
	for (let i = 0; i < 4; i += 1) code += alphabet[Math.floor(Math.random() * 32)];
	return code;
}
function Center({ children, pin = "top" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `pointer-events-none absolute inset-0 z-10 flex justify-center p-4 ${pin === "center" ? "items-center" : "items-start pt-4 sm:items-center sm:pt-4"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "pointer-events-auto max-h-dvh w-full max-w-md overflow-y-auto border border-border bg-surface p-5",
			children
		})
	});
}
function MapPick({ map, onPick }) {
	const current = MAPS.find((m) => m.id === map) ?? MAPS[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-widest text-muted uppercase",
				children: "Map"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 grid grid-cols-3 gap-2",
				children: MAPS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: m.id === map ? "h-11 border border-accent bg-bg px-1 font-display text-[11px] font-semibold text-accent" : "h-11 border border-border bg-bg px-1 font-display text-[11px] font-semibold text-muted",
					onClick: () => onPick(m.id),
					children: m.name
				}, m.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted",
				children: current.blurb
			})
		]
	});
}
function Field({ label, value, onChange, maxLength, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mt-4 block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium tracking-widest text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			maxLength,
			autoCapitalize: wide ? "characters" : "words",
			autoComplete: "off",
			spellCheck: false,
			onChange: (e) => onChange(e.target.value),
			className: `mt-1 h-12 w-full border border-border bg-bg px-3 text-fg outline-none select-text focus:border-accent ${wide ? "font-display text-2xl tracking-widest" : "text-base"}`
		})]
	});
}
function Score({ name, frags, hp, tone, align }) {
	const bar = tone === "primary" ? "bg-primary" : "bg-accent";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `max-w-[7.2rem] ${align === "end" ? "text-right" : "text-left"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-tight tracking-wide text-muted",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `font-display text-3xl font-semibold ${tone === "primary" ? "text-primary" : "text-accent"}`,
				children: frags
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-1 flex gap-1 ${align === "end" ? "justify-end" : ""}`,
				children: Array.from({ length: 4 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-3 ${i < frags ? bar : "bg-border"}` }, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 h-1.5 w-full bg-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `h-full ${bar}`,
					style: { width: `${Math.max(0, Math.min(100, hp))}%` }
				})
			})
		]
	});
}
function Chip({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "border border-accent bg-bg px-2 py-1 font-display text-xs font-semibold tracking-widest text-accent",
		children
	});
}
function Stick({ onChange }) {
	const ref = (0, import_react.useRef)(null);
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	function move(clientX, clientY) {
		const el = ref.current;
		if (!el) return;
		const rect = el.getBoundingClientRect();
		const max = rect.width * .34;
		let x = (clientX - (rect.left + rect.width / 2)) / max;
		let y = -(clientY - (rect.top + rect.height / 2)) / max;
		const mag = Math.hypot(x, y);
		if (mag > 1) {
			x /= mag;
			y /= mag;
		}
		setKnob({
			x: x * max,
			y: -y * max
		});
		onChange(x, y, true);
	}
	function release() {
		setKnob({
			x: 0,
			y: 0
		});
		onChange(0, 0, false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "relative h-32 w-32 touch-none rounded-full border border-border bg-bg/80",
		onPointerDown: (e) => {
			e.preventDefault();
			e.currentTarget.setPointerCapture(e.pointerId);
			move(e.clientX, e.clientY);
		},
		onPointerMove: (e) => {
			if (e.currentTarget.hasPointerCapture(e.pointerId)) move(e.clientX, e.clientY);
		},
		onPointerUp: release,
		onPointerCancel: release,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute top-1/2 left-1/2 h-12 w-12 rounded-full bg-primary",
			style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RiftApp, {});
}
//#endregion
export { Home as component };
