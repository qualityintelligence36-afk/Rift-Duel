//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CKP2NM2Y.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/rtc"],
		preloads: ["/assets/index-CrHCvpWF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CrHCvpWF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-a8jgq42P.js"]
	}
} });
//#endregion
export { tsrStartManifest };
