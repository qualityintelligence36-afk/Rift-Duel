import { i as __require } from "../_runtime.mjs";
import { createRequire } from "module";
//#region node_modules/@colyseus/msgpackr/unpack.js
var decoder;
try {
	decoder = new TextDecoder();
} catch (error) {}
var src;
var srcEnd;
var position$1 = 0;
var EMPTY_ARRAY = [];
var strings = EMPTY_ARRAY;
var stringPosition = 0;
var currentUnpackr = {};
var currentStructures;
var srcString;
var srcStringStart = 0;
var srcStringEnd = 0;
var bundledStrings$1;
var referenceMap;
var currentExtensions = [];
var dataView;
var defaultOptions = {
	useRecords: false,
	mapsAsObjects: true
};
var C1Type = class {};
var C1 = new C1Type();
C1.name = "MessagePack 0xC1";
var sequentialMode = false;
var inlineObjectReadThreshold = 2;
var readStruct$1;
var onLoadedStructures$1;
var onSaveState;
try {
	new Function("");
} catch (error) {
	inlineObjectReadThreshold = Infinity;
}
var Unpackr = class Unpackr {
	constructor(options) {
		if (options) {
			if (options.useRecords === false && options.mapsAsObjects === void 0) options.mapsAsObjects = true;
			if (options.sequential && options.trusted !== false) {
				options.trusted = true;
				if (!options.structures && options.useRecords != false) {
					options.structures = [];
					if (!options.maxSharedStructures) options.maxSharedStructures = 0;
				}
			}
			if (options.structures) options.structures.sharedLength = options.structures.length;
			else if (options.getStructures) {
				(options.structures = []).uninitialized = true;
				options.structures.sharedLength = 0;
			}
			if (options.int64AsNumber) options.int64AsType = "number";
		}
		Object.assign(this, options);
	}
	unpack(source, options) {
		if (src) return saveState$1(() => {
			clearSource();
			return this ? this.unpack(source, options) : Unpackr.prototype.unpack.call(defaultOptions, source, options);
		});
		if (!source.buffer && source.constructor === ArrayBuffer) source = typeof Buffer !== "undefined" ? Buffer.from(source) : new Uint8Array(source);
		if (typeof options === "object") {
			srcEnd = options.end || source.length;
			position$1 = options.start || 0;
		} else {
			position$1 = 0;
			srcEnd = options > -1 ? options : source.length;
		}
		stringPosition = 0;
		srcStringEnd = 0;
		srcString = null;
		strings = EMPTY_ARRAY;
		bundledStrings$1 = null;
		src = source;
		try {
			dataView = source.dataView || (source.dataView = new DataView(source.buffer, source.byteOffset, source.byteLength));
		} catch (error) {
			src = null;
			if (source instanceof Uint8Array) throw error;
			throw new Error("Source must be a Uint8Array or Buffer but was a " + (source && typeof source == "object" ? source.constructor.name : typeof source));
		}
		if (this instanceof Unpackr) {
			currentUnpackr = this;
			if (this.structures) {
				currentStructures = this.structures;
				return checkedRead(options);
			} else if (!currentStructures || currentStructures.length > 0) currentStructures = [];
		} else {
			currentUnpackr = defaultOptions;
			if (!currentStructures || currentStructures.length > 0) currentStructures = [];
		}
		return checkedRead(options);
	}
	unpackMultiple(source, forEach) {
		let values, lastPosition = 0;
		try {
			sequentialMode = true;
			let size = source.length;
			let value = this ? this.unpack(source, size) : defaultUnpackr.unpack(source, size);
			if (forEach) {
				if (forEach(value, lastPosition, position$1) === false) return;
				while (position$1 < size) {
					lastPosition = position$1;
					if (forEach(checkedRead(), lastPosition, position$1) === false) return;
				}
			} else {
				values = [value];
				while (position$1 < size) {
					lastPosition = position$1;
					values.push(checkedRead());
				}
				return values;
			}
		} catch (error) {
			error.lastPosition = lastPosition;
			error.values = values;
			throw error;
		} finally {
			sequentialMode = false;
			clearSource();
		}
	}
	_mergeStructures(loadedStructures, existingStructures) {
		if (onLoadedStructures$1) loadedStructures = onLoadedStructures$1.call(this, loadedStructures);
		loadedStructures = loadedStructures || [];
		if (Object.isFrozen(loadedStructures)) loadedStructures = loadedStructures.map((structure) => structure.slice(0));
		for (let i = 0, l = loadedStructures.length; i < l; i++) {
			let structure = loadedStructures[i];
			if (structure) {
				structure.isShared = true;
				if (i >= 32) structure.highByte = i - 32 >> 5;
			}
		}
		loadedStructures.sharedLength = loadedStructures.length;
		for (let id in existingStructures || []) if (id >= 0) {
			let structure = loadedStructures[id];
			let existing = existingStructures[id];
			if (existing) {
				if (structure) (loadedStructures.restoreStructures || (loadedStructures.restoreStructures = []))[id] = structure;
				loadedStructures[id] = existing;
			}
		}
		return this.structures = loadedStructures;
	}
	decode(source, options) {
		return this.unpack(source, options);
	}
};
function checkedRead(options) {
	try {
		if (!currentUnpackr.trusted && !sequentialMode) {
			let sharedLength = currentStructures.sharedLength || 0;
			if (sharedLength < currentStructures.length) currentStructures.length = sharedLength;
		}
		let result;
		if (currentUnpackr.randomAccessStructure && src[position$1] < 64 && src[position$1] >= 32 && readStruct$1) {
			result = readStruct$1(src, position$1, srcEnd, currentUnpackr);
			src = null;
			if (!(options && options.lazy) && result) result = result.toJSON();
			position$1 = srcEnd;
		} else result = read();
		if (bundledStrings$1) {
			position$1 = bundledStrings$1.postBundlePosition;
			bundledStrings$1 = null;
		}
		if (sequentialMode) currentStructures.restoreStructures = null;
		if (position$1 == srcEnd) {
			if (currentStructures && currentStructures.restoreStructures) restoreStructures();
			currentStructures = null;
			src = null;
			if (referenceMap) referenceMap = null;
		} else if (position$1 > srcEnd) throw new Error("Unexpected end of MessagePack data");
		else if (!sequentialMode) {
			let jsonView;
			try {
				jsonView = JSON.stringify(result, (_, value) => typeof value === "bigint" ? `${value}n` : value).slice(0, 100);
			} catch (error) {
				jsonView = "(JSON view not available " + error + ")";
			}
			throw new Error("Data read, but end of buffer not reached " + jsonView);
		}
		return result;
	} catch (error) {
		if (currentStructures && currentStructures.restoreStructures) restoreStructures();
		clearSource();
		if (error instanceof RangeError || error.message.startsWith("Unexpected end of buffer") || position$1 > srcEnd) error.incomplete = true;
		throw error;
	}
}
function restoreStructures() {
	for (let id in currentStructures.restoreStructures) currentStructures[id] = currentStructures.restoreStructures[id];
	currentStructures.restoreStructures = null;
}
function read() {
	let token = src[position$1++];
	if (token < 160) {
		if (token < 128) {
			if (token < 64) return token;
			else {
				let structure = currentStructures[token & 63] || currentUnpackr.getStructures && loadStructures()[token & 63];
				if (structure) {
					if (!structure.read) structure.read = createStructureReader(structure, token & 63);
					return structure.read();
				} else return token;
			}
		} else if (token < 144) {
			token -= 128;
			if (currentUnpackr.mapsAsObjects) {
				let object = {};
				for (let i = 0; i < token; i++) {
					let key = readKey();
					if (key === "__proto__") key = "__proto_";
					object[key] = read();
				}
				return object;
			} else {
				let map = /* @__PURE__ */ new Map();
				for (let i = 0; i < token; i++) map.set(read(), read());
				return map;
			}
		} else {
			token -= 144;
			let array = new Array(token);
			for (let i = 0; i < token; i++) array[i] = read();
			if (currentUnpackr.freezeData) return Object.freeze(array);
			return array;
		}
	} else if (token < 192) {
		let length = token - 160;
		if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += length) - srcStringStart);
		if (srcStringEnd == 0 && srcEnd < 140) {
			let string = length < 16 ? shortStringInJS(length) : longStringInJS(length);
			if (string != null) return string;
		}
		return readFixedString(length);
	} else {
		let value;
		switch (token) {
			case 192: return null;
			case 193:
				if (bundledStrings$1) {
					value = read();
					if (value > 0) return bundledStrings$1[1].slice(bundledStrings$1.position1, bundledStrings$1.position1 += value);
					else return bundledStrings$1[0].slice(bundledStrings$1.position0, bundledStrings$1.position0 -= value);
				}
				return C1;
			case 194: return false;
			case 195: return true;
			case 196:
				value = src[position$1++];
				if (value === void 0) throw new Error("Unexpected end of buffer");
				return readBin(value);
			case 197:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return readBin(value);
			case 198:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return readBin(value);
			case 199: return readExt(src[position$1++]);
			case 200:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return readExt(value);
			case 201:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return readExt(value);
			case 202:
				value = dataView.getFloat32(position$1);
				if (currentUnpackr.useFloat32 > 2) {
					let multiplier = mult10[(src[position$1] & 127) << 1 | src[position$1 + 1] >> 7];
					position$1 += 4;
					return (multiplier * value + (value > 0 ? .5 : -.5) >> 0) / multiplier;
				}
				position$1 += 4;
				return value;
			case 203:
				value = dataView.getFloat64(position$1);
				position$1 += 8;
				return value;
			case 204: return src[position$1++];
			case 205:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return value;
			case 206:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return value;
			case 207:
				if (currentUnpackr.int64AsType === "number") {
					value = dataView.getUint32(position$1) * 4294967296;
					value += dataView.getUint32(position$1 + 4);
				} else if (currentUnpackr.int64AsType === "string") value = dataView.getBigUint64(position$1).toString();
				else if (currentUnpackr.int64AsType === "auto") {
					value = dataView.getBigUint64(position$1);
					if (value <= BigInt(2) << BigInt(52)) value = Number(value);
				} else value = dataView.getBigUint64(position$1);
				position$1 += 8;
				return value;
			case 208: return dataView.getInt8(position$1++);
			case 209:
				value = dataView.getInt16(position$1);
				position$1 += 2;
				return value;
			case 210:
				value = dataView.getInt32(position$1);
				position$1 += 4;
				return value;
			case 211:
				if (currentUnpackr.int64AsType === "number") {
					value = dataView.getInt32(position$1) * 4294967296;
					value += dataView.getUint32(position$1 + 4);
				} else if (currentUnpackr.int64AsType === "string") value = dataView.getBigInt64(position$1).toString();
				else if (currentUnpackr.int64AsType === "auto") {
					value = dataView.getBigInt64(position$1);
					if (value >= BigInt(-2) << BigInt(52) && value <= BigInt(2) << BigInt(52)) value = Number(value);
				} else value = dataView.getBigInt64(position$1);
				position$1 += 8;
				return value;
			case 212:
				value = src[position$1++];
				if (value == 114) return recordDefinition(src[position$1++] & 63);
				else {
					let extension = currentExtensions[value];
					if (extension) {
						if (extension.read) {
							position$1++;
							return extension.read(read());
						} else if (extension.noBuffer) {
							position$1++;
							return extension();
						} else return extension(src.subarray(position$1, ++position$1));
					} else throw new Error("Unknown extension " + value);
				}
			case 213:
				value = src[position$1];
				if (value == 114) {
					position$1++;
					return recordDefinition(src[position$1++] & 63, src[position$1++]);
				} else return readExt(2);
			case 214: return readExt(4);
			case 215: return readExt(8);
			case 216: return readExt(16);
			case 217:
				value = src[position$1++];
				if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += value) - srcStringStart);
				return readString8(value);
			case 218:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += value) - srcStringStart);
				return readString16(value);
			case 219:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += value) - srcStringStart);
				return readString32(value);
			case 220:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return readArray(value);
			case 221:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return readArray(value);
			case 222:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return readMap(value);
			case 223:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return readMap(value);
			default:
				if (token >= 224) return token - 256;
				if (token === void 0) {
					let error = /* @__PURE__ */ new Error("Unexpected end of MessagePack data");
					error.incomplete = true;
					throw error;
				}
				throw new Error("Unknown MessagePack token " + token);
		}
	}
}
var validName = /^[a-zA-Z_$][a-zA-Z\d_$]*$/;
function createStructureReader(structure, firstId) {
	function readObject() {
		if (readObject.count++ > inlineObjectReadThreshold) {
			let readObject = structure.read = new Function("r", "return function(){return " + (currentUnpackr.freezeData ? "Object.freeze" : "") + "({" + structure.map((key) => key === "__proto__" ? "__proto_:r()" : validName.test(key) ? key + ":r()" : "[" + JSON.stringify(key) + "]:r()").join(",") + "})}")(read);
			if (structure.highByte === 0) structure.read = createSecondByteReader(firstId, structure.read);
			return readObject();
		}
		let object = {};
		for (let i = 0, l = structure.length; i < l; i++) {
			let key = structure[i];
			if (key === "__proto__") key = "__proto_";
			object[key] = read();
		}
		if (currentUnpackr.freezeData) return Object.freeze(object);
		return object;
	}
	readObject.count = 0;
	if (structure.highByte === 0) return createSecondByteReader(firstId, readObject);
	return readObject;
}
var createSecondByteReader = (firstId, read0) => {
	return function() {
		let highByte = src[position$1++];
		if (highByte === 0) return read0();
		let id = firstId < 32 ? -(firstId + (highByte << 5)) : firstId + (highByte << 5);
		let structure = currentStructures[id] || loadStructures()[id];
		if (!structure) throw new Error("Record id is not defined for " + id);
		if (!structure.read) structure.read = createStructureReader(structure, firstId);
		return structure.read();
	};
};
function loadStructures() {
	let loadedStructures = saveState$1(() => {
		src = null;
		return currentUnpackr.getStructures();
	});
	return currentStructures = currentUnpackr._mergeStructures(loadedStructures, currentStructures);
}
var readFixedString = readStringJS;
var readString8 = readStringJS;
var readString16 = readStringJS;
var readString32 = readStringJS;
function setExtractor(extractStrings) {
	readFixedString = readString(1);
	readString8 = readString(2);
	readString16 = readString(3);
	readString32 = readString(5);
	function readString(headerLength) {
		return function readString(length) {
			let string = strings[stringPosition++];
			if (string == null) {
				if (bundledStrings$1) return readStringJS(length);
				let byteOffset = src.byteOffset;
				let extraction = extractStrings(position$1 - headerLength + byteOffset, srcEnd + byteOffset, src.buffer);
				if (typeof extraction == "string") {
					string = extraction;
					strings = EMPTY_ARRAY;
				} else {
					strings = extraction;
					stringPosition = 1;
					srcStringEnd = 1;
					string = strings[0];
					if (string === void 0) throw new Error("Unexpected end of buffer");
				}
			}
			let srcStringLength = string.length;
			if (srcStringLength <= length) {
				position$1 += length;
				return string;
			}
			srcString = string;
			srcStringStart = position$1;
			srcStringEnd = position$1 + srcStringLength;
			position$1 += length;
			return string.slice(0, length);
		};
	}
}
function readStringJS(length) {
	let result;
	if (length < 16) {
		if (result = shortStringInJS(length)) return result;
	}
	if (length > 64 && decoder) return decoder.decode(src.subarray(position$1, position$1 += length));
	const end = position$1 + length;
	const units = [];
	result = "";
	while (position$1 < end) {
		const byte1 = src[position$1++];
		if ((byte1 & 128) === 0) units.push(byte1);
		else if ((byte1 & 224) === 192) {
			const byte2 = src[position$1++] & 63;
			units.push((byte1 & 31) << 6 | byte2);
		} else if ((byte1 & 240) === 224) {
			const byte2 = src[position$1++] & 63;
			const byte3 = src[position$1++] & 63;
			units.push((byte1 & 31) << 12 | byte2 << 6 | byte3);
		} else if ((byte1 & 248) === 240) {
			const byte2 = src[position$1++] & 63;
			const byte3 = src[position$1++] & 63;
			const byte4 = src[position$1++] & 63;
			let unit = (byte1 & 7) << 18 | byte2 << 12 | byte3 << 6 | byte4;
			if (unit > 65535) {
				unit -= 65536;
				units.push(unit >>> 10 & 1023 | 55296);
				unit = 56320 | unit & 1023;
			}
			units.push(unit);
		} else units.push(byte1);
		if (units.length >= 4096) {
			result += fromCharCode.apply(String, units);
			units.length = 0;
		}
	}
	if (units.length > 0) result += fromCharCode.apply(String, units);
	return result;
}
function readString(source, start, length) {
	let existingSrc = src;
	src = source;
	position$1 = start;
	try {
		return readStringJS(length);
	} finally {
		src = existingSrc;
	}
}
function readArray(length) {
	let array = new Array(length);
	for (let i = 0; i < length; i++) array[i] = read();
	if (currentUnpackr.freezeData) return Object.freeze(array);
	return array;
}
function readMap(length) {
	if (currentUnpackr.mapsAsObjects) {
		let object = {};
		for (let i = 0; i < length; i++) {
			let key = readKey();
			if (key === "__proto__") key = "__proto_";
			object[key] = read();
		}
		return object;
	} else {
		let map = /* @__PURE__ */ new Map();
		for (let i = 0; i < length; i++) map.set(read(), read());
		return map;
	}
}
var fromCharCode = String.fromCharCode;
function longStringInJS(length) {
	let start = position$1;
	let bytes = new Array(length);
	for (let i = 0; i < length; i++) {
		const byte = src[position$1++];
		if ((byte & 128) > 0) {
			position$1 = start;
			return;
		}
		bytes[i] = byte;
	}
	return fromCharCode.apply(String, bytes);
}
function shortStringInJS(length) {
	if (length < 4) {
		if (length < 2) {
			if (length === 0) return "";
			else {
				let a = src[position$1++];
				if ((a & 128) > 1) {
					position$1 -= 1;
					return;
				}
				return fromCharCode(a);
			}
		} else {
			let a = src[position$1++];
			let b = src[position$1++];
			if ((a & 128) > 0 || (b & 128) > 0) {
				position$1 -= 2;
				return;
			}
			if (length < 3) return fromCharCode(a, b);
			let c = src[position$1++];
			if ((c & 128) > 0) {
				position$1 -= 3;
				return;
			}
			return fromCharCode(a, b, c);
		}
	} else {
		let a = src[position$1++];
		let b = src[position$1++];
		let c = src[position$1++];
		let d = src[position$1++];
		if ((a & 128) > 0 || (b & 128) > 0 || (c & 128) > 0 || (d & 128) > 0) {
			position$1 -= 4;
			return;
		}
		if (length < 6) {
			if (length === 4) return fromCharCode(a, b, c, d);
			else {
				let e = src[position$1++];
				if ((e & 128) > 0) {
					position$1 -= 5;
					return;
				}
				return fromCharCode(a, b, c, d, e);
			}
		} else if (length < 8) {
			let e = src[position$1++];
			let f = src[position$1++];
			if ((e & 128) > 0 || (f & 128) > 0) {
				position$1 -= 6;
				return;
			}
			if (length < 7) return fromCharCode(a, b, c, d, e, f);
			let g = src[position$1++];
			if ((g & 128) > 0) {
				position$1 -= 7;
				return;
			}
			return fromCharCode(a, b, c, d, e, f, g);
		} else {
			let e = src[position$1++];
			let f = src[position$1++];
			let g = src[position$1++];
			let h = src[position$1++];
			if ((e & 128) > 0 || (f & 128) > 0 || (g & 128) > 0 || (h & 128) > 0) {
				position$1 -= 8;
				return;
			}
			if (length < 10) {
				if (length === 8) return fromCharCode(a, b, c, d, e, f, g, h);
				else {
					let i = src[position$1++];
					if ((i & 128) > 0) {
						position$1 -= 9;
						return;
					}
					return fromCharCode(a, b, c, d, e, f, g, h, i);
				}
			} else if (length < 12) {
				let i = src[position$1++];
				let j = src[position$1++];
				if ((i & 128) > 0 || (j & 128) > 0) {
					position$1 -= 10;
					return;
				}
				if (length < 11) return fromCharCode(a, b, c, d, e, f, g, h, i, j);
				let k = src[position$1++];
				if ((k & 128) > 0) {
					position$1 -= 11;
					return;
				}
				return fromCharCode(a, b, c, d, e, f, g, h, i, j, k);
			} else {
				let i = src[position$1++];
				let j = src[position$1++];
				let k = src[position$1++];
				let l = src[position$1++];
				if ((i & 128) > 0 || (j & 128) > 0 || (k & 128) > 0 || (l & 128) > 0) {
					position$1 -= 12;
					return;
				}
				if (length < 14) {
					if (length === 12) return fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l);
					else {
						let m = src[position$1++];
						if ((m & 128) > 0) {
							position$1 -= 13;
							return;
						}
						return fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m);
					}
				} else {
					let m = src[position$1++];
					let n = src[position$1++];
					if ((m & 128) > 0 || (n & 128) > 0) {
						position$1 -= 14;
						return;
					}
					if (length < 15) return fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n);
					let o = src[position$1++];
					if ((o & 128) > 0) {
						position$1 -= 15;
						return;
					}
					return fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o);
				}
			}
		}
	}
}
function readOnlyJSString() {
	let token = src[position$1++];
	let length;
	if (token < 192) length = token - 160;
	else switch (token) {
		case 217:
			length = src[position$1++];
			break;
		case 218:
			length = dataView.getUint16(position$1);
			position$1 += 2;
			break;
		case 219:
			length = dataView.getUint32(position$1);
			position$1 += 4;
			break;
		default: throw new Error("Expected string");
	}
	return readStringJS(length);
}
function readBin(length) {
	return currentUnpackr.copyBuffers ? Uint8Array.prototype.slice.call(src, position$1, position$1 += length) : src.subarray(position$1, position$1 += length);
}
function readExt(length) {
	let type = src[position$1++];
	if (currentExtensions[type]) {
		let end;
		return currentExtensions[type](src.subarray(position$1, end = position$1 += length), (readPosition) => {
			position$1 = readPosition;
			try {
				return read();
			} finally {
				position$1 = end;
			}
		});
	} else throw new Error("Unknown extension type " + type);
}
var keyCache = new Array(4096);
function readKey() {
	let length = src[position$1++];
	if (length >= 160 && length < 192) {
		length = length - 160;
		if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += length) - srcStringStart);
		else if (!(srcStringEnd == 0 && srcEnd < 180)) return readFixedString(length);
	} else {
		position$1--;
		return asSafeString(read());
	}
	let key = (length << 5 ^ (length > 1 ? dataView.getUint16(position$1) : length > 0 ? src[position$1] : 0)) & 4095;
	let entry = keyCache[key];
	let checkPosition = position$1;
	let end = position$1 + length - 3;
	let chunk;
	let i = 0;
	if (entry && entry.bytes == length) {
		while (checkPosition < end) {
			chunk = dataView.getUint32(checkPosition);
			if (chunk != entry[i++]) {
				checkPosition = 1879048192;
				break;
			}
			checkPosition += 4;
		}
		end += 3;
		while (checkPosition < end) {
			chunk = src[checkPosition++];
			if (chunk != entry[i++]) {
				checkPosition = 1879048192;
				break;
			}
		}
		if (checkPosition === end) {
			position$1 = checkPosition;
			return entry.string;
		}
		end -= 3;
		checkPosition = position$1;
	}
	entry = [];
	keyCache[key] = entry;
	entry.bytes = length;
	while (checkPosition < end) {
		chunk = dataView.getUint32(checkPosition);
		entry.push(chunk);
		checkPosition += 4;
	}
	end += 3;
	while (checkPosition < end) {
		chunk = src[checkPosition++];
		entry.push(chunk);
	}
	let string = length < 16 ? shortStringInJS(length) : longStringInJS(length);
	if (string != null) return entry.string = string;
	return entry.string = readFixedString(length);
}
function asSafeString(property) {
	if (typeof property === "string") return property;
	if (typeof property === "number" || typeof property === "boolean" || typeof property === "bigint") return property.toString();
	if (property == null) return property + "";
	if (currentUnpackr.allowArraysInMapKeys && Array.isArray(property) && property.flat().every((item) => [
		"string",
		"number",
		"boolean",
		"bigint"
	].includes(typeof item))) return property.flat().toString();
	throw new Error(`Invalid property type for record: ${typeof property}`);
}
var recordDefinition = (id, highByte) => {
	let structure = read().map(asSafeString);
	let firstByte = id;
	if (highByte !== void 0) {
		id = id < 32 ? -((highByte << 5) + id) : (highByte << 5) + id;
		structure.highByte = highByte;
	}
	let existingStructure = currentStructures[id];
	if (existingStructure && (existingStructure.isShared || sequentialMode)) (currentStructures.restoreStructures || (currentStructures.restoreStructures = []))[id] = existingStructure;
	currentStructures[id] = structure;
	structure.read = createStructureReader(structure, firstByte);
	return structure.read();
};
currentExtensions[0] = () => {};
currentExtensions[0].noBuffer = true;
currentExtensions[66] = (data) => {
	let length = data.length;
	let value = BigInt(data[0] & 128 ? data[0] - 256 : data[0]);
	for (let i = 1; i < length; i++) {
		value <<= BigInt(8);
		value += BigInt(data[i]);
	}
	return value;
};
var errors = {
	Error,
	TypeError,
	ReferenceError
};
currentExtensions[101] = () => {
	let data = read();
	return (errors[data[0]] || Error)(data[1], { cause: data[2] });
};
currentExtensions[105] = (data) => {
	if (currentUnpackr.structuredClone === false) throw new Error("Structured clone extension is disabled");
	let id = dataView.getUint32(position$1 - 4);
	if (!referenceMap) referenceMap = /* @__PURE__ */ new Map();
	let token = src[position$1];
	let target;
	if (token >= 144 && token < 160 || token == 220 || token == 221) target = [];
	else target = {};
	let refEntry = { target };
	referenceMap.set(id, refEntry);
	let targetProperties = read();
	if (refEntry.used) return Object.assign(target, targetProperties);
	refEntry.target = targetProperties;
	return targetProperties;
};
currentExtensions[112] = (data) => {
	if (currentUnpackr.structuredClone === false) throw new Error("Structured clone extension is disabled");
	let id = dataView.getUint32(position$1 - 4);
	let refEntry = referenceMap.get(id);
	refEntry.used = true;
	return refEntry.target;
};
currentExtensions[115] = () => new Set(read());
var typedArrays = [
	"Int8",
	"Uint8",
	"Uint8Clamped",
	"Int16",
	"Uint16",
	"Int32",
	"Uint32",
	"Float32",
	"Float64",
	"BigInt64",
	"BigUint64"
].map((type) => type + "Array");
var glbl = typeof globalThis === "object" ? globalThis : window;
currentExtensions[116] = (data) => {
	let typeCode = data[0];
	let typedArrayName = typedArrays[typeCode];
	if (!typedArrayName) {
		if (typeCode === 16) {
			let ab = /* @__PURE__ */ new ArrayBuffer(data.length - 1);
			new Uint8Array(ab).set(data.subarray(1));
			return ab;
		}
		throw new Error("Could not find typed array for code " + typeCode);
	}
	return new glbl[typedArrayName](Uint8Array.prototype.slice.call(data, 1).buffer);
};
currentExtensions[120] = () => {
	let data = read();
	return new RegExp(data[0], data[1]);
};
var TEMP_BUNDLE = [];
currentExtensions[98] = (data) => {
	let dataSize = (data[0] << 24) + (data[1] << 16) + (data[2] << 8) + data[3];
	let dataPosition = position$1;
	position$1 += dataSize - data.length;
	bundledStrings$1 = TEMP_BUNDLE;
	bundledStrings$1 = [readOnlyJSString(), readOnlyJSString()];
	bundledStrings$1.position0 = 0;
	bundledStrings$1.position1 = 0;
	bundledStrings$1.postBundlePosition = position$1;
	position$1 = dataPosition;
	return read();
};
currentExtensions[255] = (data) => {
	if (data.length == 4) return /* @__PURE__ */ new Date((data[0] * 16777216 + (data[1] << 16) + (data[2] << 8) + data[3]) * 1e3);
	else if (data.length == 8) return /* @__PURE__ */ new Date(((data[0] << 22) + (data[1] << 14) + (data[2] << 6) + (data[3] >> 2)) / 1e6 + ((data[3] & 3) * 4294967296 + data[4] * 16777216 + (data[5] << 16) + (data[6] << 8) + data[7]) * 1e3);
	else if (data.length == 12) return /* @__PURE__ */ new Date(((data[0] << 24) + (data[1] << 16) + (data[2] << 8) + data[3]) / 1e6 + ((data[4] & 128 ? -281474976710656 : 0) + data[6] * 1099511627776 + data[7] * 4294967296 + data[8] * 16777216 + (data[9] << 16) + (data[10] << 8) + data[11]) * 1e3);
	else return /* @__PURE__ */ new Date("invalid");
};
function saveState$1(callback) {
	if (onSaveState) onSaveState();
	let savedSrcEnd = srcEnd;
	let savedPosition = position$1;
	let savedStringPosition = stringPosition;
	let savedSrcStringStart = srcStringStart;
	let savedSrcStringEnd = srcStringEnd;
	let savedSrcString = srcString;
	let savedStrings = strings;
	let savedReferenceMap = referenceMap;
	let savedBundledStrings = bundledStrings$1;
	let savedSrc = new Uint8Array(src.slice(0, srcEnd));
	let savedStructures = currentStructures;
	let savedStructuresContents = currentStructures.slice(0, currentStructures.length);
	let savedPackr = currentUnpackr;
	let savedSequentialMode = sequentialMode;
	let value = callback();
	srcEnd = savedSrcEnd;
	position$1 = savedPosition;
	stringPosition = savedStringPosition;
	srcStringStart = savedSrcStringStart;
	srcStringEnd = savedSrcStringEnd;
	srcString = savedSrcString;
	strings = savedStrings;
	referenceMap = savedReferenceMap;
	bundledStrings$1 = savedBundledStrings;
	src = savedSrc;
	sequentialMode = savedSequentialMode;
	currentStructures = savedStructures;
	currentStructures.splice(0, currentStructures.length, ...savedStructuresContents);
	currentUnpackr = savedPackr;
	dataView = new DataView(src.buffer, src.byteOffset, src.byteLength);
	return value;
}
function clearSource() {
	src = null;
	referenceMap = null;
	currentStructures = null;
}
var mult10 = new Array(147);
for (let i = 0; i < 256; i++) mult10[i] = +("1e" + Math.floor(45.15 - i * .30103));
var defaultUnpackr = new Unpackr({ useRecords: false });
var unpack = defaultUnpackr.unpack;
defaultUnpackr.unpackMultiple;
defaultUnpackr.unpack;
var FLOAT32_OPTIONS = {
	NEVER: 0,
	ALWAYS: 1,
	DECIMAL_ROUND: 3,
	DECIMAL_FIT: 4
};
new Uint8Array((/* @__PURE__ */ new Float32Array(1)).buffer, 0, 4);
function setReadStruct(updatedReadStruct, loadedStructs, saveState) {
	readStruct$1 = updatedReadStruct;
	onLoadedStructures$1 = loadedStructs;
	onSaveState = saveState;
}
//#endregion
//#region node_modules/@colyseus/msgpackr/pack.js
var textEncoder$1;
try {
	textEncoder$1 = new TextEncoder();
} catch (error) {}
var extensions;
var extensionClasses;
var hasNodeBuffer$1 = typeof Buffer !== "undefined";
var ByteArrayAllocate = hasNodeBuffer$1 ? function(length) {
	return Buffer.allocUnsafeSlow(length);
} : Uint8Array;
var ByteArray = hasNodeBuffer$1 ? Buffer : Uint8Array;
var MAX_BUFFER_SIZE = hasNodeBuffer$1 ? 4294967296 : 2144337920;
var target;
var keysTarget;
var targetView;
var position = 0;
var safeEnd;
var bundledStrings = null;
var writeStructSlots;
var MAX_BUNDLE_SIZE = 21760;
var hasNonLatin = /[\u0080-\uFFFF]/;
var RECORD_SYMBOL = Symbol("record-id");
var Packr = class extends Unpackr {
	constructor(options) {
		super(options);
		this.offset = 0;
		let start;
		let hasSharedUpdate;
		let structures;
		let referenceMap;
		let encodeUtf8 = ByteArray.prototype.utf8Write ? function(string, position) {
			return target.utf8Write(string, position, target.byteLength - position);
		} : textEncoder$1 && textEncoder$1.encodeInto ? function(string, position) {
			return textEncoder$1.encodeInto(string, target.subarray(position)).written;
		} : false;
		let packr = this;
		if (!options) options = {};
		let isSequential = options && options.sequential;
		let hasSharedStructures = options.structures || options.saveStructures;
		let maxSharedStructures = options.maxSharedStructures;
		if (maxSharedStructures == null) maxSharedStructures = hasSharedStructures ? 32 : 0;
		if (maxSharedStructures > 8160) throw new Error("Maximum maxSharedStructure is 8160");
		if (options.structuredClone && options.moreTypes == void 0) this.moreTypes = true;
		let maxOwnStructures = options.maxOwnStructures;
		if (maxOwnStructures == null) maxOwnStructures = hasSharedStructures ? 32 : 64;
		if (!this.structures && options.useRecords != false) this.structures = [];
		let useTwoByteRecords = maxSharedStructures > 32 || maxOwnStructures + maxSharedStructures > 64;
		let sharedLimitId = maxSharedStructures + 64;
		let maxStructureId = maxSharedStructures + maxOwnStructures + 64;
		if (maxStructureId > 8256) throw new Error("Maximum maxSharedStructure + maxOwnStructure is 8192");
		let recordIdsToRemove = [];
		let transitionsCount = 0;
		let serializationsSinceTransitionRebuild = 0;
		this.pack = this.encode = function(value, encodeOptions) {
			if (!target) {
				target = new ByteArrayAllocate(8192);
				targetView = target.dataView || (target.dataView = new DataView(target.buffer, 0, 8192));
				position = 0;
			}
			safeEnd = target.length - 10;
			if (safeEnd - position < 2048) {
				target = new ByteArrayAllocate(target.length);
				targetView = target.dataView || (target.dataView = new DataView(target.buffer, 0, target.length));
				safeEnd = target.length - 10;
				position = 0;
			} else position = position + 7 & 2147483640;
			start = position;
			if (encodeOptions & 2048) position += encodeOptions & 255;
			referenceMap = packr.structuredClone ? /* @__PURE__ */ new Map() : null;
			if (packr.bundleStrings && typeof value !== "string") {
				bundledStrings = [];
				bundledStrings.size = Infinity;
			} else bundledStrings = null;
			structures = packr.structures;
			if (structures) {
				if (structures.uninitialized) structures = packr._mergeStructures(packr.getStructures());
				let sharedLength = structures.sharedLength || 0;
				if (sharedLength > maxSharedStructures) throw new Error("Shared structures is larger than maximum shared structures, try increasing maxSharedStructures to " + structures.sharedLength);
				if (!structures.transitions) {
					structures.transitions = Object.create(null);
					for (let i = 0; i < sharedLength; i++) {
						let keys = structures[i];
						if (!keys) continue;
						let nextTransition, transition = structures.transitions;
						for (let j = 0, l = keys.length; j < l; j++) {
							let key = keys[j];
							nextTransition = transition[key];
							if (!nextTransition) nextTransition = transition[key] = Object.create(null);
							transition = nextTransition;
						}
						transition[RECORD_SYMBOL] = i + 64;
					}
					this.lastNamedStructuresLength = sharedLength;
				}
				if (!isSequential) structures.nextId = sharedLength + 64;
			}
			if (hasSharedUpdate) hasSharedUpdate = false;
			let encodingError;
			try {
				if (packr.randomAccessStructure && value && value.constructor && value.constructor === Object) writeStruct(value);
				else pack(value);
				let lastBundle = bundledStrings;
				if (bundledStrings) writeBundles(start, pack, 0);
				if (referenceMap && referenceMap.idsToInsert) {
					let idsToInsert = referenceMap.idsToInsert.sort((a, b) => a.offset > b.offset ? 1 : -1);
					let i = idsToInsert.length;
					let incrementPosition = -1;
					while (lastBundle && i > 0) {
						let insertionPoint = idsToInsert[--i].offset + start;
						if (insertionPoint < lastBundle.stringsPosition + start && incrementPosition === -1) incrementPosition = 0;
						if (insertionPoint > lastBundle.position + start) {
							if (incrementPosition >= 0) incrementPosition += 6;
						} else {
							if (incrementPosition >= 0) {
								targetView.setUint32(lastBundle.position + start, targetView.getUint32(lastBundle.position + start) + incrementPosition);
								incrementPosition = -1;
							}
							lastBundle = lastBundle.previous;
							i++;
						}
					}
					if (incrementPosition >= 0 && lastBundle) targetView.setUint32(lastBundle.position + start, targetView.getUint32(lastBundle.position + start) + incrementPosition);
					position += idsToInsert.length * 6;
					if (position > safeEnd) makeRoom(position);
					packr.offset = position;
					let serialized = insertIds(target.subarray(start, position), idsToInsert);
					referenceMap = null;
					return serialized;
				}
				packr.offset = position;
				if (encodeOptions & 512) {
					target.start = start;
					target.end = position;
					return target;
				}
				return target.subarray(start, position);
			} catch (error) {
				encodingError = error;
				throw error;
			} finally {
				if (structures) {
					resetStructures();
					if (hasSharedUpdate && packr.saveStructures) {
						let sharedLength = structures.sharedLength || 0;
						let returnBuffer = target.subarray(start, position);
						let newSharedData = prepareStructures$1(structures, packr);
						if (!encodingError) {
							if (packr.saveStructures(newSharedData, newSharedData.isCompatible) === false) return packr.pack(value, encodeOptions);
							packr.lastNamedStructuresLength = sharedLength;
							if (target.length > 1073741824) target = null;
							return returnBuffer;
						}
					}
				}
				if (target.length > 1073741824) target = null;
				if (encodeOptions & 1024) position = start;
			}
		};
		const resetStructures = () => {
			if (serializationsSinceTransitionRebuild < 10) serializationsSinceTransitionRebuild++;
			let sharedLength = structures.sharedLength || 0;
			if (structures.length > sharedLength && !isSequential) structures.length = sharedLength;
			if (transitionsCount > 1e4) {
				structures.transitions = null;
				serializationsSinceTransitionRebuild = 0;
				transitionsCount = 0;
				if (recordIdsToRemove.length > 0) recordIdsToRemove = [];
			} else if (recordIdsToRemove.length > 0 && !isSequential) {
				for (let i = 0, l = recordIdsToRemove.length; i < l; i++) recordIdsToRemove[i][RECORD_SYMBOL] = 0;
				recordIdsToRemove = [];
			}
		};
		const packArray = (value) => {
			var length = value.length;
			if (length < 16) target[position++] = 144 | length;
			else if (length < 65536) {
				target[position++] = 220;
				target[position++] = length >> 8;
				target[position++] = length & 255;
			} else {
				target[position++] = 221;
				targetView.setUint32(position, length);
				position += 4;
			}
			for (let i = 0; i < length; i++) pack(value[i]);
		};
		const pack = (value) => {
			if (position > safeEnd) target = makeRoom(position);
			var type = typeof value;
			var length;
			if (type === "string") {
				let strLength = value.length;
				if (bundledStrings && strLength >= 4 && strLength < 4096) {
					if ((bundledStrings.size += strLength) > MAX_BUNDLE_SIZE) {
						let extStart;
						let maxBytes = (bundledStrings[0] ? bundledStrings[0].length * 3 + bundledStrings[1].length : 0) + 10;
						if (position + maxBytes > safeEnd) target = makeRoom(position + maxBytes);
						let lastBundle;
						if (bundledStrings.position) {
							lastBundle = bundledStrings;
							target[position] = 200;
							position += 3;
							target[position++] = 98;
							extStart = position - start;
							position += 4;
							writeBundles(start, pack, 0);
							targetView.setUint16(extStart + start - 3, position - start - extStart);
						} else {
							target[position++] = 214;
							target[position++] = 98;
							extStart = position - start;
							position += 4;
						}
						bundledStrings = ["", ""];
						bundledStrings.previous = lastBundle;
						bundledStrings.size = 0;
						bundledStrings.position = extStart;
					}
					let twoByte = hasNonLatin.test(value);
					bundledStrings[twoByte ? 0 : 1] += value;
					target[position++] = 193;
					pack(twoByte ? -strLength : strLength);
					return;
				}
				let headerSize;
				if (strLength < 32) headerSize = 1;
				else if (strLength < 256) headerSize = 2;
				else if (strLength < 65536) headerSize = 3;
				else headerSize = 5;
				let maxBytes = strLength * 3;
				if (position + maxBytes > safeEnd) target = makeRoom(position + maxBytes);
				if (strLength < 64 || !encodeUtf8) {
					let i, c1, c2, strPosition = position + headerSize;
					for (i = 0; i < strLength; i++) {
						c1 = value.charCodeAt(i);
						if (c1 < 128) target[strPosition++] = c1;
						else if (c1 < 2048) {
							target[strPosition++] = c1 >> 6 | 192;
							target[strPosition++] = c1 & 63 | 128;
						} else if ((c1 & 64512) === 55296 && ((c2 = value.charCodeAt(i + 1)) & 64512) === 56320) {
							c1 = 65536 + ((c1 & 1023) << 10) + (c2 & 1023);
							i++;
							target[strPosition++] = c1 >> 18 | 240;
							target[strPosition++] = c1 >> 12 & 63 | 128;
							target[strPosition++] = c1 >> 6 & 63 | 128;
							target[strPosition++] = c1 & 63 | 128;
						} else {
							target[strPosition++] = c1 >> 12 | 224;
							target[strPosition++] = c1 >> 6 & 63 | 128;
							target[strPosition++] = c1 & 63 | 128;
						}
					}
					length = strPosition - position - headerSize;
				} else length = encodeUtf8(value, position + headerSize);
				if (length < 32) target[position++] = 160 | length;
				else if (length < 256) {
					if (headerSize < 2) target.copyWithin(position + 2, position + 1, position + 1 + length);
					target[position++] = 217;
					target[position++] = length;
				} else if (length < 65536) {
					if (headerSize < 3) target.copyWithin(position + 3, position + 2, position + 2 + length);
					target[position++] = 218;
					target[position++] = length >> 8;
					target[position++] = length & 255;
				} else {
					if (headerSize < 5) target.copyWithin(position + 5, position + 3, position + 3 + length);
					target[position++] = 219;
					targetView.setUint32(position, length);
					position += 4;
				}
				position += length;
			} else if (type === "number") {
				if (value >>> 0 === value) {
					if (value < 32 || value < 128 && this.useRecords === false || value < 64 && !this.randomAccessStructure) target[position++] = value;
					else if (value < 256) {
						target[position++] = 204;
						target[position++] = value;
					} else if (value < 65536) {
						target[position++] = 205;
						target[position++] = value >> 8;
						target[position++] = value & 255;
					} else {
						target[position++] = 206;
						targetView.setUint32(position, value);
						position += 4;
					}
				} else if (value >> 0 === value) {
					if (value >= -32) target[position++] = 256 + value;
					else if (value >= -128) {
						target[position++] = 208;
						target[position++] = value + 256;
					} else if (value >= -32768) {
						target[position++] = 209;
						targetView.setInt16(position, value);
						position += 2;
					} else {
						target[position++] = 210;
						targetView.setInt32(position, value);
						position += 4;
					}
				} else {
					let useFloat32;
					if ((useFloat32 = this.useFloat32) > 0 && value < 4294967296 && value >= -2147483648) {
						target[position++] = 202;
						targetView.setFloat32(position, value);
						let xShifted;
						if (useFloat32 < 4 || (xShifted = value * mult10[(target[position] & 127) << 1 | target[position + 1] >> 7]) >> 0 === xShifted) {
							position += 4;
							return;
						} else position--;
					}
					target[position++] = 203;
					targetView.setFloat64(position, value);
					position += 8;
				}
			} else if (type === "object" || type === "function") {
				if (!value) target[position++] = 192;
				else {
					if (referenceMap) {
						let referee = referenceMap.get(value);
						if (referee) {
							if (!referee.id) referee.id = (referenceMap.idsToInsert || (referenceMap.idsToInsert = [])).push(referee);
							target[position++] = 214;
							target[position++] = 112;
							targetView.setUint32(position, referee.id);
							position += 4;
							return;
						} else referenceMap.set(value, { offset: position - start });
					}
					let constructor = value.constructor;
					if (constructor === Object) writeObject(value);
					else if (constructor === Array) packArray(value);
					else if (constructor === Map) {
						if (this.mapAsEmptyObject) target[position++] = 128;
						else {
							length = value.size;
							if (length < 16) target[position++] = 128 | length;
							else if (length < 65536) {
								target[position++] = 222;
								target[position++] = length >> 8;
								target[position++] = length & 255;
							} else {
								target[position++] = 223;
								targetView.setUint32(position, length);
								position += 4;
							}
							for (let [key, entryValue] of value) {
								pack(key);
								pack(entryValue);
							}
						}
					} else {
						for (let i = 0, l = extensions.length; i < l; i++) {
							let extensionClass = extensionClasses[i];
							if (value instanceof extensionClass) {
								let extension = extensions[i];
								if (extension.write) {
									if (extension.type) {
										target[position++] = 212;
										target[position++] = extension.type;
										target[position++] = 0;
									}
									let writeResult = extension.write.call(this, value);
									if (writeResult === value) {
										if (Array.isArray(value)) packArray(value);
										else writeObject(value);
									} else pack(writeResult);
									return;
								}
								let currentTarget = target;
								let currentTargetView = targetView;
								let currentPosition = position;
								target = null;
								let result;
								try {
									result = extension.pack.call(this, value, (size) => {
										target = currentTarget;
										currentTarget = null;
										position += size;
										if (position > safeEnd) makeRoom(position);
										return {
											target,
											targetView,
											position: position - size
										};
									}, pack);
								} finally {
									if (currentTarget) {
										target = currentTarget;
										targetView = currentTargetView;
										position = currentPosition;
										safeEnd = target.length - 10;
									}
								}
								if (result) {
									if (result.length + position > safeEnd) makeRoom(result.length + position);
									position = writeExtensionData(result, target, position, extension.type);
								}
								return;
							}
						}
						if (Array.isArray(value)) packArray(value);
						else {
							if (value.toJSON) {
								const json = value.toJSON();
								if (json !== value) return pack(json);
							}
							if (type === "function") return pack(this.writeFunction && this.writeFunction(value));
							writeObject(value);
						}
					}
				}
			} else if (type === "boolean") target[position++] = value ? 195 : 194;
			else if (type === "bigint") {
				if (value < BigInt(1) << BigInt(63) && value >= -(BigInt(1) << BigInt(63))) {
					target[position++] = 211;
					targetView.setBigInt64(position, value);
				} else if (value < BigInt(1) << BigInt(64) && value > 0) {
					target[position++] = 207;
					targetView.setBigUint64(position, value);
				} else if (this.largeBigIntToFloat) {
					target[position++] = 203;
					targetView.setFloat64(position, Number(value));
				} else if (this.largeBigIntToString) return pack(value.toString());
				else if (this.useBigIntExtension && value < BigInt(2) ** BigInt(1023) && value > -(BigInt(2) ** BigInt(1023))) {
					target[position++] = 199;
					position++;
					target[position++] = 66;
					let bytes = [];
					let alignedSign;
					do {
						let byte = value & BigInt(255);
						alignedSign = (byte & BigInt(128)) === (value < BigInt(0) ? BigInt(128) : BigInt(0));
						bytes.push(byte);
						value >>= BigInt(8);
					} while (!((value === BigInt(0) || value === BigInt(-1)) && alignedSign));
					target[position - 2] = bytes.length;
					for (let i = bytes.length; i > 0;) target[position++] = Number(bytes[--i]);
					return;
				} else throw new RangeError(value + " was too large to fit in MessagePack 64-bit integer format, use useBigIntExtension, or set largeBigIntToFloat to convert to float-64, or set largeBigIntToString to convert to string");
				position += 8;
			} else if (type === "undefined") {
				if (this.encodeUndefinedAsNil) target[position++] = 192;
				else {
					target[position++] = 212;
					target[position++] = 0;
					target[position++] = 0;
				}
			} else throw new Error("Unknown type: " + type);
		};
		const writePlainObject = this.variableMapSize || this.coercibleKeyAsNumber || this.skipValues ? (object) => {
			let keys;
			if (this.skipValues) {
				keys = [];
				for (let key in object) if ((typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) && !this.skipValues.includes(object[key])) keys.push(key);
			} else keys = Object.keys(object);
			let length = keys.length;
			if (length < 16) target[position++] = 128 | length;
			else if (length < 65536) {
				target[position++] = 222;
				target[position++] = length >> 8;
				target[position++] = length & 255;
			} else {
				target[position++] = 223;
				targetView.setUint32(position, length);
				position += 4;
			}
			let key;
			if (this.coercibleKeyAsNumber) for (let i = 0; i < length; i++) {
				key = keys[i];
				let num = Number(key);
				pack(isNaN(num) ? key : num);
				pack(object[key]);
			}
			else for (let i = 0; i < length; i++) {
				pack(key = keys[i]);
				pack(object[key]);
			}
		} : (object) => {
			target[position++] = 222;
			let objectOffset = position - start;
			position += 2;
			let size = 0;
			for (let key in object) if (typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) {
				pack(key);
				pack(object[key]);
				size++;
			}
			if (size > 65535) throw new Error("Object is too large to serialize with fast 16-bit map size, use the \"variableMapSize\" option to serialize this object");
			target[objectOffset++ + start] = size >> 8;
			target[objectOffset + start] = size & 255;
		};
		const writeRecord = this.useRecords === false ? writePlainObject : options.progressiveRecords && !useTwoByteRecords ? (object) => {
			let nextTransition, transition = structures.transitions || (structures.transitions = Object.create(null));
			let objectOffset = position++ - start;
			let wroteKeys;
			for (let key in object) if (typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) {
				nextTransition = transition[key];
				if (nextTransition) transition = nextTransition;
				else {
					let keys = Object.keys(object);
					let lastTransition = transition;
					transition = structures.transitions;
					let newTransitions = 0;
					for (let i = 0, l = keys.length; i < l; i++) {
						let key = keys[i];
						nextTransition = transition[key];
						if (!nextTransition) {
							nextTransition = transition[key] = Object.create(null);
							newTransitions++;
						}
						transition = nextTransition;
					}
					if (objectOffset + start + 1 == position) {
						position--;
						newRecord(transition, keys, newTransitions);
					} else insertNewRecord(transition, keys, objectOffset, newTransitions);
					wroteKeys = true;
					transition = lastTransition[key];
				}
				pack(object[key]);
			}
			if (!wroteKeys) {
				let recordId = transition[RECORD_SYMBOL];
				if (recordId) target[objectOffset + start] = recordId;
				else insertNewRecord(transition, Object.keys(object), objectOffset, 0);
			}
		} : (object) => {
			let nextTransition, transition = structures.transitions || (structures.transitions = Object.create(null));
			let newTransitions = 0;
			for (let key in object) if (typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) {
				nextTransition = transition[key];
				if (!nextTransition) {
					nextTransition = transition[key] = Object.create(null);
					newTransitions++;
				}
				transition = nextTransition;
			}
			let recordId = transition[RECORD_SYMBOL];
			if (recordId) {
				if (recordId >= 96 && useTwoByteRecords) {
					target[position++] = ((recordId -= 96) & 31) + 96;
					target[position++] = recordId >> 5;
				} else target[position++] = recordId;
			} else newRecord(transition, transition.__keys__ || Object.keys(object), newTransitions);
			for (let key in object) if (typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) pack(object[key]);
		};
		const checkUseRecords = typeof this.useRecords == "function" && this.useRecords;
		const writeObject = checkUseRecords ? (object) => {
			checkUseRecords(object) ? writeRecord(object) : writePlainObject(object);
		} : writeRecord;
		const makeRoom = (end) => {
			let newSize;
			if (end > 16777216) {
				if (end - start > MAX_BUFFER_SIZE) throw new Error("Packed buffer would be larger than maximum buffer size");
				newSize = Math.min(MAX_BUFFER_SIZE, Math.round(Math.max((end - start) * (end > 67108864 ? 1.25 : 2), 4194304) / 4096) * 4096);
			} else newSize = (Math.max(end - start << 2, target.length - 1) >> 12) + 1 << 12;
			let newBuffer = new ByteArrayAllocate(newSize);
			targetView = newBuffer.dataView || (newBuffer.dataView = new DataView(newBuffer.buffer, 0, newSize));
			end = Math.min(end, target.length);
			if (target.copy) target.copy(newBuffer, 0, start, end);
			else newBuffer.set(target.slice(start, end));
			position -= start;
			start = 0;
			safeEnd = newBuffer.length - 10;
			return target = newBuffer;
		};
		const newRecord = (transition, keys, newTransitions) => {
			let recordId = structures.nextId;
			if (!recordId) recordId = 64;
			if (recordId < sharedLimitId && this.shouldShareStructure && !this.shouldShareStructure(keys)) {
				recordId = structures.nextOwnId;
				if (!(recordId < maxStructureId)) recordId = sharedLimitId;
				structures.nextOwnId = recordId + 1;
			} else {
				if (recordId >= maxStructureId) recordId = sharedLimitId;
				structures.nextId = recordId + 1;
			}
			let highByte = keys.highByte = recordId >= 96 && useTwoByteRecords ? recordId - 96 >> 5 : -1;
			transition[RECORD_SYMBOL] = recordId;
			transition.__keys__ = keys;
			structures[recordId - 64] = keys;
			if (recordId < sharedLimitId) {
				keys.isShared = true;
				structures.sharedLength = recordId - 63;
				hasSharedUpdate = true;
				if (highByte >= 0) {
					target[position++] = (recordId & 31) + 96;
					target[position++] = highByte;
				} else target[position++] = recordId;
			} else {
				if (highByte >= 0) {
					target[position++] = 213;
					target[position++] = 114;
					target[position++] = (recordId & 31) + 96;
					target[position++] = highByte;
				} else {
					target[position++] = 212;
					target[position++] = 114;
					target[position++] = recordId;
				}
				if (newTransitions) transitionsCount += serializationsSinceTransitionRebuild * newTransitions;
				if (recordIdsToRemove.length >= maxOwnStructures) recordIdsToRemove.shift()[RECORD_SYMBOL] = 0;
				recordIdsToRemove.push(transition);
				pack(keys);
			}
		};
		const insertNewRecord = (transition, keys, insertionOffset, newTransitions) => {
			let mainTarget = target;
			let mainPosition = position;
			let mainSafeEnd = safeEnd;
			let mainStart = start;
			target = keysTarget;
			position = 0;
			start = 0;
			if (!target) keysTarget = target = new ByteArrayAllocate(8192);
			safeEnd = target.length - 10;
			newRecord(transition, keys, newTransitions);
			keysTarget = target;
			let keysPosition = position;
			target = mainTarget;
			position = mainPosition;
			safeEnd = mainSafeEnd;
			start = mainStart;
			if (keysPosition > 1) {
				let newEnd = position + keysPosition - 1;
				if (newEnd > safeEnd) makeRoom(newEnd);
				let insertionPosition = insertionOffset + start;
				target.copyWithin(insertionPosition + keysPosition, insertionPosition + 1, position);
				target.set(keysTarget.slice(0, keysPosition), insertionPosition);
				position = newEnd;
			} else target[insertionOffset + start] = keysTarget[0];
		};
		const writeStruct = (object) => {
			let newPosition = writeStructSlots(object, target, start, position, structures, makeRoom, (value, newPosition, notifySharedUpdate) => {
				if (notifySharedUpdate) return hasSharedUpdate = true;
				position = newPosition;
				let startTarget = target;
				pack(value);
				resetStructures();
				if (startTarget !== target) return {
					position,
					targetView,
					target
				};
				return position;
			}, this);
			if (newPosition === 0) return writeObject(object);
			position = newPosition;
		};
	}
	useBuffer(buffer) {
		target = buffer;
		target.dataView || (target.dataView = new DataView(target.buffer, target.byteOffset, target.byteLength));
		targetView = target.dataView;
		position = 0;
	}
	set position(value) {
		position = value;
	}
	get position() {
		return position;
	}
	set buffer(buffer) {
		target = buffer;
	}
	get buffer() {
		return target;
	}
	clearSharedData() {
		if (this.structures) this.structures = [];
		if (this.typedStructs) this.typedStructs = [];
	}
};
extensionClasses = [
	Date,
	Set,
	Error,
	RegExp,
	ArrayBuffer,
	Object.getPrototypeOf(Uint8Array.prototype).constructor,
	C1Type
];
extensions = [
	{ pack(date, allocateForWrite, pack) {
		let seconds = date.getTime() / 1e3;
		if ((this.useTimestamp32 || date.getMilliseconds() === 0) && seconds >= 0 && seconds < 4294967296) {
			let { target, targetView, position } = allocateForWrite(6);
			target[position++] = 214;
			target[position++] = 255;
			targetView.setUint32(position, seconds);
		} else if (seconds > 0 && seconds < 4294967296) {
			let { target, targetView, position } = allocateForWrite(10);
			target[position++] = 215;
			target[position++] = 255;
			targetView.setUint32(position, date.getMilliseconds() * 4e6 + (seconds / 1e3 / 4294967296 >> 0));
			targetView.setUint32(position + 4, seconds);
		} else if (isNaN(seconds)) {
			if (this.onInvalidDate) {
				allocateForWrite(0);
				return pack(this.onInvalidDate());
			}
			let { target, targetView, position } = allocateForWrite(3);
			target[position++] = 212;
			target[position++] = 255;
			target[position++] = 255;
		} else {
			let { target, targetView, position } = allocateForWrite(15);
			target[position++] = 199;
			target[position++] = 12;
			target[position++] = 255;
			targetView.setUint32(position, date.getMilliseconds() * 1e6);
			targetView.setBigInt64(position + 4, BigInt(Math.floor(seconds)));
		}
	} },
	{ pack(set, allocateForWrite, pack) {
		if (this.setAsEmptyObject) {
			allocateForWrite(0);
			return pack({});
		}
		let array = Array.from(set);
		let { target, position } = allocateForWrite(this.moreTypes ? 3 : 0);
		if (this.moreTypes) {
			target[position++] = 212;
			target[position++] = 115;
			target[position++] = 0;
		}
		pack(array);
	} },
	{ pack(error, allocateForWrite, pack) {
		let { target, position } = allocateForWrite(this.moreTypes ? 3 : 0);
		if (this.moreTypes) {
			target[position++] = 212;
			target[position++] = 101;
			target[position++] = 0;
		}
		pack([
			error.name,
			error.message,
			error.cause
		]);
	} },
	{ pack(regex, allocateForWrite, pack) {
		let { target, position } = allocateForWrite(this.moreTypes ? 3 : 0);
		if (this.moreTypes) {
			target[position++] = 212;
			target[position++] = 120;
			target[position++] = 0;
		}
		pack([regex.source, regex.flags]);
	} },
	{ pack(arrayBuffer, allocateForWrite) {
		if (this.moreTypes) writeExtBuffer(arrayBuffer, 16, allocateForWrite);
		else writeBuffer(hasNodeBuffer$1 ? Buffer.from(arrayBuffer) : new Uint8Array(arrayBuffer), allocateForWrite);
	} },
	{ pack(typedArray, allocateForWrite) {
		let constructor = typedArray.constructor;
		if (constructor !== ByteArray && this.moreTypes) writeExtBuffer(typedArray, typedArrays.indexOf(constructor.name), allocateForWrite);
		else writeBuffer(typedArray, allocateForWrite);
	} },
	{ pack(c1, allocateForWrite) {
		let { target, position } = allocateForWrite(1);
		target[position] = 193;
	} }
];
function writeExtBuffer(typedArray, type, allocateForWrite, encode) {
	let length = typedArray.byteLength;
	if (length + 1 < 256) {
		var { target, position } = allocateForWrite(4 + length);
		target[position++] = 199;
		target[position++] = length + 1;
	} else if (length + 1 < 65536) {
		var { target, position } = allocateForWrite(5 + length);
		target[position++] = 200;
		target[position++] = length + 1 >> 8;
		target[position++] = length + 1 & 255;
	} else {
		var { target, position, targetView } = allocateForWrite(7 + length);
		target[position++] = 201;
		targetView.setUint32(position, length + 1);
		position += 4;
	}
	target[position++] = 116;
	target[position++] = type;
	if (!typedArray.buffer) typedArray = new Uint8Array(typedArray);
	target.set(new Uint8Array(typedArray.buffer, typedArray.byteOffset, typedArray.byteLength), position);
}
function writeBuffer(buffer, allocateForWrite) {
	let length = buffer.byteLength;
	var target, position;
	if (length < 256) {
		var { target, position } = allocateForWrite(length + 2);
		target[position++] = 196;
		target[position++] = length;
	} else if (length < 65536) {
		var { target, position } = allocateForWrite(length + 3);
		target[position++] = 197;
		target[position++] = length >> 8;
		target[position++] = length & 255;
	} else {
		var { target, position, targetView } = allocateForWrite(length + 5);
		target[position++] = 198;
		targetView.setUint32(position, length);
		position += 4;
	}
	target.set(buffer, position);
}
function writeExtensionData(result, target, position, type) {
	let length = result.length;
	switch (length) {
		case 1:
			target[position++] = 212;
			break;
		case 2:
			target[position++] = 213;
			break;
		case 4:
			target[position++] = 214;
			break;
		case 8:
			target[position++] = 215;
			break;
		case 16:
			target[position++] = 216;
			break;
		default: if (length < 256) {
			target[position++] = 199;
			target[position++] = length;
		} else if (length < 65536) {
			target[position++] = 200;
			target[position++] = length >> 8;
			target[position++] = length & 255;
		} else {
			target[position++] = 201;
			target[position++] = length >> 24;
			target[position++] = length >> 16 & 255;
			target[position++] = length >> 8 & 255;
			target[position++] = length & 255;
		}
	}
	target[position++] = type;
	target.set(result, position);
	position += length;
	return position;
}
function insertIds(serialized, idsToInsert) {
	let nextId;
	let distanceToMove = idsToInsert.length * 6;
	let lastEnd = serialized.length - distanceToMove;
	while (nextId = idsToInsert.pop()) {
		let offset = nextId.offset;
		let id = nextId.id;
		serialized.copyWithin(offset + distanceToMove, offset, lastEnd);
		distanceToMove -= 6;
		let position = offset + distanceToMove;
		serialized[position++] = 214;
		serialized[position++] = 105;
		serialized[position++] = id >> 24;
		serialized[position++] = id >> 16 & 255;
		serialized[position++] = id >> 8 & 255;
		serialized[position++] = id & 255;
		lastEnd = offset;
	}
	return serialized;
}
function writeBundles(start, pack, incrementPosition) {
	if (bundledStrings.length > 0) {
		targetView.setUint32(bundledStrings.position + start, position + incrementPosition - bundledStrings.position - start);
		bundledStrings.stringsPosition = position - start;
		let writeStrings = bundledStrings;
		bundledStrings = null;
		pack(writeStrings[0]);
		pack(writeStrings[1]);
	}
}
function prepareStructures$1(structures, packr) {
	structures.isCompatible = (existingStructures) => {
		let compatible = !existingStructures || (packr.lastNamedStructuresLength || 0) === existingStructures.length;
		if (!compatible) packr._mergeStructures(existingStructures);
		return compatible;
	};
	return structures;
}
function setWriteStructSlots(writeSlots, makeStructures) {
	writeStructSlots = writeSlots;
	prepareStructures$1 = makeStructures;
}
var defaultPackr = new Packr({ useRecords: false });
defaultPackr.pack;
defaultPackr.pack;
var { NEVER, ALWAYS, DECIMAL_ROUND, DECIMAL_FIT } = FLOAT32_OPTIONS;
//#endregion
//#region node_modules/@colyseus/msgpackr/struct.js
var ASCII = 3;
var NUMBER = 0;
var UTF8 = 2;
var OBJECT_DATA = 1;
var DATE = 16;
var TYPE_NAMES = [
	"num",
	"object",
	"string",
	"ascii"
];
TYPE_NAMES[DATE] = "date";
var float32Headers = [
	false,
	true,
	true,
	false,
	false,
	true,
	true,
	false
];
var evalSupported;
try {
	new Function("");
	evalSupported = true;
} catch (error) {}
var updatedPosition;
var hasNodeBuffer = typeof Buffer !== "undefined";
var textEncoder;
var currentSource;
try {
	textEncoder = new TextEncoder();
} catch (error) {}
var encodeUtf8 = hasNodeBuffer ? function(target, string, position) {
	return target.utf8Write(string, position, target.byteLength - position);
} : textEncoder && textEncoder.encodeInto ? function(target, string, position) {
	return textEncoder.encodeInto(string, target.subarray(position)).written;
} : false;
setWriteStructSlots(writeStruct, prepareStructures);
function writeStruct(object, target, encodingStart, position, structures, makeRoom, pack, packr) {
	let typedStructs = packr.typedStructs || (packr.typedStructs = []);
	let targetView = target.dataView;
	let refsStartPosition = (typedStructs.lastStringStart || 100) + position;
	let safeEnd = target.length - 10;
	let start = position;
	if (position > safeEnd) {
		target = makeRoom(position);
		targetView = target.dataView;
		position -= encodingStart;
		start -= encodingStart;
		refsStartPosition -= encodingStart;
		encodingStart = 0;
		safeEnd = target.length - 10;
	}
	let refOffset, refPosition = refsStartPosition;
	let transition = typedStructs.transitions || (typedStructs.transitions = Object.create(null));
	let nextId = typedStructs.nextId || typedStructs.length;
	let headerSize = nextId < 15 ? 1 : nextId < 240 ? 2 : nextId < 61440 ? 3 : nextId < 15728640 ? 4 : 0;
	if (headerSize === 0) return 0;
	position += headerSize;
	let queuedReferences = [];
	let usedAscii0;
	let keyIndex = 0;
	for (let key in object) {
		let value = object[key];
		let nextTransition = transition[key];
		if (!nextTransition) transition[key] = nextTransition = {
			key,
			parent: transition,
			enumerationOffset: 0,
			ascii0: null,
			ascii8: null,
			num8: null,
			string16: null,
			object16: null,
			num32: null,
			float64: null,
			date64: null
		};
		if (position > safeEnd) {
			target = makeRoom(position);
			targetView = target.dataView;
			position -= encodingStart;
			start -= encodingStart;
			refsStartPosition -= encodingStart;
			refPosition -= encodingStart;
			encodingStart = 0;
			safeEnd = target.length - 10;
		}
		switch (typeof value) {
			case "number":
				let number = value;
				if (nextId < 200 || !nextTransition.num64) {
					if (number >> 0 === number && number < 536870912 && number > -520093696) {
						if (number < 246 && number >= 0 && (nextTransition.num8 && !(nextId > 200 && nextTransition.num32) || number < 32 && !nextTransition.num32)) {
							transition = nextTransition.num8 || createTypeTransition(nextTransition, NUMBER, 1);
							target[position++] = number;
						} else {
							transition = nextTransition.num32 || createTypeTransition(nextTransition, NUMBER, 4);
							targetView.setUint32(position, number, true);
							position += 4;
						}
						break;
					} else if (number < 4294967296 && number >= -2147483648) {
						targetView.setFloat32(position, number, true);
						if (float32Headers[target[position + 3] >>> 5]) {
							let xShifted;
							if ((xShifted = number * mult10[(target[position + 3] & 127) << 1 | target[position + 2] >> 7]) >> 0 === xShifted) {
								transition = nextTransition.num32 || createTypeTransition(nextTransition, NUMBER, 4);
								position += 4;
								break;
							}
						}
					}
				}
				transition = nextTransition.num64 || createTypeTransition(nextTransition, NUMBER, 8);
				targetView.setFloat64(position, number, true);
				position += 8;
				break;
			case "string":
				let strLength = value.length;
				refOffset = refPosition - refsStartPosition;
				if ((strLength << 2) + refPosition > safeEnd) {
					target = makeRoom((strLength << 2) + refPosition);
					targetView = target.dataView;
					position -= encodingStart;
					start -= encodingStart;
					refsStartPosition -= encodingStart;
					refPosition -= encodingStart;
					encodingStart = 0;
					safeEnd = target.length - 10;
				}
				if (strLength > 65280 + refOffset >> 2) {
					queuedReferences.push(key, value, position - start);
					break;
				}
				let isNotAscii;
				let strStart = refPosition;
				if (strLength < 64) {
					let i, c1, c2;
					for (i = 0; i < strLength; i++) {
						c1 = value.charCodeAt(i);
						if (c1 < 128) target[refPosition++] = c1;
						else if (c1 < 2048) {
							isNotAscii = true;
							target[refPosition++] = c1 >> 6 | 192;
							target[refPosition++] = c1 & 63 | 128;
						} else if ((c1 & 64512) === 55296 && ((c2 = value.charCodeAt(i + 1)) & 64512) === 56320) {
							isNotAscii = true;
							c1 = 65536 + ((c1 & 1023) << 10) + (c2 & 1023);
							i++;
							target[refPosition++] = c1 >> 18 | 240;
							target[refPosition++] = c1 >> 12 & 63 | 128;
							target[refPosition++] = c1 >> 6 & 63 | 128;
							target[refPosition++] = c1 & 63 | 128;
						} else {
							isNotAscii = true;
							target[refPosition++] = c1 >> 12 | 224;
							target[refPosition++] = c1 >> 6 & 63 | 128;
							target[refPosition++] = c1 & 63 | 128;
						}
					}
				} else {
					refPosition += encodeUtf8(target, value, refPosition);
					isNotAscii = refPosition - strStart > strLength;
				}
				if (refOffset < 160 || refOffset < 246 && (nextTransition.ascii8 || nextTransition.string8)) {
					if (isNotAscii) {
						if (!(transition = nextTransition.string8)) {
							if (typedStructs.length > 10 && (transition = nextTransition.ascii8)) {
								transition.__type = UTF8;
								nextTransition.ascii8 = null;
								nextTransition.string8 = transition;
								pack(null, 0, true);
							} else transition = createTypeTransition(nextTransition, UTF8, 1);
						}
					} else if (refOffset === 0 && !usedAscii0) {
						usedAscii0 = true;
						transition = nextTransition.ascii0 || createTypeTransition(nextTransition, ASCII, 0);
						break;
					} else if (!(transition = nextTransition.ascii8) && !(typedStructs.length > 10 && (transition = nextTransition.string8))) transition = createTypeTransition(nextTransition, ASCII, 1);
					target[position++] = refOffset;
				} else {
					transition = nextTransition.string16 || createTypeTransition(nextTransition, UTF8, 2);
					targetView.setUint16(position, refOffset, true);
					position += 2;
				}
				break;
			case "object":
				if (value) {
					if (value.constructor === Date) {
						transition = nextTransition.date64 || createTypeTransition(nextTransition, DATE, 8);
						targetView.setFloat64(position, value.getTime(), true);
						position += 8;
					} else queuedReferences.push(key, value, keyIndex);
					break;
				} else {
					nextTransition = anyType(nextTransition, position, targetView, -10);
					if (nextTransition) {
						transition = nextTransition;
						position = updatedPosition;
					} else queuedReferences.push(key, value, keyIndex);
				}
				break;
			case "boolean":
				transition = nextTransition.num8 || nextTransition.ascii8 || createTypeTransition(nextTransition, NUMBER, 1);
				target[position++] = value ? 249 : 248;
				break;
			case "undefined":
				nextTransition = anyType(nextTransition, position, targetView, -9);
				if (nextTransition) {
					transition = nextTransition;
					position = updatedPosition;
				} else queuedReferences.push(key, value, keyIndex);
				break;
			default: queuedReferences.push(key, value, keyIndex);
		}
		keyIndex++;
	}
	for (let i = 0, l = queuedReferences.length; i < l;) {
		let key = queuedReferences[i++];
		let value = queuedReferences[i++];
		let propertyIndex = queuedReferences[i++];
		let nextTransition = transition[key];
		if (!nextTransition) transition[key] = nextTransition = {
			key,
			parent: transition,
			enumerationOffset: propertyIndex - keyIndex,
			ascii0: null,
			ascii8: null,
			num8: null,
			string16: null,
			object16: null,
			num32: null,
			float64: null
		};
		let newPosition;
		if (value) {
			let size;
			refOffset = refPosition - refsStartPosition;
			if (refOffset < 65280) {
				transition = nextTransition.object16;
				if (transition) size = 2;
				else if (transition = nextTransition.object32) size = 4;
				else {
					transition = createTypeTransition(nextTransition, OBJECT_DATA, 2);
					size = 2;
				}
			} else {
				transition = nextTransition.object32 || createTypeTransition(nextTransition, OBJECT_DATA, 4);
				size = 4;
			}
			newPosition = pack(value, refPosition);
			if (typeof newPosition === "object") {
				refPosition = newPosition.position;
				targetView = newPosition.targetView;
				target = newPosition.target;
				refsStartPosition -= encodingStart;
				position -= encodingStart;
				start -= encodingStart;
				encodingStart = 0;
			} else refPosition = newPosition;
			if (size === 2) {
				targetView.setUint16(position, refOffset, true);
				position += 2;
			} else {
				targetView.setUint32(position, refOffset, true);
				position += 4;
			}
		} else {
			transition = nextTransition.object16 || createTypeTransition(nextTransition, OBJECT_DATA, 2);
			targetView.setInt16(position, value === null ? -10 : -9, true);
			position += 2;
		}
		keyIndex++;
	}
	let recordId = transition[RECORD_SYMBOL];
	if (recordId == null) {
		recordId = packr.typedStructs.length;
		let structure = [];
		let nextTransition = transition;
		let key, type;
		while ((type = nextTransition.__type) !== void 0) {
			let size = nextTransition.__size;
			nextTransition = nextTransition.__parent;
			key = nextTransition.key;
			let property = [
				type,
				size,
				key
			];
			if (nextTransition.enumerationOffset) property.push(nextTransition.enumerationOffset);
			structure.push(property);
			nextTransition = nextTransition.parent;
		}
		structure.reverse();
		transition[RECORD_SYMBOL] = recordId;
		packr.typedStructs[recordId] = structure;
		pack(null, 0, true);
	}
	switch (headerSize) {
		case 1:
			if (recordId >= 16) return 0;
			target[start] = recordId + 32;
			break;
		case 2:
			if (recordId >= 256) return 0;
			target[start] = 56;
			target[start + 1] = recordId;
			break;
		case 3:
			if (recordId >= 65536) return 0;
			target[start] = 57;
			targetView.setUint16(start + 1, recordId, true);
			break;
		case 4:
			if (recordId >= 16777216) return 0;
			targetView.setUint32(start, (recordId << 8) + 58, true);
	}
	if (position < refsStartPosition) {
		if (refsStartPosition === refPosition) return position;
		target.copyWithin(position, refsStartPosition, refPosition);
		refPosition += position - refsStartPosition;
		typedStructs.lastStringStart = position - start;
	} else if (position > refsStartPosition) {
		if (refsStartPosition === refPosition) return position;
		typedStructs.lastStringStart = position - start;
		return writeStruct(object, target, encodingStart, start, structures, makeRoom, pack, packr);
	}
	return refPosition;
}
function anyType(transition, position, targetView, value) {
	let nextTransition;
	if (nextTransition = transition.ascii8 || transition.num8) {
		targetView.setInt8(position, value, true);
		updatedPosition = position + 1;
		return nextTransition;
	}
	if (nextTransition = transition.string16 || transition.object16) {
		targetView.setInt16(position, value, true);
		updatedPosition = position + 2;
		return nextTransition;
	}
	if (nextTransition = transition.num32) {
		targetView.setUint32(position, 3758096640 + value, true);
		updatedPosition = position + 4;
		return nextTransition;
	}
	if (nextTransition = transition.num64) {
		targetView.setFloat64(position, NaN, true);
		targetView.setInt8(position, value);
		updatedPosition = position + 8;
		return nextTransition;
	}
	updatedPosition = position;
}
function createTypeTransition(transition, type, size) {
	let typeName = TYPE_NAMES[type] + (size << 3);
	let newTransition = transition[typeName] || (transition[typeName] = Object.create(null));
	newTransition.__type = type;
	newTransition.__size = size;
	newTransition.__parent = transition;
	return newTransition;
}
function onLoadedStructures(sharedData) {
	if (!(sharedData instanceof Map)) return sharedData;
	let typed = sharedData.get("typed") || [];
	if (Object.isFrozen(typed)) typed = typed.map((structure) => structure.slice(0));
	let named = sharedData.get("named");
	let transitions = Object.create(null);
	for (let i = 0, l = typed.length; i < l; i++) {
		let structure = typed[i];
		let transition = transitions;
		for (let [type, size, key] of structure) {
			let nextTransition = transition[key];
			if (!nextTransition) transition[key] = nextTransition = {
				key,
				parent: transition,
				enumerationOffset: 0,
				ascii0: null,
				ascii8: null,
				num8: null,
				string16: null,
				object16: null,
				num32: null,
				float64: null,
				date64: null
			};
			transition = createTypeTransition(nextTransition, type, size);
		}
		transition[RECORD_SYMBOL] = i;
	}
	typed.transitions = transitions;
	this.typedStructs = typed;
	this.lastTypedStructuresLength = typed.length;
	return named;
}
var sourceSymbol = Symbol.for("source");
function readStruct(src, position, srcEnd, unpackr) {
	let recordId = src[position++] - 32;
	if (recordId >= 24) switch (recordId) {
		case 24:
			recordId = src[position++];
			break;
		case 25:
			recordId = src[position++] + (src[position++] << 8);
			break;
		case 26:
			recordId = src[position++] + (src[position++] << 8) + (src[position++] << 16);
			break;
		case 27: recordId = src[position++] + (src[position++] << 8) + (src[position++] << 16) + (src[position++] << 24);
	}
	let structure = unpackr.typedStructs && unpackr.typedStructs[recordId];
	if (!structure) {
		src = Uint8Array.prototype.slice.call(src, position, srcEnd);
		srcEnd -= position;
		position = 0;
		if (!unpackr.getStructures) throw new Error(`Reference to shared structure ${recordId} without getStructures method`);
		unpackr._mergeStructures(unpackr.getStructures());
		if (!unpackr.typedStructs) throw new Error("Could not find any shared typed structures");
		unpackr.lastTypedStructuresLength = unpackr.typedStructs.length;
		structure = unpackr.typedStructs[recordId];
		if (!structure) throw new Error("Could not find typed structure " + recordId);
	}
	var construct = structure.construct;
	if (!construct) {
		construct = structure.construct = function LazyObject() {};
		var prototype = construct.prototype;
		let properties = [];
		let currentOffset = 0;
		let lastRefProperty;
		for (let i = 0, l = structure.length; i < l; i++) {
			let [type, size, key, enumerationOffset] = structure[i];
			if (key === "__proto__") key = "__proto_";
			let property = {
				key,
				offset: currentOffset
			};
			if (enumerationOffset) properties.splice(i + enumerationOffset, 0, property);
			else properties.push(property);
			let getRef;
			switch (size) {
				case 0:
					getRef = () => 0;
					break;
				case 1:
					getRef = (source, position) => {
						let ref = source.bytes[position + property.offset];
						return ref >= 246 ? toConstant(ref) : ref;
					};
					break;
				case 2:
					getRef = (source, position) => {
						let src = source.bytes;
						let ref = (src.dataView || (src.dataView = new DataView(src.buffer, src.byteOffset, src.byteLength))).getUint16(position + property.offset, true);
						return ref >= 65280 ? toConstant(ref & 255) : ref;
					};
					break;
				case 4: getRef = (source, position) => {
					let src = source.bytes;
					let ref = (src.dataView || (src.dataView = new DataView(src.buffer, src.byteOffset, src.byteLength))).getUint32(position + property.offset, true);
					return ref >= 4294967040 ? toConstant(ref & 255) : ref;
				};
			}
			property.getRef = getRef;
			currentOffset += size;
			let get;
			switch (type) {
				case ASCII:
					if (lastRefProperty && !lastRefProperty.next) lastRefProperty.next = property;
					lastRefProperty = property;
					property.multiGetCount = 0;
					get = function(source) {
						let src = source.bytes;
						let position = source.position;
						let refStart = currentOffset + position;
						let ref = getRef(source, position);
						if (typeof ref !== "number") return ref;
						let end, next = property.next;
						while (next) {
							end = next.getRef(source, position);
							if (typeof end === "number") break;
							else end = null;
							next = next.next;
						}
						if (end == null) end = source.bytesEnd - refStart;
						if (source.srcString) return source.srcString.slice(ref, end);
						return readString(src, ref + refStart, end - ref);
					};
					break;
				case UTF8:
				case OBJECT_DATA:
					if (lastRefProperty && !lastRefProperty.next) lastRefProperty.next = property;
					lastRefProperty = property;
					get = function(source) {
						let position = source.position;
						let refStart = currentOffset + position;
						let ref = getRef(source, position);
						if (typeof ref !== "number") return ref;
						let src = source.bytes;
						let end, next = property.next;
						while (next) {
							end = next.getRef(source, position);
							if (typeof end === "number") break;
							else end = null;
							next = next.next;
						}
						if (end == null) end = source.bytesEnd - refStart;
						if (type === UTF8) return src.toString("utf8", ref + refStart, end + refStart);
						else {
							currentSource = source;
							try {
								return unpackr.unpack(src, {
									start: ref + refStart,
									end: end + refStart
								});
							} finally {
								currentSource = null;
							}
						}
					};
					break;
				case NUMBER:
					switch (size) {
						case 4:
							get = function(source) {
								let src = source.bytes;
								let dataView = src.dataView || (src.dataView = new DataView(src.buffer, src.byteOffset, src.byteLength));
								let position = source.position + property.offset;
								let value = dataView.getInt32(position, true);
								if (value < 536870912) {
									if (value > -520093696) return value;
									if (value > -536870912) return toConstant(value & 255);
								}
								let fValue = dataView.getFloat32(position, true);
								let multiplier = mult10[(src[position + 3] & 127) << 1 | src[position + 2] >> 7];
								return (multiplier * fValue + (fValue > 0 ? .5 : -.5) >> 0) / multiplier;
							};
							break;
						case 8:
							get = function(source) {
								let src = source.bytes;
								let value = (src.dataView || (src.dataView = new DataView(src.buffer, src.byteOffset, src.byteLength))).getFloat64(source.position + property.offset, true);
								if (isNaN(value)) {
									let byte = src[source.position + property.offset];
									if (byte >= 246) return toConstant(byte);
								}
								return value;
							};
							break;
						case 1: get = function(source) {
							let value = source.bytes[source.position + property.offset];
							return value < 246 ? value : toConstant(value);
						};
					}
					break;
				case DATE: get = function(source) {
					let src = source.bytes;
					let dataView = src.dataView || (src.dataView = new DataView(src.buffer, src.byteOffset, src.byteLength));
					return new Date(dataView.getFloat64(source.position + property.offset, true));
				};
			}
			property.get = get;
		}
		if (evalSupported) {
			let objectLiteralProperties = [];
			let args = [];
			let i = 0;
			let hasInheritedProperties;
			for (let property of properties) {
				if (unpackr.alwaysLazyProperty && unpackr.alwaysLazyProperty(property.key)) {
					hasInheritedProperties = true;
					continue;
				}
				Object.defineProperty(prototype, property.key, {
					get: withSource(property.get),
					enumerable: true
				});
				let valueFunction = "v" + i++;
				args.push(valueFunction);
				objectLiteralProperties.push("[" + JSON.stringify(property.key) + "]:" + valueFunction + "(s)");
			}
			if (hasInheritedProperties) objectLiteralProperties.push("__proto__:this");
			let toObject = new Function(...args, "return function(s){return{" + objectLiteralProperties.join(",") + "}}").apply(null, properties.map((prop) => prop.get));
			Object.defineProperty(prototype, "toJSON", { value(omitUnderscoredProperties) {
				return toObject.call(this, this[sourceSymbol]);
			} });
		} else Object.defineProperty(prototype, "toJSON", { value(omitUnderscoredProperties) {
			let resolved = {};
			for (let i = 0, l = properties.length; i < l; i++) {
				let key = properties[i].key;
				resolved[key] = this[key];
			}
			return resolved;
		} });
	}
	var instance = new construct();
	instance[sourceSymbol] = {
		bytes: src,
		position,
		srcString: "",
		bytesEnd: srcEnd
	};
	return instance;
}
function toConstant(code) {
	switch (code) {
		case 246: return null;
		case 247: return;
		case 248: return false;
		case 249: return true;
	}
	throw new Error("Unknown constant");
}
function withSource(get) {
	return function() {
		return get(this[sourceSymbol]);
	};
}
function saveState() {
	if (currentSource) {
		currentSource.bytes = Uint8Array.prototype.slice.call(currentSource.bytes, currentSource.position, currentSource.bytesEnd);
		currentSource.position = 0;
		currentSource.bytesEnd = currentSource.bytes.length;
	}
}
function prepareStructures(structures, packr) {
	if (packr.typedStructs) {
		let structMap = /* @__PURE__ */ new Map();
		structMap.set("named", structures);
		structMap.set("typed", packr.typedStructs);
		structures = structMap;
	}
	let lastTypedStructuresLength = packr.lastTypedStructuresLength || 0;
	structures.isCompatible = (existing) => {
		let compatible = true;
		if (existing instanceof Map) {
			if ((existing.get("named") || []).length !== (packr.lastNamedStructuresLength || 0)) compatible = false;
			if ((existing.get("typed") || []).length !== lastTypedStructuresLength) compatible = false;
		} else if (existing instanceof Array || Array.isArray(existing)) {
			if (existing.length !== (packr.lastNamedStructuresLength || 0)) compatible = false;
		}
		if (!compatible) packr._mergeStructures(existing);
		return compatible;
	};
	packr.lastTypedStructuresLength = packr.typedStructs && packr.typedStructs.length;
	return structures;
}
setReadStruct(readStruct, onLoadedStructures, saveState);
//#endregion
//#region node_modules/@colyseus/msgpackr/node-index.js
if (!(process.env.MSGPACKR_NATIVE_ACCELERATION_DISABLED !== void 0 && process.env.MSGPACKR_NATIVE_ACCELERATION_DISABLED.toLowerCase() === "true")) {
	let extractor;
	try {
		if (typeof __require == "function") extractor = __require("msgpackr-extract");
		else extractor = createRequire(import.meta.url)("msgpackr-extract");
		if (extractor) setExtractor(extractor.extractStrings);
	} catch (error) {}
}
//#endregion
export { unpack as n, Packr as t };
