//#region node_modules/@colyseus/schema/build/esm/index.mjs
var SWITCH_TO_STRUCTURE = 255;
var TYPE_ID = 213;
/**
* Encoding Schema field operations.
*/
var OPERATION;
(function(OPERATION) {
	OPERATION[OPERATION["ADD"] = 128] = "ADD";
	OPERATION[OPERATION["REPLACE"] = 0] = "REPLACE";
	OPERATION[OPERATION["DELETE"] = 64] = "DELETE";
	OPERATION[OPERATION["DELETE_AND_MOVE"] = 96] = "DELETE_AND_MOVE";
	OPERATION[OPERATION["MOVE_AND_ADD"] = 160] = "MOVE_AND_ADD";
	OPERATION[OPERATION["DELETE_AND_ADD"] = 192] = "DELETE_AND_ADD";
	/**
	* Collection operations
	*/
	OPERATION[OPERATION["CLEAR"] = 10] = "CLEAR";
	/**
	* ArraySchema operations
	*/
	OPERATION[OPERATION["REVERSE"] = 15] = "REVERSE";
	OPERATION[OPERATION["MOVE"] = 32] = "MOVE";
	OPERATION[OPERATION["DELETE_BY_REFID"] = 33] = "DELETE_BY_REFID";
	OPERATION[OPERATION["ADD_BY_REFID"] = 129] = "ADD_BY_REFID";
})(OPERATION || (OPERATION = {}));
Symbol.metadata ??= Symbol.for("Symbol.metadata");
var $track = "~track";
var $encoder = "~encoder";
var $decoder = "~decoder";
var $filter = "~filter";
var $getByIndex = "~getByIndex";
var $deleteByIndex = "~deleteByIndex";
/**
* Used to hold ChangeTree instances whitin the structures
*/
var $changes = "~changes";
/**
* Used to keep track of the type of the child elements of a collection
* (MapSchema, ArraySchema, etc.)
*/
var $childType = "~childType";
/**
* Optional "discard" method for custom types (ArraySchema)
* (Discards changes for next serialization)
*/
var $onEncodeEnd = "~onEncodeEnd";
/**
* When decoding, this method is called after the instance is fully decoded
*/
var $onDecodeEnd = "~onDecodeEnd";
/**
* Metadata
*/
var $descriptors = "~descriptors";
var $numFields = "~__numFields";
var $refTypeFieldIndexes = "~__refTypeFieldIndexes";
var $viewFieldIndexes = "~__viewFieldIndexes";
var $fieldIndexesByViewTag = "$__fieldIndexesByViewTag";
try {
	new TextEncoder();
} catch (e) {}
var _convoBuffer$1 = /* @__PURE__ */ new ArrayBuffer(8);
var _int32$1 = new Int32Array(_convoBuffer$1);
var _float32$1 = new Float32Array(_convoBuffer$1);
var _float64$1 = new Float64Array(_convoBuffer$1);
var _int64$1 = new BigInt64Array(_convoBuffer$1);
var utf8Length = typeof Buffer !== "undefined" && Buffer.byteLength ? Buffer.byteLength : function(str, _) {
	var c = 0, length = 0;
	for (var i = 0, l = str.length; i < l; i++) {
		c = str.charCodeAt(i);
		if (c < 128) length += 1;
		else if (c < 2048) length += 2;
		else if (c < 55296 || c >= 57344) length += 3;
		else {
			i++;
			length += 4;
		}
	}
	return length;
};
function utf8Write(view, str, it) {
	var c = 0;
	for (var i = 0, l = str.length; i < l; i++) {
		c = str.charCodeAt(i);
		if (c < 128) view[it.offset++] = c;
		else if (c < 2048) {
			view[it.offset] = 192 | c >> 6;
			view[it.offset + 1] = 128 | c & 63;
			it.offset += 2;
		} else if (c < 55296 || c >= 57344) {
			view[it.offset] = 224 | c >> 12;
			view[it.offset + 1] = 128 | c >> 6 & 63;
			view[it.offset + 2] = 128 | c & 63;
			it.offset += 3;
		} else {
			i++;
			c = 65536 + ((c & 1023) << 10 | str.charCodeAt(i) & 1023);
			view[it.offset] = 240 | c >> 18;
			view[it.offset + 1] = 128 | c >> 12 & 63;
			view[it.offset + 2] = 128 | c >> 6 & 63;
			view[it.offset + 3] = 128 | c & 63;
			it.offset += 4;
		}
	}
}
function int8$1(bytes, value, it) {
	bytes[it.offset++] = value & 255;
}
function uint8$1(bytes, value, it) {
	bytes[it.offset++] = value & 255;
}
function int16$1(bytes, value, it) {
	bytes[it.offset++] = value & 255;
	bytes[it.offset++] = value >> 8 & 255;
}
function uint16$1(bytes, value, it) {
	bytes[it.offset++] = value & 255;
	bytes[it.offset++] = value >> 8 & 255;
}
function int32$1(bytes, value, it) {
	bytes[it.offset++] = value & 255;
	bytes[it.offset++] = value >> 8 & 255;
	bytes[it.offset++] = value >> 16 & 255;
	bytes[it.offset++] = value >> 24 & 255;
}
function uint32$1(bytes, value, it) {
	const b4 = value >> 24;
	const b3 = value >> 16;
	const b2 = value >> 8;
	const b1 = value;
	bytes[it.offset++] = b1 & 255;
	bytes[it.offset++] = b2 & 255;
	bytes[it.offset++] = b3 & 255;
	bytes[it.offset++] = b4 & 255;
}
function int64$1(bytes, value, it) {
	const high = Math.floor(value / Math.pow(2, 32));
	uint32$1(bytes, value >>> 0, it);
	uint32$1(bytes, high, it);
}
function uint64$1(bytes, value, it) {
	const high = value / Math.pow(2, 32) >> 0;
	uint32$1(bytes, value >>> 0, it);
	uint32$1(bytes, high, it);
}
function bigint64$1(bytes, value, it) {
	_int64$1[0] = BigInt.asIntN(64, value);
	int32$1(bytes, _int32$1[0], it);
	int32$1(bytes, _int32$1[1], it);
}
function biguint64$1(bytes, value, it) {
	_int64$1[0] = BigInt.asIntN(64, value);
	int32$1(bytes, _int32$1[0], it);
	int32$1(bytes, _int32$1[1], it);
}
function float32$1(bytes, value, it) {
	_float32$1[0] = value;
	int32$1(bytes, _int32$1[0], it);
}
function float64$1(bytes, value, it) {
	_float64$1[0] = value;
	int32$1(bytes, _int32$1[0], it);
	int32$1(bytes, _int32$1[1], it);
}
function boolean$1(bytes, value, it) {
	bytes[it.offset++] = value ? 1 : 0;
}
function string$1(bytes, value, it) {
	if (!value) value = "";
	let length = utf8Length(value, "utf8");
	let size = 0;
	if (length < 32) {
		bytes[it.offset++] = length | 160;
		size = 1;
	} else if (length < 256) {
		bytes[it.offset++] = 217;
		bytes[it.offset++] = length % 255;
		size = 2;
	} else if (length < 65536) {
		bytes[it.offset++] = 218;
		uint16$1(bytes, length, it);
		size = 3;
	} else if (length < 4294967296) {
		bytes[it.offset++] = 219;
		uint32$1(bytes, length, it);
		size = 5;
	} else throw new Error("String too long");
	utf8Write(bytes, value, it);
	return size + length;
}
function number$1(bytes, value, it) {
	if (isNaN(value)) return number$1(bytes, 0, it);
	else if (!isFinite(value)) return number$1(bytes, value > 0 ? Number.MAX_SAFE_INTEGER : -Number.MAX_SAFE_INTEGER, it);
	else if (value !== (value | 0)) {
		if (Math.abs(value) <= 34028235e31) {
			_float32$1[0] = value;
			if (Math.abs(Math.abs(_float32$1[0]) - Math.abs(value)) < 1e-4) {
				bytes[it.offset++] = 202;
				float32$1(bytes, value, it);
				return 5;
			}
		}
		bytes[it.offset++] = 203;
		float64$1(bytes, value, it);
		return 9;
	}
	if (value >= 0) {
		if (value < 128) {
			bytes[it.offset++] = value & 255;
			return 1;
		}
		if (value < 256) {
			bytes[it.offset++] = 204;
			bytes[it.offset++] = value & 255;
			return 2;
		}
		if (value < 65536) {
			bytes[it.offset++] = 205;
			uint16$1(bytes, value, it);
			return 3;
		}
		if (value < 4294967296) {
			bytes[it.offset++] = 206;
			uint32$1(bytes, value, it);
			return 5;
		}
		bytes[it.offset++] = 207;
		uint64$1(bytes, value, it);
		return 9;
	} else {
		if (value >= -32) {
			bytes[it.offset++] = 224 | value + 32;
			return 1;
		}
		if (value >= -128) {
			bytes[it.offset++] = 208;
			int8$1(bytes, value, it);
			return 2;
		}
		if (value >= -32768) {
			bytes[it.offset++] = 209;
			int16$1(bytes, value, it);
			return 3;
		}
		if (value >= -2147483648) {
			bytes[it.offset++] = 210;
			int32$1(bytes, value, it);
			return 5;
		}
		bytes[it.offset++] = 211;
		int64$1(bytes, value, it);
		return 9;
	}
}
var encode = {
	int8: int8$1,
	uint8: uint8$1,
	int16: int16$1,
	uint16: uint16$1,
	int32: int32$1,
	uint32: uint32$1,
	int64: int64$1,
	uint64: uint64$1,
	bigint64: bigint64$1,
	biguint64: biguint64$1,
	float32: float32$1,
	float64: float64$1,
	boolean: boolean$1,
	string: string$1,
	number: number$1,
	utf8Write,
	utf8Length
};
var _convoBuffer = /* @__PURE__ */ new ArrayBuffer(8);
var _int32 = new Int32Array(_convoBuffer);
var _float32 = new Float32Array(_convoBuffer);
var _float64 = new Float64Array(_convoBuffer);
var _uint64 = new BigUint64Array(_convoBuffer);
var _int64 = new BigInt64Array(_convoBuffer);
function utf8Read(bytes, it, length) {
	if (length > bytes.length - it.offset) length = bytes.length - it.offset;
	var string = "", chr = 0;
	for (var i = it.offset, end = it.offset + length; i < end; i++) {
		var byte = bytes[i];
		if ((byte & 128) === 0) {
			string += String.fromCharCode(byte);
			continue;
		}
		if ((byte & 224) === 192) {
			string += String.fromCharCode((byte & 31) << 6 | bytes[++i] & 63);
			continue;
		}
		if ((byte & 240) === 224) {
			string += String.fromCharCode((byte & 15) << 12 | (bytes[++i] & 63) << 6 | (bytes[++i] & 63) << 0);
			continue;
		}
		if ((byte & 248) === 240) {
			chr = (byte & 7) << 18 | (bytes[++i] & 63) << 12 | (bytes[++i] & 63) << 6 | (bytes[++i] & 63) << 0;
			if (chr >= 65536) {
				chr -= 65536;
				string += String.fromCharCode((chr >>> 10) + 55296, (chr & 1023) + 56320);
			} else string += String.fromCharCode(chr);
			continue;
		}
		console.error("decode.utf8Read(): Invalid byte " + byte + " at offset " + i + ". Skip to end of string: " + (it.offset + length));
		break;
	}
	it.offset += length;
	return string;
}
function int8(bytes, it) {
	return uint8(bytes, it) << 24 >> 24;
}
function uint8(bytes, it) {
	return bytes[it.offset++];
}
function int16(bytes, it) {
	return uint16(bytes, it) << 16 >> 16;
}
function uint16(bytes, it) {
	return bytes[it.offset++] | bytes[it.offset++] << 8;
}
function int32(bytes, it) {
	return bytes[it.offset++] | bytes[it.offset++] << 8 | bytes[it.offset++] << 16 | bytes[it.offset++] << 24;
}
function uint32(bytes, it) {
	return int32(bytes, it) >>> 0;
}
function float32(bytes, it) {
	_int32[0] = int32(bytes, it);
	return _float32[0];
}
function float64(bytes, it) {
	_int32[0] = int32(bytes, it);
	_int32[1] = int32(bytes, it);
	return _float64[0];
}
function int64(bytes, it) {
	const low = uint32(bytes, it);
	return int32(bytes, it) * Math.pow(2, 32) + low;
}
function uint64(bytes, it) {
	const low = uint32(bytes, it);
	return uint32(bytes, it) * Math.pow(2, 32) + low;
}
function bigint64(bytes, it) {
	_int32[0] = int32(bytes, it);
	_int32[1] = int32(bytes, it);
	return _int64[0];
}
function biguint64(bytes, it) {
	_int32[0] = int32(bytes, it);
	_int32[1] = int32(bytes, it);
	return _uint64[0];
}
function boolean(bytes, it) {
	return uint8(bytes, it) > 0;
}
function string(bytes, it) {
	const prefix = bytes[it.offset++];
	let length;
	if (prefix < 192) length = prefix & 31;
	else if (prefix === 217) length = uint8(bytes, it);
	else if (prefix === 218) length = uint16(bytes, it);
	else if (prefix === 219) length = uint32(bytes, it);
	return utf8Read(bytes, it, length);
}
function number(bytes, it) {
	const prefix = bytes[it.offset++];
	if (prefix < 128) return prefix;
	else if (prefix === 202) return float32(bytes, it);
	else if (prefix === 203) return float64(bytes, it);
	else if (prefix === 204) return uint8(bytes, it);
	else if (prefix === 205) return uint16(bytes, it);
	else if (prefix === 206) return uint32(bytes, it);
	else if (prefix === 207) return uint64(bytes, it);
	else if (prefix === 208) return int8(bytes, it);
	else if (prefix === 209) return int16(bytes, it);
	else if (prefix === 210) return int32(bytes, it);
	else if (prefix === 211) return int64(bytes, it);
	else if (prefix > 223) return (255 - prefix + 1) * -1;
}
function stringCheck(bytes, it) {
	const prefix = bytes[it.offset];
	return prefix < 192 && prefix > 160 || prefix === 217 || prefix === 218 || prefix === 219;
}
var decode = {
	utf8Read,
	int8,
	uint8,
	int16,
	uint16,
	int32,
	uint32,
	float32,
	float64,
	int64,
	uint64,
	bigint64,
	biguint64,
	boolean,
	string,
	number,
	stringCheck
};
var registeredTypes = {};
var identifiers = /* @__PURE__ */ new Map();
function registerType(identifier, definition) {
	if (definition.constructor) {
		identifiers.set(definition.constructor, identifier);
		registeredTypes[identifier] = definition;
	}
	if (definition.encode) encode[identifier] = definition.encode;
	if (definition.decode) decode[identifier] = definition.decode;
}
function getType(identifier) {
	return registeredTypes[identifier];
}
var TypeContext = class TypeContext {
	/**
	* For inheritance support
	* Keeps track of which classes extends which. (parent -> children)
	*/
	static {
		this.inheritedTypes = /* @__PURE__ */ new Map();
	}
	static {
		this.cachedContexts = /* @__PURE__ */ new Map();
	}
	static register(target) {
		const parent = Object.getPrototypeOf(target);
		if (parent !== Schema) {
			let inherits = TypeContext.inheritedTypes.get(parent);
			if (!inherits) {
				inherits = /* @__PURE__ */ new Set();
				TypeContext.inheritedTypes.set(parent, inherits);
			}
			inherits.add(target);
		}
	}
	static cache(rootClass) {
		let context = TypeContext.cachedContexts.get(rootClass);
		if (!context) {
			context = new TypeContext(rootClass);
			TypeContext.cachedContexts.set(rootClass, context);
		}
		return context;
	}
	constructor(rootClass) {
		this.types = {};
		this.schemas = /* @__PURE__ */ new Map();
		this.hasFilters = false;
		this.parentFiltered = {};
		if (rootClass) this.discoverTypes(rootClass);
	}
	has(schema) {
		return this.schemas.has(schema);
	}
	get(typeid) {
		return this.types[typeid];
	}
	add(schema, typeid = this.schemas.size) {
		if (this.schemas.has(schema)) return false;
		this.types[typeid] = schema;
		if (schema[Symbol.metadata] === void 0) Metadata.initialize(schema);
		this.schemas.set(schema, typeid);
		return true;
	}
	getTypeId(klass) {
		return this.schemas.get(klass);
	}
	discoverTypes(klass, parentType, parentIndex, parentHasViewTag) {
		if (parentHasViewTag) this.registerFilteredByParent(klass, parentType, parentIndex);
		if (!this.add(klass)) return;
		TypeContext.inheritedTypes.get(klass)?.forEach((child) => {
			this.discoverTypes(child, parentType, parentIndex, parentHasViewTag);
		});
		let parent = klass;
		while ((parent = Object.getPrototypeOf(parent)) && parent !== Schema && parent !== Function.prototype) this.discoverTypes(parent);
		const metadata = klass[Symbol.metadata] ??= {};
		if (metadata[$viewFieldIndexes]) this.hasFilters = true;
		for (const fieldIndex in metadata) {
			const index = fieldIndex;
			const fieldType = metadata[index].type;
			const fieldHasViewTag = metadata[index].tag !== void 0;
			if (typeof fieldType === "string") continue;
			if (typeof fieldType === "function") this.discoverTypes(fieldType, klass, index, parentHasViewTag || fieldHasViewTag);
			else {
				const type = Object.values(fieldType)[0];
				if (typeof type === "string") continue;
				this.discoverTypes(type, klass, index, parentHasViewTag || fieldHasViewTag);
			}
		}
	}
	/**
	* Keep track of which classes have filters applied.
	* Format: `${typeid}-${parentTypeid}-${parentIndex}`
	*/
	registerFilteredByParent(schema, parentType, parentIndex) {
		let key = `${this.schemas.get(schema) ?? this.schemas.size}`;
		if (parentType) key += `-${this.schemas.get(parentType)}`;
		key += `-${parentIndex}`;
		this.parentFiltered[key] = true;
	}
	debug() {
		let parentFiltered = "";
		for (const key in this.parentFiltered) {
			const keys = key.split("-").map(Number);
			const fieldIndex = keys.pop();
			parentFiltered += `\n\t\t`;
			parentFiltered += `${key}: ${keys.reverse().map((id, i) => {
				const klass = this.types[id];
				const metadata = klass[Symbol.metadata];
				let txt = klass.name;
				if (i === 0) txt += `[${metadata[fieldIndex].name}]`;
				return `${txt}`;
			}).join(" -> ")}`;
		}
		return `TypeContext ->\n\tSchema types: ${this.schemas.size}\n\thasFilters: ${this.hasFilters}\n\tparentFiltered:${parentFiltered}`;
	}
};
function getNormalizedType(type) {
	if (Array.isArray(type)) return { array: getNormalizedType(type[0]) };
	else if (typeof type["type"] !== "undefined") return type["type"];
	else if (isTSEnum(type)) return Object.keys(type).every((key) => typeof type[key] === "string") ? "string" : "number";
	else if (typeof type === "object" && type !== null) {
		const collectionType = Object.keys(type).find((k) => registeredTypes[k] !== void 0);
		if (collectionType) {
			type[collectionType] = getNormalizedType(type[collectionType]);
			return type;
		}
	}
	return type;
}
function isTSEnum(_enum) {
	if (typeof _enum === "function" && _enum[Symbol.metadata]) return false;
	const keys = Object.keys(_enum);
	const numericFields = keys.filter((k) => /\d+/.test(k));
	if (numericFields.length > 0 && numericFields.length === keys.length / 2 && _enum[_enum[numericFields[0]]] == numericFields[0]) return true;
	if (keys.length > 0 && keys.every((key) => typeof _enum[key] === "string" && _enum[key] === key)) return true;
	return false;
}
var Metadata = {
	addField(metadata, index, name, type, descriptor) {
		if (index > 64) throw new Error(`Can't define field '${name}'.\nSchema instances may only have up to 64 fields.`);
		metadata[index] = Object.assign(metadata[index] || {}, {
			type: getNormalizedType(type),
			index,
			name
		});
		Object.defineProperty(metadata, $descriptors, {
			value: metadata[$descriptors] || {},
			enumerable: false,
			configurable: true
		});
		if (descriptor) {
			metadata[$descriptors][name] = descriptor;
			metadata[$descriptors][`_${name}`] = {
				value: void 0,
				writable: true,
				enumerable: false,
				configurable: true
			};
		} else metadata[$descriptors][name] = {
			value: void 0,
			writable: true,
			enumerable: true,
			configurable: true
		};
		Object.defineProperty(metadata, $numFields, {
			value: index,
			enumerable: false,
			configurable: true
		});
		Object.defineProperty(metadata, name, {
			value: index,
			enumerable: false,
			configurable: true
		});
		if (typeof metadata[index].type !== "string") {
			if (metadata[$refTypeFieldIndexes] === void 0) Object.defineProperty(metadata, $refTypeFieldIndexes, {
				value: [],
				enumerable: false,
				configurable: true
			});
			metadata[$refTypeFieldIndexes].push(index);
		}
	},
	setTag(metadata, fieldName, tag) {
		const index = metadata[fieldName];
		const field = metadata[index];
		field.tag = tag;
		if (!metadata[$viewFieldIndexes]) {
			Object.defineProperty(metadata, $viewFieldIndexes, {
				value: [],
				enumerable: false,
				configurable: true
			});
			Object.defineProperty(metadata, $fieldIndexesByViewTag, {
				value: {},
				enumerable: false,
				configurable: true
			});
		}
		metadata[$viewFieldIndexes].push(index);
		if (!metadata[$fieldIndexesByViewTag][tag]) metadata[$fieldIndexesByViewTag][tag] = [];
		metadata[$fieldIndexesByViewTag][tag].push(index);
	},
	setFields(target, fields) {
		const constructor = target.prototype.constructor;
		TypeContext.register(constructor);
		const parentClass = Object.getPrototypeOf(constructor);
		const parentMetadata = parentClass && parentClass[Symbol.metadata];
		const metadata = Metadata.initialize(constructor);
		if (!constructor["~track"]) constructor[$track] = Schema[$track];
		if (!constructor["~encoder"]) constructor[$encoder] = Schema[$encoder];
		if (!constructor["~decoder"]) constructor[$decoder] = Schema[$decoder];
		if (!constructor.prototype.toJSON) constructor.prototype.toJSON = Schema.prototype.toJSON;
		let fieldIndex = metadata[$numFields] ?? (parentMetadata && parentMetadata[$numFields]) ?? -1;
		fieldIndex++;
		for (const field in fields) {
			const type = getNormalizedType(fields[field]);
			const complexTypeKlass = typeof Object.keys(type)[0] === "string" && getType(Object.keys(type)[0]);
			const childType = complexTypeKlass ? Object.values(type)[0] : type;
			Metadata.addField(metadata, fieldIndex, field, type, getPropertyDescriptor(`_${field}`, fieldIndex, childType, complexTypeKlass));
			fieldIndex++;
		}
		return target;
	},
	isDeprecated(metadata, field) {
		return metadata[field].deprecated === true;
	},
	init(klass) {
		const metadata = {};
		klass[Symbol.metadata] = metadata;
		Object.defineProperty(metadata, $numFields, {
			value: 0,
			enumerable: false,
			configurable: true
		});
	},
	initialize(constructor) {
		const parentClass = Object.getPrototypeOf(constructor);
		const parentMetadata = parentClass[Symbol.metadata];
		let metadata = constructor[Symbol.metadata] ?? Object.create(null);
		if (parentClass !== Schema && metadata === parentMetadata) {
			metadata = Object.create(null);
			if (parentMetadata) {
				Object.setPrototypeOf(metadata, parentMetadata);
				Object.defineProperty(metadata, $numFields, {
					value: parentMetadata[$numFields],
					enumerable: false,
					configurable: true,
					writable: true
				});
				if (parentMetadata[$viewFieldIndexes] !== void 0) {
					Object.defineProperty(metadata, $viewFieldIndexes, {
						value: [...parentMetadata[$viewFieldIndexes]],
						enumerable: false,
						configurable: true,
						writable: true
					});
					Object.defineProperty(metadata, $fieldIndexesByViewTag, {
						value: { ...parentMetadata[$fieldIndexesByViewTag] },
						enumerable: false,
						configurable: true,
						writable: true
					});
				}
				if (parentMetadata[$refTypeFieldIndexes] !== void 0) Object.defineProperty(metadata, $refTypeFieldIndexes, {
					value: [...parentMetadata[$refTypeFieldIndexes]],
					enumerable: false,
					configurable: true,
					writable: true
				});
				Object.defineProperty(metadata, $descriptors, {
					value: { ...parentMetadata[$descriptors] },
					enumerable: false,
					configurable: true,
					writable: true
				});
			}
		}
		Object.defineProperty(constructor, Symbol.metadata, {
			value: metadata,
			writable: false,
			configurable: true
		});
		return metadata;
	},
	isValidInstance(klass) {
		return klass.constructor[Symbol.metadata] && Object.prototype.hasOwnProperty.call(klass.constructor[Symbol.metadata], $numFields);
	},
	getFields(klass) {
		const metadata = klass[Symbol.metadata];
		const fields = {};
		for (let i = 0; i <= metadata[$numFields]; i++) fields[metadata[i].name] = metadata[i].type;
		return fields;
	},
	hasViewTagAtIndex(metadata, index) {
		return metadata?.[$viewFieldIndexes]?.includes(index);
	}
};
function createChangeSet(queueRootNode) {
	return {
		indexes: {},
		operations: [],
		queueRootNode
	};
}
function createChangeTreeList() {
	return {
		next: void 0,
		tail: void 0
	};
}
function setOperationAtIndex(changeSet, index) {
	const operationsIndex = changeSet.indexes[index];
	if (operationsIndex === void 0) changeSet.indexes[index] = changeSet.operations.push(index) - 1;
	else changeSet.operations[operationsIndex] = index;
}
function deleteOperationAtIndex(changeSet, index) {
	let operationsIndex = changeSet.indexes[index];
	if (operationsIndex === void 0) {
		operationsIndex = Object.values(changeSet.indexes).at(-1);
		index = Object.entries(changeSet.indexes).find(([_, value]) => value === operationsIndex)?.[0];
	}
	changeSet.operations[operationsIndex] = void 0;
	delete changeSet.indexes[index];
}
var ChangeTree = class {
	constructor(ref) {
		/**
		* Whether this structure is parent of a filtered structure.
		*/
		this.isFiltered = false;
		this.indexedOperations = {};
		this.changes = {
			indexes: {},
			operations: []
		};
		this.allChanges = {
			indexes: {},
			operations: []
		};
		/**
		* Is this a new instance? Used on ArraySchema to determine OPERATION.MOVE_AND_ADD operation.
		*/
		this.isNew = true;
		this.ref = ref;
		this.metadata = ref.constructor[Symbol.metadata];
		if (this.metadata?.[$viewFieldIndexes]) {
			this.allFilteredChanges = {
				indexes: {},
				operations: []
			};
			this.filteredChanges = {
				indexes: {},
				operations: []
			};
		}
	}
	setRoot(root) {
		this.root = root;
		const isNewChangeTree = this.root.add(this);
		this.checkIsFiltered(this.parent, this.parentIndex, isNewChangeTree);
		if (isNewChangeTree) this.forEachChild((child, _) => {
			if (child.root !== root) child.setRoot(root);
			else root.add(child);
		});
	}
	setParent(parent, root, parentIndex) {
		this.addParent(parent, parentIndex);
		if (!root) return;
		const isNewChangeTree = root.add(this);
		if (root !== this.root) {
			this.root = root;
			this.checkIsFiltered(parent, parentIndex, isNewChangeTree);
		}
		if (isNewChangeTree) this.forEachChild((child, index) => {
			if (child.root === root) {
				root.add(child);
				root.moveNextToParent(child);
				return;
			}
			child.setParent(this.ref, root, index);
		});
	}
	forEachChild(callback) {
		if (this.ref["~childType"]) {
			if (typeof this.ref["~childType"] !== "string") for (const [key, value] of this.ref.entries()) {
				if (!value) continue;
				callback(value[$changes], this.indexes?.[key] ?? key);
			}
		} else for (const index of this.metadata?.[$refTypeFieldIndexes] ?? []) {
			const field = this.metadata[index];
			const value = this.ref[field.name];
			if (!value) continue;
			callback(value[$changes], index);
		}
	}
	operation(op) {
		if (this.filteredChanges !== void 0) {
			this.filteredChanges.operations.push(-op);
			this.root?.enqueueChangeTree(this, "filteredChanges");
		} else {
			this.changes.operations.push(-op);
			this.root?.enqueueChangeTree(this, "changes");
		}
	}
	change(index, operation = OPERATION.ADD) {
		const isFiltered = this.isFiltered || this.metadata?.[index]?.tag !== void 0;
		const changeSet = isFiltered ? this.filteredChanges : this.changes;
		const previousOperation = this.indexedOperations[index];
		if (!previousOperation || previousOperation === OPERATION.DELETE) {
			const op = !previousOperation ? operation : previousOperation === OPERATION.DELETE ? OPERATION.DELETE_AND_ADD : operation;
			this.indexedOperations[index] = op;
		}
		setOperationAtIndex(changeSet, index);
		if (isFiltered) {
			setOperationAtIndex(this.allFilteredChanges, index);
			if (this.root) {
				this.root.enqueueChangeTree(this, "filteredChanges");
				this.root.enqueueChangeTree(this, "allFilteredChanges");
			}
		} else {
			setOperationAtIndex(this.allChanges, index);
			this.root?.enqueueChangeTree(this, "changes");
		}
	}
	shiftChangeIndexes(shiftIndex) {
		const changeSet = this.isFiltered ? this.filteredChanges : this.changes;
		const newIndexedOperations = {};
		const newIndexes = {};
		for (const index in this.indexedOperations) {
			newIndexedOperations[Number(index) + shiftIndex] = this.indexedOperations[index];
			newIndexes[Number(index) + shiftIndex] = changeSet.indexes[index];
		}
		this.indexedOperations = newIndexedOperations;
		changeSet.indexes = newIndexes;
		changeSet.operations = changeSet.operations.map((index) => index + shiftIndex);
	}
	shiftAllChangeIndexes(shiftIndex, startIndex = 0) {
		if (this.filteredChanges !== void 0) {
			this._shiftAllChangeIndexes(shiftIndex, startIndex, this.allFilteredChanges);
			this._shiftAllChangeIndexes(shiftIndex, startIndex, this.allChanges);
		} else this._shiftAllChangeIndexes(shiftIndex, startIndex, this.allChanges);
	}
	_shiftAllChangeIndexes(shiftIndex, startIndex = 0, changeSet) {
		const newIndexes = {};
		let newKey = 0;
		for (const key in changeSet.indexes) newIndexes[newKey++] = changeSet.indexes[key];
		changeSet.indexes = newIndexes;
		for (let i = 0; i < changeSet.operations.length; i++) {
			const index = changeSet.operations[i];
			if (index > startIndex) changeSet.operations[i] = index + shiftIndex;
		}
	}
	indexedOperation(index, operation, allChangesIndex = index) {
		this.indexedOperations[index] = operation;
		if (this.filteredChanges !== void 0) {
			setOperationAtIndex(this.allFilteredChanges, allChangesIndex);
			setOperationAtIndex(this.filteredChanges, index);
			this.root?.enqueueChangeTree(this, "filteredChanges");
		} else {
			setOperationAtIndex(this.allChanges, allChangesIndex);
			setOperationAtIndex(this.changes, index);
			this.root?.enqueueChangeTree(this, "changes");
		}
	}
	getType(index) {
		return this.ref["~childType"] || this.metadata[index].type;
	}
	getChange(index) {
		return this.indexedOperations[index];
	}
	getValue(index, isEncodeAll = false) {
		return this.ref[$getByIndex](index, isEncodeAll);
	}
	delete(index, operation, allChangesIndex = index) {
		if (index === void 0) {
			try {
				throw new Error(`@colyseus/schema ${this.ref.constructor.name}: trying to delete non-existing index '${index}'`);
			} catch (e) {
				console.warn(e);
			}
			return;
		}
		const changeSet = this.filteredChanges !== void 0 ? this.filteredChanges : this.changes;
		this.indexedOperations[index] = operation ?? OPERATION.DELETE;
		setOperationAtIndex(changeSet, index);
		deleteOperationAtIndex(this.allChanges, allChangesIndex);
		const previousValue = this.getValue(index);
		if (previousValue && previousValue["~changes"]) this.root?.remove(previousValue[$changes]);
		if (this.filteredChanges !== void 0) {
			deleteOperationAtIndex(this.allFilteredChanges, allChangesIndex);
			this.root?.enqueueChangeTree(this, "filteredChanges");
		} else this.root?.enqueueChangeTree(this, "changes");
		return previousValue;
	}
	endEncode(changeSetName) {
		this.indexedOperations = {};
		this[changeSetName] = createChangeSet();
		this.ref[$onEncodeEnd]?.();
		this.isNew = false;
	}
	discard(discardAll = false) {
		this.ref[$onEncodeEnd]?.();
		this.indexedOperations = {};
		this.changes = createChangeSet(this.changes.queueRootNode);
		if (this.filteredChanges !== void 0) this.filteredChanges = createChangeSet(this.filteredChanges.queueRootNode);
		if (discardAll) {
			this.allChanges = createChangeSet(this.allChanges.queueRootNode);
			if (this.allFilteredChanges !== void 0) this.allFilteredChanges = createChangeSet(this.allFilteredChanges.queueRootNode);
		}
	}
	/**
	* Recursively discard all changes from this, and child structures.
	* (Used in tests only)
	*/
	discardAll() {
		const keys = Object.keys(this.indexedOperations);
		for (let i = 0, len = keys.length; i < len; i++) {
			const value = this.getValue(Number(keys[i]));
			if (value && value["~changes"]) value[$changes].discardAll();
		}
		this.discard();
	}
	get changed() {
		return Object.entries(this.indexedOperations).length > 0;
	}
	checkIsFiltered(parent, parentIndex, isNewChangeTree) {
		if (this.root.types.hasFilters) {
			this._checkFilteredByParent(parent, parentIndex);
			if (this.filteredChanges !== void 0) {
				this.root?.enqueueChangeTree(this, "filteredChanges");
				if (isNewChangeTree) this.root?.enqueueChangeTree(this, "allFilteredChanges");
			}
		}
		if (!this.isFiltered) {
			this.root?.enqueueChangeTree(this, "changes");
			if (isNewChangeTree) this.root?.enqueueChangeTree(this, "allChanges");
		}
	}
	_checkFilteredByParent(parent, parentIndex) {
		if (!parent) return;
		const refType = Metadata.isValidInstance(this.ref) ? this.ref.constructor : this.ref[$childType];
		let parentChangeTree;
		let parentIsCollection = !Metadata.isValidInstance(parent);
		if (parentIsCollection) {
			parentChangeTree = parent[$changes];
			parent = parentChangeTree.parent;
			parentIndex = parentChangeTree.parentIndex;
		} else parentChangeTree = parent[$changes];
		const parentConstructor = parent.constructor;
		let key = `${this.root.types.getTypeId(refType)}`;
		if (parentConstructor) key += `-${this.root.types.schemas.get(parentConstructor)}`;
		key += `-${parentIndex}`;
		const fieldHasViewTag = Metadata.hasViewTagAtIndex(parentConstructor?.[Symbol.metadata], parentIndex);
		this.isFiltered = parent["~changes"].isFiltered || this.root.types.parentFiltered[key] || fieldHasViewTag;
		if (this.isFiltered) {
			this.isVisibilitySharedWithParent = parentChangeTree.isFiltered && typeof refType !== "string" && !fieldHasViewTag && parentIsCollection;
			if (!this.filteredChanges) {
				this.filteredChanges = createChangeSet();
				this.allFilteredChanges = createChangeSet();
			}
			if (this.changes.operations.length > 0) {
				this.changes.operations.forEach((index) => setOperationAtIndex(this.filteredChanges, index));
				this.allChanges.operations.forEach((index) => setOperationAtIndex(this.allFilteredChanges, index));
				this.changes = createChangeSet();
				this.allChanges = createChangeSet();
			}
		}
	}
	/**
	* Get the immediate parent
	*/
	get parent() {
		return this.parentChain?.ref;
	}
	/**
	* Get the immediate parent index
	*/
	get parentIndex() {
		return this.parentChain?.index;
	}
	/**
	* Add a parent to the chain
	*/
	addParent(parent, index) {
		if (this.hasParent((p, _) => p["~changes"] === parent["~changes"])) {
			this.parentChain.index = index;
			return;
		}
		this.parentChain = {
			ref: parent,
			index,
			next: this.parentChain
		};
	}
	/**
	* Remove a parent from the chain
	* @param parent - The parent to remove
	* @returns true if parent was removed
	*/
	removeParent(parent = this.parent) {
		let current = this.parentChain;
		let previous = null;
		while (current) {
			if (current.ref["~changes"] === parent["~changes"]) {
				if (previous) previous.next = current.next;
				else this.parentChain = current.next;
				return true;
			}
			previous = current;
			current = current.next;
		}
		return this.parentChain === void 0;
	}
	/**
	* Find a specific parent in the chain
	*/
	findParent(predicate) {
		let current = this.parentChain;
		while (current) {
			if (predicate(current.ref, current.index)) return current;
			current = current.next;
		}
	}
	/**
	* Check if this ChangeTree has a specific parent
	*/
	hasParent(predicate) {
		return this.findParent(predicate) !== void 0;
	}
	/**
	* Get all parents as an array (for debugging/testing)
	*/
	getAllParents() {
		const parents = [];
		let current = this.parentChain;
		while (current) {
			parents.push({
				ref: current.ref,
				index: current.index
			});
			current = current.next;
		}
		return parents;
	}
};
function encodeValue(encoder, bytes, type, value, operation, it) {
	if (typeof type === "string") encode[type]?.(bytes, value, it);
	else if (type[Symbol.metadata] !== void 0) {
		encode.number(bytes, value[$changes].refId, it);
		if ((operation & OPERATION.ADD) === OPERATION.ADD) encoder.tryEncodeTypeId(bytes, type, value.constructor, it);
	} else encode.number(bytes, value[$changes].refId, it);
}
/**
* Used for Schema instances.
* @private
*/
var encodeSchemaOperation = function(encoder, bytes, changeTree, index, operation, it, _, __, metadata) {
	bytes[it.offset++] = (index | operation) & 255;
	if (operation === OPERATION.DELETE) return;
	const ref = changeTree.ref;
	const field = metadata[index];
	encodeValue(encoder, bytes, metadata[index].type, ref[field.name], operation, it);
};
/**
* Used for collections (MapSchema, CollectionSchema, SetSchema)
* @private
*/
var encodeKeyValueOperation = function(encoder, bytes, changeTree, index, operation, it) {
	bytes[it.offset++] = operation & 255;
	encode.number(bytes, index, it);
	if (operation === OPERATION.DELETE) return;
	const ref = changeTree.ref;
	if ((operation & OPERATION.ADD) === OPERATION.ADD) {
		if (typeof ref["set"] === "function") {
			const dynamicIndex = changeTree.ref["$indexes"].get(index);
			encode.string(bytes, dynamicIndex, it);
		}
	}
	const type = ref[$childType];
	encodeValue(encoder, bytes, type, ref[$getByIndex](index), operation, it);
};
/**
* Used for collections (MapSchema, ArraySchema, etc.)
* @private
*/
var encodeArray = function(encoder, bytes, changeTree, field, operation, it, isEncodeAll, hasView) {
	const ref = changeTree.ref;
	const useOperationByRefId = hasView && changeTree.isFiltered && typeof changeTree.getType(field) !== "string";
	let refOrIndex;
	if (useOperationByRefId) {
		const item = ref["tmpItems"][field];
		if (!item) return;
		refOrIndex = item[$changes].refId;
		if (operation === OPERATION.DELETE) operation = OPERATION.DELETE_BY_REFID;
		else if (operation === OPERATION.ADD) operation = OPERATION.ADD_BY_REFID;
	} else refOrIndex = field;
	bytes[it.offset++] = operation & 255;
	encode.number(bytes, refOrIndex, it);
	if (operation === OPERATION.DELETE || operation === OPERATION.DELETE_BY_REFID) return;
	encodeValue(encoder, bytes, changeTree.getType(field), changeTree.getValue(field, isEncodeAll), operation, it);
};
var DEFINITION_MISMATCH = -1;
function decodeValue(decoder, operation, ref, index, type, bytes, it, allChanges) {
	const $root = decoder.root;
	const previousValue = ref[$getByIndex](index);
	let value;
	if ((operation & OPERATION.DELETE) === OPERATION.DELETE) {
		const previousRefId = $root.refIds.get(previousValue);
		if (previousRefId !== void 0) $root.removeRef(previousRefId);
		if (operation !== OPERATION.DELETE_AND_ADD) ref[$deleteByIndex](index);
		value = void 0;
	}
	if (operation === OPERATION.DELETE);
	else if (Schema.is(type)) {
		const refId = decode.number(bytes, it);
		value = $root.refs.get(refId);
		if ((operation & OPERATION.ADD) === OPERATION.ADD) {
			const childType = decoder.getInstanceType(bytes, it, type);
			if (!value) value = decoder.createInstanceOfType(childType);
			$root.addRef(refId, value, value !== previousValue || operation === OPERATION.DELETE_AND_ADD && value === previousValue);
		}
	} else if (typeof type === "string") value = decode[type](bytes, it);
	else {
		const typeDef = getType(Object.keys(type)[0]);
		const refId = decode.number(bytes, it);
		const valueRef = $root.refs.has(refId) ? previousValue || $root.refs.get(refId) : new typeDef.constructor();
		value = valueRef.clone(true);
		value[$childType] = Object.values(type)[0];
		if (previousValue) {
			let previousRefId = $root.refIds.get(previousValue);
			if (previousRefId !== void 0 && refId !== previousRefId) {
				const entries = previousValue.entries();
				let iter;
				while ((iter = entries.next()) && !iter.done) {
					const [key, value] = iter.value;
					if (typeof value === "object") {
						previousRefId = $root.refIds.get(value);
						$root.removeRef(previousRefId);
					}
					allChanges.push({
						ref: previousValue,
						refId: previousRefId,
						op: OPERATION.DELETE,
						field: key,
						value: void 0,
						previousValue: value
					});
				}
			}
		}
		$root.addRef(refId, value, valueRef !== previousValue || operation === OPERATION.DELETE_AND_ADD && valueRef === previousValue);
	}
	return {
		value,
		previousValue
	};
}
var decodeSchemaOperation = function(decoder, bytes, it, ref, allChanges) {
	const first_byte = bytes[it.offset++];
	const metadata = ref.constructor[Symbol.metadata];
	const operation = first_byte >> 6 << 6;
	const index = first_byte % (operation || 255);
	const field = metadata[index];
	if (field === void 0) {
		console.warn("@colyseus/schema: field not defined at", {
			index,
			ref: ref.constructor.name,
			metadata
		});
		return DEFINITION_MISMATCH;
	}
	const { value, previousValue } = decodeValue(decoder, operation, ref, index, field.type, bytes, it, allChanges);
	if (value !== null && value !== void 0) ref[field.name] = value;
	if (previousValue !== value) allChanges.push({
		ref,
		refId: decoder.currentRefId,
		op: operation,
		field: field.name,
		value,
		previousValue
	});
};
var decodeKeyValueOperation = function(decoder, bytes, it, ref, allChanges) {
	const operation = bytes[it.offset++];
	if (operation === OPERATION.CLEAR) {
		decoder.removeChildRefs(ref, allChanges);
		ref.clear();
		return;
	}
	const index = decode.number(bytes, it);
	const type = ref[$childType];
	let dynamicIndex;
	if ((operation & OPERATION.ADD) === OPERATION.ADD) {
		if (typeof ref["set"] === "function") {
			dynamicIndex = decode.string(bytes, it);
			ref["setIndex"](index, dynamicIndex);
		} else dynamicIndex = index;
	} else dynamicIndex = ref["getIndex"](index);
	const { value, previousValue } = decodeValue(decoder, operation, ref, index, type, bytes, it, allChanges);
	if (value !== null && value !== void 0) {
		if (typeof ref["set"] === "function") ref["$items"].set(dynamicIndex, value);
		else if (typeof ref["$setAt"] === "function") ref["$setAt"](index, value, operation);
		else if (typeof ref["add"] === "function") {
			const index = ref.add(value);
			if (typeof index === "number") ref["setIndex"](index, index);
		}
	}
	if (previousValue !== value) allChanges.push({
		ref,
		refId: decoder.currentRefId,
		op: operation,
		field: "",
		dynamicIndex,
		value,
		previousValue
	});
};
var decodeArray = function(decoder, bytes, it, ref, allChanges) {
	let operation = bytes[it.offset++];
	let index;
	if (operation === OPERATION.CLEAR) {
		decoder.removeChildRefs(ref, allChanges);
		ref.clear();
		return;
	} else if (operation === OPERATION.REVERSE) {
		ref.reverse();
		return;
	} else if (operation === OPERATION.DELETE_BY_REFID) {
		const refId = decode.number(bytes, it);
		const previousValue = decoder.root.refs.get(refId);
		index = ref.findIndex((value) => value === previousValue);
		ref[$deleteByIndex](index);
		allChanges.push({
			ref,
			refId: decoder.currentRefId,
			op: OPERATION.DELETE,
			field: "",
			dynamicIndex: index,
			value: void 0,
			previousValue
		});
		return;
	} else if (operation === OPERATION.ADD_BY_REFID) {
		const refId = decode.number(bytes, it);
		const itemByRefId = decoder.root.refs.get(refId);
		if (itemByRefId) index = ref.findIndex((value) => value === itemByRefId);
		if (index === -1 || index === void 0) index = ref.length;
	} else index = decode.number(bytes, it);
	const type = ref[$childType];
	let dynamicIndex = index;
	const { value, previousValue } = decodeValue(decoder, operation, ref, index, type, bytes, it, allChanges);
	if (value !== null && value !== void 0 && value !== previousValue) ref["$setAt"](index, value, operation);
	if (previousValue !== value) allChanges.push({
		ref,
		refId: decoder.currentRefId,
		op: operation,
		field: "",
		dynamicIndex,
		value,
		previousValue
	});
};
var EncodeSchemaError = class extends Error {};
function assertType(value, type, klass, field) {
	let typeofTarget;
	let allowNull = false;
	switch (type) {
		case "number":
		case "int8":
		case "uint8":
		case "int16":
		case "uint16":
		case "int32":
		case "uint32":
		case "int64":
		case "uint64":
		case "float32":
		case "float64":
			typeofTarget = "number";
			if (isNaN(value)) console.log(`trying to encode "NaN" in ${klass.constructor.name}#${field}`);
			break;
		case "bigint64":
		case "biguint64":
			typeofTarget = "bigint";
			break;
		case "string":
			typeofTarget = "string";
			allowNull = true;
			break;
		case "boolean": return;
		default: return;
	}
	if (typeof value !== typeofTarget && (!allowNull || allowNull && value !== null)) {
		let foundValue = `'${JSON.stringify(value)}'${value && value.constructor && ` (${value.constructor.name})` || ""}`;
		throw new EncodeSchemaError(`a '${typeofTarget}' was expected, but ${foundValue} was provided in ${klass.constructor.name}#${field}`);
	}
}
function assertInstanceType(value, type, instance, field) {
	if (!(value instanceof type)) throw new EncodeSchemaError(`a '${type.name}' was expected, but '${value && value.constructor.name}' was provided in ${instance.constructor.name}#${field}`);
}
var _a$4;
var _b$4;
var DEFAULT_SORT = (a, b) => {
	const A = a.toString();
	const B = b.toString();
	if (A < B) return -1;
	else if (A > B) return 1;
	else return 0;
};
var ArraySchema = class ArraySchema {
	static {
		this[_a$4] = encodeArray;
	}
	static {
		this[_b$4] = decodeArray;
	}
	/**
	* Determine if a property must be filtered.
	* - If returns false, the property is NOT going to be encoded.
	* - If returns true, the property is going to be encoded.
	*
	* Encoding with "filters" happens in two steps:
	* - First, the encoder iterates over all "not owned" properties and encodes them.
	* - Then, the encoder iterates over all "owned" properties per instance and encodes them.
	*/
	static [(_a$4 = $encoder, _b$4 = $decoder, $filter)](ref, index, view) {
		return !view || typeof ref["~childType"] === "string" || view.isChangeTreeVisible(ref["tmpItems"][index]?.["~changes"]);
	}
	static is(type) {
		return Array.isArray(type) || type["array"] !== void 0;
	}
	static from(iterable) {
		return new ArraySchema(...Array.from(iterable));
	}
	constructor(...items) {
		this.items = [];
		this.tmpItems = [];
		this.deletedIndexes = {};
		this.isMovingItems = false;
		Object.defineProperty(this, $childType, {
			value: void 0,
			enumerable: false,
			writable: true,
			configurable: true
		});
		const proxy = new Proxy(this, {
			get: (obj, prop) => {
				if (typeof prop !== "symbol" && !isNaN(prop)) return this.items[prop];
				else return Reflect.get(obj, prop);
			},
			set: (obj, key, setValue) => {
				if (typeof key !== "symbol" && !isNaN(key)) {
					if (setValue === void 0 || setValue === null) obj.$deleteAt(key);
					else {
						if (setValue["~changes"]) {
							assertInstanceType(setValue, obj[$childType], obj, key);
							const previousValue = obj.items[key];
							if (!obj.isMovingItems) obj.$changeAt(Number(key), setValue);
							else {
								if (previousValue !== void 0) {
									if (setValue["~changes"].isNew) obj[$changes].indexedOperation(Number(key), OPERATION.MOVE_AND_ADD);
									else if ((obj["~changes"].getChange(Number(key)) & OPERATION.DELETE) === OPERATION.DELETE) obj[$changes].indexedOperation(Number(key), OPERATION.DELETE_AND_MOVE);
									else obj[$changes].indexedOperation(Number(key), OPERATION.MOVE);
								} else if (setValue["~changes"].isNew) obj[$changes].indexedOperation(Number(key), OPERATION.ADD);
								setValue[$changes].setParent(this, obj[$changes].root, key);
							}
							if (previousValue !== void 0) previousValue[$changes].root?.remove(previousValue[$changes]);
						} else obj.$changeAt(Number(key), setValue);
						obj.items[key] = setValue;
						obj.tmpItems[key] = setValue;
					}
					return true;
				} else return Reflect.set(obj, key, setValue);
			},
			deleteProperty: (obj, prop) => {
				if (typeof prop === "number") obj.$deleteAt(prop);
				else delete obj[prop];
				return true;
			},
			has: (obj, key) => {
				if (typeof key !== "symbol" && !isNaN(Number(key))) return Reflect.has(this.items, key);
				return Reflect.has(obj, key);
			}
		});
		Object.defineProperty(this, $changes, {
			value: new ChangeTree(proxy),
			enumerable: false,
			writable: true
		});
		if (items.length > 0) this.push(...items);
		return proxy;
	}
	set length(newLength) {
		if (newLength === 0) this.clear();
		else if (newLength < this.items.length) this.splice(newLength, this.length - newLength);
		else console.warn("ArraySchema: can't set .length to a higher value than its length.");
	}
	get length() {
		return this.items.length;
	}
	push(...values) {
		let length = this.tmpItems.length;
		const changeTree = this[$changes];
		for (let i = 0, l = values.length; i < l; i++, length++) {
			const value = values[i];
			if (value === void 0 || value === null) return;
			else if (typeof value === "object" && this["~childType"]) assertInstanceType(value, this[$childType], this, i);
			changeTree.indexedOperation(length, OPERATION.ADD, this.items.length);
			this.items.push(value);
			this.tmpItems.push(value);
			value[$changes]?.setParent(this, changeTree.root, length);
		}
		return length;
	}
	/**
	* Removes the last element from an array and returns it.
	*/
	pop() {
		let index = -1;
		for (let i = this.tmpItems.length - 1; i >= 0; i--) if (this.deletedIndexes[i] !== true) {
			index = i;
			break;
		}
		if (index < 0) return;
		this[$changes].delete(index, void 0, this.items.length - 1);
		this.deletedIndexes[index] = true;
		return this.items.pop();
	}
	at(index) {
		if (index < 0) index += this.length;
		return this.items[index];
	}
	$changeAt(index, value) {
		if (value === void 0 || value === null) {
			console.error("ArraySchema items cannot be null nor undefined; Use `deleteAt(index)` instead.");
			return;
		}
		if (this.items[index] === value) return;
		const operation = this.items[index] !== void 0 ? typeof value === "object" ? OPERATION.DELETE_AND_ADD : OPERATION.REPLACE : OPERATION.ADD;
		const changeTree = this[$changes];
		changeTree.change(index, operation);
		value[$changes]?.setParent(this, changeTree.root, index);
	}
	$deleteAt(index, operation) {
		this[$changes].delete(index, operation);
	}
	$setAt(index, value, operation) {
		if (index === 0 && operation === OPERATION.ADD && this.items[index] !== void 0) this.items.unshift(value);
		else if (operation === OPERATION.DELETE_AND_MOVE) {
			this.items.splice(index, 1);
			this.items[index] = value;
		} else this.items[index] = value;
	}
	clear() {
		if (this.items.length === 0) return;
		const changeTree = this[$changes];
		changeTree.forEachChild((childChangeTree, _) => {
			changeTree.root?.remove(childChangeTree);
		});
		changeTree.discard(true);
		changeTree.operation(OPERATION.CLEAR);
		this.items.length = 0;
		this.tmpItems.length = 0;
	}
	/**
	* Combines two or more arrays.
	* @param items Additional items to add to the end of array1.
	*/
	concat(...items) {
		return new ArraySchema(...this.items.concat(...items));
	}
	/**
	* Adds all the elements of an array separated by the specified separator string.
	* @param separator A string used to separate one element of an array from the next in the resulting String. If omitted, the array elements are separated with a comma.
	*/
	join(separator) {
		return this.items.join(separator);
	}
	/**
	* Reverses the elements in an Array.
	*/
	reverse() {
		this[$changes].operation(OPERATION.REVERSE);
		this.items.reverse();
		this.tmpItems.reverse();
		return this;
	}
	/**
	* Removes the first element from an array and returns it.
	*/
	shift() {
		if (this.items.length === 0) return;
		const changeTree = this[$changes];
		const index = this.tmpItems.findIndex((item) => item === this.items[0]);
		const allChangesIndex = this.items.findIndex((item) => item === this.items[0]);
		changeTree.delete(index, OPERATION.DELETE, allChangesIndex);
		changeTree.shiftAllChangeIndexes(-1, allChangesIndex);
		this.deletedIndexes[index] = true;
		return this.items.shift();
	}
	/**
	* Returns a section of an array.
	* @param start The beginning of the specified portion of the array.
	* @param end The end of the specified portion of the array. This is exclusive of the element at the index 'end'.
	*/
	slice(start, end) {
		const sliced = new ArraySchema();
		sliced.push(...this.items.slice(start, end));
		return sliced;
	}
	/**
	* Sorts an array.
	* @param compareFn Function used to determine the order of the elements. It is expected to return
	* a negative value if first argument is less than second argument, zero if they're equal and a positive
	* value otherwise. If omitted, the elements are sorted in ascending, ASCII character order.
	* ```ts
	* [11,2,22,1].sort((a, b) => a - b)
	* ```
	*/
	sort(compareFn = DEFAULT_SORT) {
		this.isMovingItems = true;
		const changeTree = this[$changes];
		this.items.sort(compareFn).forEach((_, i) => changeTree.change(i, OPERATION.REPLACE));
		this.tmpItems.sort(compareFn);
		this.isMovingItems = false;
		return this;
	}
	/**
	* Removes elements from an array and, if necessary, inserts new elements in their place, returning the deleted elements.
	* @param start The zero-based location in the array from which to start removing elements.
	* @param deleteCount The number of elements to remove.
	* @param insertItems Elements to insert into the array in place of the deleted elements.
	*/
	splice(start, deleteCount, ...insertItems) {
		const changeTree = this[$changes];
		const itemsLength = this.items.length;
		const tmpItemsLength = this.tmpItems.length;
		const insertCount = insertItems.length;
		const indexes = [];
		for (let i = 0; i < tmpItemsLength; i++) if (this.deletedIndexes[i] !== true) indexes.push(i);
		if (itemsLength > start) {
			if (deleteCount === void 0) deleteCount = itemsLength - start;
			for (let i = start; i < start + deleteCount; i++) {
				const index = indexes[i];
				changeTree.delete(index, OPERATION.DELETE);
				this.deletedIndexes[index] = true;
			}
		} else deleteCount = 0;
		if (insertCount > 0) {
			if (insertCount > deleteCount) {
				console.error("Inserting more elements than deleting during ArraySchema#splice()");
				throw new Error("ArraySchema#splice(): insertCount must be equal or lower than deleteCount.");
			}
			for (let i = 0; i < insertCount; i++) {
				const addIndex = (indexes[start] ?? itemsLength) + i;
				changeTree.indexedOperation(addIndex, this.deletedIndexes[addIndex] ? OPERATION.DELETE_AND_ADD : OPERATION.ADD);
				insertItems[i][$changes]?.setParent(this, changeTree.root, addIndex);
			}
		}
		if (deleteCount > insertCount) changeTree.shiftAllChangeIndexes(-(deleteCount - insertCount), indexes[start + insertCount]);
		if (changeTree.filteredChanges !== void 0) changeTree.root?.enqueueChangeTree(changeTree, "filteredChanges");
		else changeTree.root?.enqueueChangeTree(changeTree, "changes");
		return this.items.splice(start, deleteCount, ...insertItems);
	}
	/**
	* Inserts new elements at the start of an array.
	* @param items  Elements to insert at the start of the Array.
	*/
	unshift(...items) {
		const changeTree = this[$changes];
		changeTree.shiftChangeIndexes(items.length);
		if (changeTree.isFiltered) setOperationAtIndex(changeTree.filteredChanges, this.items.length);
		else setOperationAtIndex(changeTree.allChanges, this.items.length);
		items.forEach((_, index) => {
			changeTree.change(index, OPERATION.ADD);
		});
		this.tmpItems.unshift(...items);
		return this.items.unshift(...items);
	}
	/**
	* Returns the index of the first occurrence of a value in an array.
	* @param searchElement The value to locate in the array.
	* @param fromIndex The array index at which to begin the search. If fromIndex is omitted, the search starts at index 0.
	*/
	indexOf(searchElement, fromIndex) {
		return this.items.indexOf(searchElement, fromIndex);
	}
	/**
	* Returns the index of the last occurrence of a specified value in an array.
	* @param searchElement The value to locate in the array.
	* @param fromIndex The array index at which to begin the search. If fromIndex is omitted, the search starts at the last index in the array.
	*/
	lastIndexOf(searchElement, fromIndex = this.length - 1) {
		return this.items.lastIndexOf(searchElement, fromIndex);
	}
	every(callbackfn, thisArg) {
		return this.items.every(callbackfn, thisArg);
	}
	/**
	* Determines whether the specified callback function returns true for any element of an array.
	* @param callbackfn A function that accepts up to three arguments. The some method calls
	* the callbackfn function for each element in the array until the callbackfn returns a value
	* which is coercible to the Boolean value true, or until the end of the array.
	* @param thisArg An object to which the this keyword can refer in the callbackfn function.
	* If thisArg is omitted, undefined is used as the this value.
	*/
	some(callbackfn, thisArg) {
		return this.items.some(callbackfn, thisArg);
	}
	/**
	* Performs the specified action for each element in an array.
	* @param callbackfn  A function that accepts up to three arguments. forEach calls the callbackfn function one time for each element in the array.
	* @param thisArg  An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.
	*/
	forEach(callbackfn, thisArg) {
		return this.items.forEach(callbackfn, thisArg);
	}
	/**
	* Calls a defined callback function on each element of an array, and returns an array that contains the results.
	* @param callbackfn A function that accepts up to three arguments. The map method calls the callbackfn function one time for each element in the array.
	* @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.
	*/
	map(callbackfn, thisArg) {
		return this.items.map(callbackfn, thisArg);
	}
	filter(callbackfn, thisArg) {
		return this.items.filter(callbackfn, thisArg);
	}
	/**
	* Calls the specified callback function for all the elements in an array. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.
	* @param callbackfn A function that accepts up to four arguments. The reduce method calls the callbackfn function one time for each element in the array.
	* @param initialValue If initialValue is specified, it is used as the initial value to start the accumulation. The first call to the callbackfn function provides this value as an argument instead of an array value.
	*/
	reduce(callbackfn, initialValue) {
		return this.items.reduce(callbackfn, initialValue);
	}
	/**
	* Calls the specified callback function for all the elements in an array, in descending order. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.
	* @param callbackfn A function that accepts up to four arguments. The reduceRight method calls the callbackfn function one time for each element in the array.
	* @param initialValue If initialValue is specified, it is used as the initial value to start the accumulation. The first call to the callbackfn function provides this value as an argument instead of an array value.
	*/
	reduceRight(callbackfn, initialValue) {
		return this.items.reduceRight(callbackfn, initialValue);
	}
	/**
	* Returns the value of the first element in the array where predicate is true, and undefined
	* otherwise.
	* @param predicate find calls predicate once for each element of the array, in ascending
	* order, until it finds one where predicate returns true. If such an element is found, find
	* immediately returns that element value. Otherwise, find returns undefined.
	* @param thisArg If provided, it will be used as the this value for each invocation of
	* predicate. If it is not provided, undefined is used instead.
	*/
	find(predicate, thisArg) {
		return this.items.find(predicate, thisArg);
	}
	/**
	* Returns the index of the first element in the array where predicate is true, and -1
	* otherwise.
	* @param predicate find calls predicate once for each element of the array, in ascending
	* order, until it finds one where predicate returns true. If such an element is found,
	* findIndex immediately returns that element index. Otherwise, findIndex returns -1.
	* @param thisArg If provided, it will be used as the this value for each invocation of
	* predicate. If it is not provided, undefined is used instead.
	*/
	findIndex(predicate, thisArg) {
		return this.items.findIndex(predicate, thisArg);
	}
	/**
	* Returns the this object after filling the section identified by start and end with value
	* @param value value to fill array section with
	* @param start index to start filling the array at. If start is negative, it is treated as
	* length+start where length is the length of the array.
	* @param end index to stop filling the array at. If end is negative, it is treated as
	* length+end.
	*/
	fill(value, start, end) {
		throw new Error("ArraySchema#fill() not implemented");
	}
	/**
	* Returns the this object after copying a section of the array identified by start and end
	* to the same array starting at position target
	* @param target If target is negative, it is treated as length+target where length is the
	* length of the array.
	* @param start If start is negative, it is treated as length+start. If end is negative, it
	* is treated as length+end.
	* @param end If not specified, length of the this object is used as its default value.
	*/
	copyWithin(target, start, end) {
		throw new Error("ArraySchema#copyWithin() not implemented");
	}
	/**
	* Returns a string representation of an array.
	*/
	toString() {
		return this.items.toString();
	}
	/**
	* Returns a string representation of an array. The elements are converted to string using their toLocalString methods.
	*/
	toLocaleString() {
		return this.items.toLocaleString();
	}
	/** Iterator */
	[Symbol.iterator]() {
		return this.items[Symbol.iterator]();
	}
	static get [Symbol.species]() {
		return ArraySchema;
	}
	/**
	* Returns an iterable of key, value pairs for every entry in the array
	*/
	entries() {
		return this.items.entries();
	}
	/**
	* Returns an iterable of keys in the array
	*/
	keys() {
		return this.items.keys();
	}
	/**
	* Returns an iterable of values in the array
	*/
	values() {
		return this.items.values();
	}
	/**
	* Determines whether an array includes a certain element, returning true or false as appropriate.
	* @param searchElement The element to search for.
	* @param fromIndex The position in this array at which to begin searching for searchElement.
	*/
	includes(searchElement, fromIndex) {
		return this.items.includes(searchElement, fromIndex);
	}
	/**
	* Calls a defined callback function on each element of an array. Then, flattens the result into
	* a new array.
	* This is identical to a map followed by flat with depth 1.
	*
	* @param callback A function that accepts up to three arguments. The flatMap method calls the
	* callback function one time for each element in the array.
	* @param thisArg An object to which the this keyword can refer in the callback function. If
	* thisArg is omitted, undefined is used as the this value.
	*/
	flatMap(callback, thisArg) {
		throw new Error("ArraySchema#flatMap() is not supported.");
	}
	/**
	* Returns a new array with all sub-array elements concatenated into it recursively up to the
	* specified depth.
	*
	* @param depth The maximum recursion depth
	*/
	flat(depth) {
		throw new Error("ArraySchema#flat() is not supported.");
	}
	findLast() {
		return this.items.findLast.apply(this.items, arguments);
	}
	findLastIndex(...args) {
		return this.items.findLastIndex.apply(this.items, arguments);
	}
	with(index, value) {
		const copy = this.items.slice();
		if (index < 0) index += this.length;
		copy[index] = value;
		return new ArraySchema(...copy);
	}
	toReversed() {
		return this.items.slice().reverse();
	}
	toSorted(compareFn) {
		return this.items.slice().sort(compareFn);
	}
	toSpliced(start, deleteCount, ...items) {
		return this.items.toSpliced.apply(copy, arguments);
	}
	shuffle() {
		return this.move((_) => {
			let currentIndex = this.items.length;
			while (currentIndex != 0) {
				let randomIndex = Math.floor(Math.random() * currentIndex);
				currentIndex--;
				[this[currentIndex], this[randomIndex]] = [this[randomIndex], this[currentIndex]];
			}
		});
	}
	/**
	* Allows to move items around in the array.
	*
	* Example:
	*     state.cards.move((cards) => {
	*         [cards[4], cards[3]] = [cards[3], cards[4]];
	*         [cards[3], cards[2]] = [cards[2], cards[3]];
	*         [cards[2], cards[0]] = [cards[0], cards[2]];
	*         [cards[1], cards[1]] = [cards[1], cards[1]];
	*         [cards[0], cards[0]] = [cards[0], cards[0]];
	*     })
	*
	* @param cb
	* @returns
	*/
	move(cb) {
		this.isMovingItems = true;
		cb(this);
		this.isMovingItems = false;
		return this;
	}
	[$getByIndex](index, isEncodeAll = false) {
		return isEncodeAll ? this.items[index] : this.deletedIndexes[index] ? this.items[index] : this.tmpItems[index] || this.items[index];
	}
	[$deleteByIndex](index) {
		this.items[index] = void 0;
		this.tmpItems[index] = void 0;
	}
	[$onEncodeEnd]() {
		this.tmpItems = this.items.slice();
		this.deletedIndexes = {};
	}
	[$onDecodeEnd]() {
		this.items = this.items.filter((item) => item !== void 0);
		this.tmpItems = this.items.slice();
	}
	toArray() {
		return this.items.slice(0);
	}
	toJSON() {
		return this.toArray().map((value) => {
			return typeof value["toJSON"] === "function" ? value["toJSON"]() : value;
		});
	}
	clone(isDecoding) {
		let cloned;
		if (isDecoding) {
			cloned = new ArraySchema();
			cloned.push(...this.items);
		} else cloned = new ArraySchema(...this.map((item) => item["~changes"] ? item.clone() : item));
		return cloned;
	}
};
registerType("array", { constructor: ArraySchema });
var _a$3;
var _b$3;
var MapSchema = class MapSchema {
	static {
		this[_a$3] = encodeKeyValueOperation;
	}
	static {
		this[_b$3] = decodeKeyValueOperation;
	}
	/**
	* Determine if a property must be filtered.
	* - If returns false, the property is NOT going to be encoded.
	* - If returns true, the property is going to be encoded.
	*
	* Encoding with "filters" happens in two steps:
	* - First, the encoder iterates over all "not owned" properties and encodes them.
	* - Then, the encoder iterates over all "owned" properties per instance and encodes them.
	*/
	static [(_a$3 = $encoder, _b$3 = $decoder, $filter)](ref, index, view) {
		return !view || typeof ref["~childType"] === "string" || view.isChangeTreeVisible((ref["~getByIndex"](index) ?? ref.deletedItems[index])["~changes"]);
	}
	static is(type) {
		return type["map"] !== void 0;
	}
	constructor(initialValues) {
		this.$items = /* @__PURE__ */ new Map();
		this.$indexes = /* @__PURE__ */ new Map();
		this.deletedItems = {};
		const changeTree = new ChangeTree(this);
		changeTree.indexes = {};
		Object.defineProperty(this, $changes, {
			value: changeTree,
			enumerable: false,
			writable: true
		});
		if (initialValues) {
			if (initialValues instanceof Map || initialValues instanceof MapSchema) initialValues.forEach((v, k) => this.set(k, v));
			else for (const k in initialValues) this.set(k, initialValues[k]);
		}
		Object.defineProperty(this, $childType, {
			value: void 0,
			enumerable: false,
			writable: true,
			configurable: true
		});
	}
	/** Iterator */
	[Symbol.iterator]() {
		return this.$items[Symbol.iterator]();
	}
	get [Symbol.toStringTag]() {
		return this.$items[Symbol.toStringTag];
	}
	static get [Symbol.species]() {
		return MapSchema;
	}
	set(key, value) {
		if (value === void 0 || value === null) throw new Error(`MapSchema#set('${key}', ${value}): trying to set ${value} value on '${key}'.`);
		else if (typeof value === "object" && this["~childType"]) assertInstanceType(value, this[$childType], this, key);
		key = key.toString();
		const changeTree = this[$changes];
		const isRef = value[$changes] !== void 0;
		let index;
		let operation;
		if (typeof changeTree.indexes[key] !== "undefined") {
			index = changeTree.indexes[key];
			operation = OPERATION.REPLACE;
			const previousValue = this.$items.get(key);
			if (previousValue === value) return;
			else if (isRef) {
				operation = OPERATION.DELETE_AND_ADD;
				if (previousValue !== void 0) previousValue[$changes].root?.remove(previousValue[$changes]);
			}
			if (this.deletedItems[index]) delete this.deletedItems[index];
		} else {
			index = changeTree.indexes[$numFields] ?? 0;
			operation = OPERATION.ADD;
			this.$indexes.set(index, key);
			changeTree.indexes[key] = index;
			changeTree.indexes[$numFields] = index + 1;
		}
		this.$items.set(key, value);
		changeTree.change(index, operation);
		if (isRef) value[$changes].setParent(this, changeTree.root, index);
		return this;
	}
	get(key) {
		return this.$items.get(key);
	}
	delete(key) {
		if (!this.$items.has(key)) return false;
		const index = this[$changes].indexes[key];
		this.deletedItems[index] = this[$changes].delete(index);
		return this.$items.delete(key);
	}
	clear() {
		const changeTree = this[$changes];
		changeTree.discard(true);
		changeTree.indexes = {};
		changeTree.forEachChild((childChangeTree, _) => {
			changeTree.root?.remove(childChangeTree);
		});
		this.$indexes.clear();
		this.$items.clear();
		changeTree.operation(OPERATION.CLEAR);
	}
	has(key) {
		return this.$items.has(key);
	}
	forEach(callbackfn) {
		this.$items.forEach(callbackfn);
	}
	entries() {
		return this.$items.entries();
	}
	keys() {
		return this.$items.keys();
	}
	values() {
		return this.$items.values();
	}
	get size() {
		return this.$items.size;
	}
	setIndex(index, key) {
		this.$indexes.set(index, key);
	}
	getIndex(index) {
		return this.$indexes.get(index);
	}
	[$getByIndex](index) {
		return this.$items.get(this.$indexes.get(index));
	}
	[$deleteByIndex](index) {
		const key = this.$indexes.get(index);
		this.$items.delete(key);
		this.$indexes.delete(index);
	}
	[$onEncodeEnd]() {
		const changeTree = this[$changes];
		for (const indexStr in this.deletedItems) {
			const index = parseInt(indexStr);
			const key = this.$indexes.get(index);
			delete changeTree.indexes[key];
			this.$indexes.delete(index);
		}
		this.deletedItems = {};
	}
	toJSON() {
		const map = {};
		this.forEach((value, key) => {
			map[key] = typeof value["toJSON"] === "function" ? value["toJSON"]() : value;
		});
		return map;
	}
	clone(isDecoding) {
		let cloned;
		if (isDecoding) cloned = Object.assign(new MapSchema(), this);
		else {
			cloned = new MapSchema();
			this.forEach((value, key) => {
				if (value["~changes"]) cloned.set(key, value["clone"]());
				else cloned.set(key, value);
			});
		}
		return cloned;
	}
};
registerType("map", { constructor: MapSchema });
var _a$2;
var _b$2;
var CollectionSchema = class CollectionSchema {
	static {
		this[_a$2] = encodeKeyValueOperation;
	}
	static {
		this[_b$2] = decodeKeyValueOperation;
	}
	/**
	* Determine if a property must be filtered.
	* - If returns false, the property is NOT going to be encoded.
	* - If returns true, the property is going to be encoded.
	*
	* Encoding with "filters" happens in two steps:
	* - First, the encoder iterates over all "not owned" properties and encodes them.
	* - Then, the encoder iterates over all "owned" properties per instance and encodes them.
	*/
	static [(_a$2 = $encoder, _b$2 = $decoder, $filter)](ref, index, view) {
		return !view || typeof ref["~childType"] === "string" || view.isChangeTreeVisible((ref["~getByIndex"](index) ?? ref.deletedItems[index])["~changes"]);
	}
	static is(type) {
		return type["collection"] !== void 0;
	}
	constructor(initialValues) {
		this.$items = /* @__PURE__ */ new Map();
		this.$indexes = /* @__PURE__ */ new Map();
		this.deletedItems = {};
		this.$refId = 0;
		this[$changes] = new ChangeTree(this);
		this[$changes].indexes = {};
		if (initialValues) initialValues.forEach((v) => this.add(v));
		Object.defineProperty(this, $childType, {
			value: void 0,
			enumerable: false,
			writable: true,
			configurable: true
		});
	}
	add(value) {
		const index = this.$refId++;
		if (value["~changes"] !== void 0) value[$changes].setParent(this, this[$changes].root, index);
		this[$changes].indexes[index] = index;
		this.$indexes.set(index, index);
		this.$items.set(index, value);
		this[$changes].change(index);
		return index;
	}
	at(index) {
		const key = Array.from(this.$items.keys())[index];
		return this.$items.get(key);
	}
	entries() {
		return this.$items.entries();
	}
	delete(item) {
		const entries = this.$items.entries();
		let index;
		let entry;
		while (entry = entries.next()) {
			if (entry.done) break;
			if (item === entry.value[1]) {
				index = entry.value[0];
				break;
			}
		}
		if (index === void 0) return false;
		this.deletedItems[index] = this[$changes].delete(index);
		this.$indexes.delete(index);
		return this.$items.delete(index);
	}
	clear() {
		const changeTree = this[$changes];
		changeTree.discard(true);
		changeTree.indexes = {};
		changeTree.forEachChild((childChangeTree, _) => {
			changeTree.root?.remove(childChangeTree);
		});
		this.$indexes.clear();
		this.$items.clear();
		changeTree.operation(OPERATION.CLEAR);
	}
	has(value) {
		return Array.from(this.$items.values()).some((v) => v === value);
	}
	forEach(callbackfn) {
		this.$items.forEach((value, key, _) => callbackfn(value, key, this));
	}
	values() {
		return this.$items.values();
	}
	get size() {
		return this.$items.size;
	}
	/** Iterator */
	[Symbol.iterator]() {
		return this.$items.values();
	}
	setIndex(index, key) {
		this.$indexes.set(index, key);
	}
	getIndex(index) {
		return this.$indexes.get(index);
	}
	[$getByIndex](index) {
		return this.$items.get(this.$indexes.get(index));
	}
	[$deleteByIndex](index) {
		const key = this.$indexes.get(index);
		this.$items.delete(key);
		this.$indexes.delete(index);
	}
	[$onEncodeEnd]() {
		this.deletedItems = {};
	}
	toArray() {
		return Array.from(this.$items.values());
	}
	toJSON() {
		const values = [];
		this.forEach((value, key) => {
			values.push(typeof value["toJSON"] === "function" ? value["toJSON"]() : value);
		});
		return values;
	}
	clone(isDecoding) {
		let cloned;
		if (isDecoding) cloned = Object.assign(new CollectionSchema(), this);
		else {
			cloned = new CollectionSchema();
			this.forEach((value) => {
				if (value["~changes"]) cloned.add(value["clone"]());
				else cloned.add(value);
			});
		}
		return cloned;
	}
};
registerType("collection", { constructor: CollectionSchema });
var _a$1;
var _b$1;
var SetSchema = class SetSchema {
	static {
		this[_a$1] = encodeKeyValueOperation;
	}
	static {
		this[_b$1] = decodeKeyValueOperation;
	}
	/**
	* Determine if a property must be filtered.
	* - If returns false, the property is NOT going to be encoded.
	* - If returns true, the property is going to be encoded.
	*
	* Encoding with "filters" happens in two steps:
	* - First, the encoder iterates over all "not owned" properties and encodes them.
	* - Then, the encoder iterates over all "owned" properties per instance and encodes them.
	*/
	static [(_a$1 = $encoder, _b$1 = $decoder, $filter)](ref, index, view) {
		return !view || typeof ref["~childType"] === "string" || view.visible.has((ref["~getByIndex"](index) ?? ref.deletedItems[index])["~changes"]);
	}
	static is(type) {
		return type["set"] !== void 0;
	}
	constructor(initialValues) {
		this.$items = /* @__PURE__ */ new Map();
		this.$indexes = /* @__PURE__ */ new Map();
		this.deletedItems = {};
		this.$refId = 0;
		this[$changes] = new ChangeTree(this);
		this[$changes].indexes = {};
		if (initialValues) initialValues.forEach((v) => this.add(v));
		Object.defineProperty(this, $childType, {
			value: void 0,
			enumerable: false,
			writable: true,
			configurable: true
		});
	}
	add(value) {
		if (this.has(value)) return false;
		const index = this.$refId++;
		if (value["~changes"] !== void 0) value[$changes].setParent(this, this[$changes].root, index);
		const operation = this["~changes"].indexes[index]?.op ?? OPERATION.ADD;
		this[$changes].indexes[index] = index;
		this.$indexes.set(index, index);
		this.$items.set(index, value);
		this[$changes].change(index, operation);
		return index;
	}
	entries() {
		return this.$items.entries();
	}
	delete(item) {
		const entries = this.$items.entries();
		let index;
		let entry;
		while (entry = entries.next()) {
			if (entry.done) break;
			if (item === entry.value[1]) {
				index = entry.value[0];
				break;
			}
		}
		if (index === void 0) return false;
		this.deletedItems[index] = this[$changes].delete(index);
		this.$indexes.delete(index);
		return this.$items.delete(index);
	}
	clear() {
		const changeTree = this[$changes];
		changeTree.discard(true);
		changeTree.indexes = {};
		this.$indexes.clear();
		this.$items.clear();
		changeTree.operation(OPERATION.CLEAR);
	}
	has(value) {
		const values = this.$items.values();
		let has = false;
		let entry;
		while (entry = values.next()) {
			if (entry.done) break;
			if (value === entry.value) {
				has = true;
				break;
			}
		}
		return has;
	}
	forEach(callbackfn) {
		this.$items.forEach((value, key, _) => callbackfn(value, key, this));
	}
	values() {
		return this.$items.values();
	}
	get size() {
		return this.$items.size;
	}
	/** Iterator */
	[Symbol.iterator]() {
		return this.$items.values();
	}
	setIndex(index, key) {
		this.$indexes.set(index, key);
	}
	getIndex(index) {
		return this.$indexes.get(index);
	}
	[$getByIndex](index) {
		return this.$items.get(this.$indexes.get(index));
	}
	[$deleteByIndex](index) {
		const key = this.$indexes.get(index);
		this.$items.delete(key);
		this.$indexes.delete(index);
	}
	[$onEncodeEnd]() {
		this.deletedItems = {};
	}
	toArray() {
		return Array.from(this.$items.values());
	}
	toJSON() {
		const values = [];
		this.forEach((value, key) => {
			values.push(typeof value["toJSON"] === "function" ? value["toJSON"]() : value);
		});
		return values;
	}
	clone(isDecoding) {
		let cloned;
		if (isDecoding) cloned = Object.assign(new SetSchema(), this);
		else {
			cloned = new SetSchema();
			this.forEach((value) => {
				if (value["~changes"]) cloned.add(value["clone"]());
				else cloned.add(value);
			});
		}
		return cloned;
	}
};
registerType("set", { constructor: SetSchema });
var DEFAULT_VIEW_TAG = -1;
function type(type, options) {
	return function(target, field) {
		const constructor = target.constructor;
		if (!type) throw new Error(`${constructor.name}: @type() reference provided for "${field}" is undefined. Make sure you don't have any circular dependencies.`);
		type = getNormalizedType(type);
		TypeContext.register(constructor);
		const parentMetadata = Object.getPrototypeOf(constructor)[Symbol.metadata];
		const metadata = Metadata.initialize(constructor);
		let fieldIndex = metadata[field];
		/**
		* skip if descriptor already exists for this field (`@deprecated()`)
		*/
		if (metadata[fieldIndex] !== void 0) {
			if (metadata[fieldIndex].deprecated) return;
			else if (metadata[fieldIndex].type !== void 0) try {
				throw new Error(`@colyseus/schema: Duplicate '${field}' definition on '${constructor.name}'.\nCheck @type() annotation`);
			} catch (e) {
				const definitionAtLine = e.stack.split("\n")[4].trim();
				throw new Error(`${e.message} ${definitionAtLine}`);
			}
		} else {
			fieldIndex = metadata[$numFields] ?? (parentMetadata && parentMetadata[$numFields]) ?? -1;
			fieldIndex++;
		}
		if (options && options.manual) Metadata.addField(metadata, fieldIndex, field, type, {
			enumerable: true,
			configurable: true,
			writable: true
		});
		else {
			const complexTypeKlass = typeof Object.keys(type)[0] === "string" && getType(Object.keys(type)[0]);
			const childType = complexTypeKlass ? Object.values(type)[0] : type;
			Metadata.addField(metadata, fieldIndex, field, type, getPropertyDescriptor(`_${field}`, fieldIndex, childType, complexTypeKlass));
		}
	};
}
function getPropertyDescriptor(fieldCached, fieldIndex, type, complexTypeKlass) {
	return {
		get: function() {
			return this[fieldCached];
		},
		set: function(value) {
			const previousValue = this[fieldCached] ?? void 0;
			if (value === previousValue) return;
			if (value !== void 0 && value !== null) {
				if (complexTypeKlass) {
					if (complexTypeKlass.constructor === ArraySchema && !(value instanceof ArraySchema)) value = new ArraySchema(...value);
					if (complexTypeKlass.constructor === MapSchema && !(value instanceof MapSchema)) value = new MapSchema(value);
					value[$childType] = type;
				} else if (typeof type !== "string") assertInstanceType(value, type, this, fieldCached.substring(1));
				else assertType(value, type, this, fieldCached.substring(1));
				const changeTree = this[$changes];
				if (previousValue !== void 0 && previousValue["~changes"]) {
					changeTree.root?.remove(previousValue[$changes]);
					this.constructor[$track](changeTree, fieldIndex, OPERATION.DELETE_AND_ADD);
				} else this.constructor[$track](changeTree, fieldIndex, OPERATION.ADD);
				value[$changes]?.setParent(this, changeTree.root, fieldIndex);
			} else if (previousValue !== void 0) this[$changes].delete(fieldIndex);
			this[fieldCached] = value;
		},
		enumerable: true,
		configurable: true
	};
}
function getIndent(level) {
	return new Array(level).fill(0).map((_, i) => i === level - 1 ? `└─ ` : `   `).join("");
}
var _a;
var _b;
/**
* Schema encoder / decoder
*/
var Schema = class Schema {
	static {
		this[_a] = encodeSchemaOperation;
	}
	static {
		this[_b] = decodeSchemaOperation;
	}
	/**
	* Assign the property descriptors required to track changes on this instance.
	* @param instance
	*/
	static initialize(instance) {
		Object.defineProperty(instance, $changes, {
			value: new ChangeTree(instance),
			enumerable: false,
			writable: true
		});
		Object.defineProperties(instance, instance.constructor[Symbol.metadata]?.[$descriptors] || {});
	}
	static is(type) {
		return typeof type[Symbol.metadata] === "object";
	}
	/**
	* Track property changes
	*/
	static [(_a = $encoder, _b = $decoder, $track)](changeTree, index, operation = OPERATION.ADD) {
		changeTree.change(index, operation);
	}
	/**
	* Determine if a property must be filtered.
	* - If returns false, the property is NOT going to be encoded.
	* - If returns true, the property is going to be encoded.
	*
	* Encoding with "filters" happens in two steps:
	* - First, the encoder iterates over all "not owned" properties and encodes them.
	* - Then, the encoder iterates over all "owned" properties per instance and encodes them.
	*/
	static [$filter](ref, index, view) {
		const tag = ref.constructor[Symbol.metadata][index]?.tag;
		if (view === void 0) return tag === void 0;
		else if (tag === void 0) return true;
		else if (tag === DEFAULT_VIEW_TAG) return view.isChangeTreeVisible(ref[$changes]);
		else {
			const tags = view.tags?.get(ref[$changes]);
			return tags && tags.has(tag);
		}
	}
	constructor(arg) {
		Schema.initialize(this);
		if (arg) Object.assign(this, arg);
	}
	assign(props) {
		Object.assign(this, props);
		return this;
	}
	/**
	* (Server-side): Flag a property to be encoded for the next patch.
	* @param instance Schema instance
	* @param property string representing the property name, or number representing the index of the property.
	* @param operation OPERATION to perform (detected automatically)
	*/
	setDirty(property, operation) {
		const metadata = this.constructor[Symbol.metadata];
		this[$changes].change(metadata[metadata[property]].index, operation);
	}
	clone() {
		const cloned = Object.create(this.constructor.prototype);
		Schema.initialize(cloned);
		const metadata = this.constructor[Symbol.metadata];
		for (const fieldIndex in metadata) {
			const field = metadata[fieldIndex].name;
			if (typeof this[field] === "object" && typeof this[field]?.clone === "function") cloned[field] = this[field].clone();
			else cloned[field] = this[field];
		}
		return cloned;
	}
	toJSON() {
		const obj = {};
		const metadata = this.constructor[Symbol.metadata];
		for (const index in metadata) {
			const field = metadata[index];
			const fieldName = field.name;
			if (!field.deprecated && this[fieldName] !== null && typeof this[fieldName] !== "undefined") obj[fieldName] = typeof this[fieldName]["toJSON"] === "function" ? this[fieldName]["toJSON"]() : this[fieldName];
		}
		return obj;
	}
	/**
	* Used in tests only
	* @internal
	*/
	discardAllChanges() {
		this[$changes].discardAll();
	}
	[$getByIndex](index) {
		const metadata = this.constructor[Symbol.metadata];
		return this[metadata[index].name];
	}
	[$deleteByIndex](index) {
		const metadata = this.constructor[Symbol.metadata];
		this[metadata[index].name] = void 0;
	}
	/**
	* Inspect the `refId` of all Schema instances in the tree. Optionally display the contents of the instance.
	*
	* @param ref Schema instance
	* @param showContents display JSON contents of the instance
	* @returns
	*/
	static debugRefIds(ref, showContents = false, level = 0, decoder, keyPrefix = "") {
		const contents = showContents ? ` - ${JSON.stringify(ref.toJSON())}` : "";
		const changeTree = ref[$changes];
		const refId = decoder ? decoder.root.refIds.get(ref) : changeTree.refId;
		const root = decoder ? decoder.root : changeTree.root;
		const refCount = root?.refCount?.[refId] > 1 ? ` [×${root.refCount[refId]}]` : "";
		let output = `${getIndent(level)}${keyPrefix}${ref.constructor.name} (refId: ${refId})${refCount}${contents}\n`;
		changeTree.forEachChild((childChangeTree, indexOrKey) => {
			let key = indexOrKey;
			if (typeof indexOrKey === "number" && ref["$indexes"]) key = ref["$indexes"].get(indexOrKey) ?? indexOrKey;
			const keyPrefix = ref["forEach"] !== void 0 && key !== void 0 ? `["${key}"]: ` : "";
			output += this.debugRefIds(childChangeTree.ref, showContents, level + 1, decoder, keyPrefix);
		});
		return output;
	}
	static debugRefIdEncodingOrder(ref, changeSet = "allChanges") {
		let encodeOrder = [];
		let current = ref[$changes].root[changeSet].next;
		while (current) {
			if (current.changeTree) encodeOrder.push(current.changeTree.refId);
			current = current.next;
		}
		return encodeOrder;
	}
	static debugRefIdsFromDecoder(decoder) {
		return this.debugRefIds(decoder.state, false, 0, decoder);
	}
	/**
	* Return a string representation of the changes on a Schema instance.
	* The list of changes is cleared after each encode.
	*
	* @param instance Schema instance
	* @param isEncodeAll Return "full encode" instead of current change set.
	* @returns
	*/
	static debugChanges(instance, isEncodeAll = false) {
		const changeTree = instance[$changes];
		const changeSet = isEncodeAll ? changeTree.allChanges : changeTree.changes;
		const changeSetName = isEncodeAll ? "allChanges" : "changes";
		let output = `${instance.constructor.name} (${changeTree.refId}) -> .${changeSetName}:\n`;
		function dumpChangeSet(changeSet) {
			changeSet.operations.filter((op) => op).forEach((index) => {
				const operation = changeTree.indexedOperations[index];
				output += `- [${index}]: ${OPERATION[operation]} (${JSON.stringify(changeTree.getValue(Number(index), isEncodeAll))})\n`;
			});
		}
		dumpChangeSet(changeSet);
		if (!isEncodeAll && changeTree.filteredChanges && changeTree.filteredChanges.operations.filter((op) => op).length > 0) {
			output += `${instance.constructor.name} (${changeTree.refId}) -> .filteredChanges:\n`;
			dumpChangeSet(changeTree.filteredChanges);
		}
		if (isEncodeAll && changeTree.allFilteredChanges && changeTree.allFilteredChanges.operations.filter((op) => op).length > 0) {
			output += `${instance.constructor.name} (${changeTree.refId}) -> .allFilteredChanges:\n`;
			dumpChangeSet(changeTree.allFilteredChanges);
		}
		return output;
	}
	static debugChangesDeep(ref, changeSetName = "changes") {
		let output = "";
		const rootChangeTree = ref[$changes];
		const root = rootChangeTree.root;
		const changeTrees = /* @__PURE__ */ new Map();
		const instanceRefIds = [];
		let totalOperations = 0;
		for (const [refId, changes] of Object.entries(root[changeSetName])) {
			const changeTree = root.changeTrees[refId];
			if (!changeTree) continue;
			let includeChangeTree = false;
			let parentChangeTrees = [];
			let parentChangeTree = changeTree.parent?.[$changes];
			if (changeTree === rootChangeTree) includeChangeTree = true;
			else while (parentChangeTree !== void 0) {
				parentChangeTrees.push(parentChangeTree);
				if (parentChangeTree.ref === ref) {
					includeChangeTree = true;
					break;
				}
				parentChangeTree = parentChangeTree.parent?.[$changes];
			}
			if (includeChangeTree) {
				instanceRefIds.push(changeTree.refId);
				totalOperations += Object.keys(changes).length;
				changeTrees.set(changeTree, parentChangeTrees.reverse());
			}
		}
		output += "---\n";
		output += `root refId: ${rootChangeTree.refId}\n`;
		output += `Total instances: ${instanceRefIds.length} (refIds: ${instanceRefIds.join(", ")})\n`;
		output += `Total changes: ${totalOperations}\n`;
		output += "---\n";
		const visitedParents = /* @__PURE__ */ new WeakSet();
		for (const [changeTree, parentChangeTrees] of changeTrees.entries()) {
			parentChangeTrees.forEach((parentChangeTree, level) => {
				if (!visitedParents.has(parentChangeTree)) {
					output += `${getIndent(level)}${parentChangeTree.ref.constructor.name} (refId: ${parentChangeTree.refId})\n`;
					visitedParents.add(parentChangeTree);
				}
			});
			const changes = changeTree.indexedOperations;
			const level = parentChangeTrees.length;
			const indent = getIndent(level);
			const parentIndex = level > 0 ? `(${changeTree.parentIndex}) ` : "";
			output += `${indent}${parentIndex}${changeTree.ref.constructor.name} (refId: ${changeTree.refId}) - changes: ${Object.keys(changes).length}\n`;
			for (const index in changes) {
				const operation = changes[index];
				output += `${getIndent(level + 1)}${OPERATION[operation]}: ${index}\n`;
			}
		}
		return `${output}`;
	}
};
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
function __decorate(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
}
var Root = class {
	constructor(types) {
		this.types = types;
		this.nextUniqueId = 0;
		this.refCount = {};
		this.changeTrees = {};
		this.allChanges = createChangeTreeList();
		this.allFilteredChanges = createChangeTreeList();
		this.changes = createChangeTreeList();
		this.filteredChanges = createChangeTreeList();
	}
	getNextUniqueId() {
		return this.nextUniqueId++;
	}
	add(changeTree) {
		if (changeTree.refId === void 0) changeTree.refId = this.getNextUniqueId();
		const isNewChangeTree = this.changeTrees[changeTree.refId] === void 0;
		if (isNewChangeTree) this.changeTrees[changeTree.refId] = changeTree;
		const previousRefCount = this.refCount[changeTree.refId];
		if (previousRefCount === 0) {
			const ops = changeTree.allChanges.operations;
			let len = ops.length;
			while (len--) {
				changeTree.indexedOperations[ops[len]] = OPERATION.ADD;
				setOperationAtIndex(changeTree.changes, len);
			}
		}
		this.refCount[changeTree.refId] = (previousRefCount || 0) + 1;
		return isNewChangeTree;
	}
	remove(changeTree) {
		const refCount = this.refCount[changeTree.refId] - 1;
		if (refCount <= 0) {
			changeTree.root = void 0;
			delete this.changeTrees[changeTree.refId];
			this.removeChangeFromChangeSet("allChanges", changeTree);
			this.removeChangeFromChangeSet("changes", changeTree);
			if (changeTree.filteredChanges) {
				this.removeChangeFromChangeSet("allFilteredChanges", changeTree);
				this.removeChangeFromChangeSet("filteredChanges", changeTree);
			}
			this.refCount[changeTree.refId] = 0;
			changeTree.forEachChild((child, _) => {
				if (child.removeParent(changeTree.ref)) {
					if (child.parentChain === void 0 || child.parentChain && this.refCount[child.refId] > 0) this.remove(child);
					else if (child.parentChain) this.moveNextToParent(child);
				}
			});
		} else {
			this.refCount[changeTree.refId] = refCount;
			this.recursivelyMoveNextToParent(changeTree);
		}
		return refCount;
	}
	recursivelyMoveNextToParent(changeTree) {
		this.moveNextToParent(changeTree);
		changeTree.forEachChild((child, _) => this.recursivelyMoveNextToParent(child));
	}
	moveNextToParent(changeTree) {
		if (changeTree.filteredChanges) {
			this.moveNextToParentInChangeTreeList("filteredChanges", changeTree);
			this.moveNextToParentInChangeTreeList("allFilteredChanges", changeTree);
		} else {
			this.moveNextToParentInChangeTreeList("changes", changeTree);
			this.moveNextToParentInChangeTreeList("allChanges", changeTree);
		}
	}
	moveNextToParentInChangeTreeList(changeSetName, changeTree) {
		const changeSet = this[changeSetName];
		const node = changeTree[changeSetName].queueRootNode;
		if (!node) return;
		const parent = changeTree.parent;
		if (!parent || !parent["~changes"]) return;
		const parentNode = parent[$changes][changeSetName]?.queueRootNode;
		if (!parentNode || parentNode === node) return;
		const parentPosition = parentNode.position;
		if (node.position > parentPosition) return;
		if (node.prev) node.prev.next = node.next;
		else changeSet.next = node.next;
		if (node.next) node.next.prev = node.prev;
		else changeSet.tail = node.prev;
		node.prev = parentNode;
		node.next = parentNode.next;
		if (parentNode.next) parentNode.next.prev = node;
		else changeSet.tail = node;
		parentNode.next = node;
		this.updatePositionsAfterMove(changeSet, node, parentPosition + 1);
	}
	enqueueChangeTree(changeTree, changeSet, queueRootNode = changeTree[changeSet].queueRootNode) {
		if (queueRootNode) return;
		changeTree[changeSet].queueRootNode = this.addToChangeTreeList(this[changeSet], changeTree);
	}
	addToChangeTreeList(list, changeTree) {
		const node = {
			changeTree,
			next: void 0,
			prev: void 0,
			position: list.tail ? list.tail.position + 1 : 0
		};
		if (!list.next) {
			list.next = node;
			list.tail = node;
		} else {
			node.prev = list.tail;
			list.tail.next = node;
			list.tail = node;
		}
		return node;
	}
	updatePositionsAfterRemoval(list, removedPosition) {
		let current = list.next;
		let position = 0;
		while (current) {
			if (position >= removedPosition) current.position = position;
			current = current.next;
			position++;
		}
	}
	updatePositionsAfterMove(list, node, newPosition) {
		let current = list.next;
		let position = 0;
		while (current) {
			current.position = position;
			current = current.next;
			position++;
		}
	}
	removeChangeFromChangeSet(changeSetName, changeTree) {
		const changeSet = this[changeSetName];
		const node = changeTree[changeSetName].queueRootNode;
		if (node && node.changeTree === changeTree) {
			const removedPosition = node.position;
			if (node.prev) node.prev.next = node.next;
			else changeSet.next = node.next;
			if (node.next) node.next.prev = node.prev;
			else changeSet.tail = node.prev;
			this.updatePositionsAfterRemoval(changeSet, removedPosition);
			changeTree[changeSetName].queueRootNode = void 0;
			return true;
		}
		return false;
	}
};
var Encoder = class Encoder {
	static {
		this.BUFFER_SIZE = typeof Buffer !== "undefined" && Buffer.poolSize || 8192;
	}
	constructor(state) {
		this.sharedBuffer = Buffer.allocUnsafe(Encoder.BUFFER_SIZE);
		this.context = TypeContext.cache(state.constructor);
		this.root = new Root(this.context);
		this.setState(state);
	}
	setState(state) {
		this.state = state;
		this.state[$changes].setRoot(this.root);
	}
	encode(it = { offset: 0 }, view, buffer = this.sharedBuffer, changeSetName = "changes", isEncodeAll = changeSetName === "allChanges", initialOffset = it.offset) {
		const hasView = view !== void 0;
		const rootChangeTree = this.state[$changes];
		let current = this.root[changeSetName];
		while (current = current.next) {
			const changeTree = current.changeTree;
			if (hasView) {
				if (!view.isChangeTreeVisible(changeTree)) {
					view.invisible.add(changeTree);
					continue;
				}
				view.invisible.delete(changeTree);
			}
			const changeSet = changeTree[changeSetName];
			const ref = changeTree.ref;
			const numChanges = changeSet.operations.length;
			if (numChanges === 0) continue;
			const ctor = ref.constructor;
			const encoder = ctor[$encoder];
			const filter = ctor[$filter];
			const metadata = ctor[Symbol.metadata];
			if (hasView || it.offset > initialOffset || changeTree !== rootChangeTree) {
				buffer[it.offset++] = 255;
				encode.number(buffer, changeTree.refId, it);
			}
			for (let j = 0; j < numChanges; j++) {
				const fieldIndex = changeSet.operations[j];
				if (fieldIndex < 0) {
					buffer[it.offset++] = Math.abs(fieldIndex) & 255;
					continue;
				}
				const operation = isEncodeAll ? OPERATION.ADD : changeTree.indexedOperations[fieldIndex];
				if (fieldIndex === void 0 || operation === void 0 || filter && !filter(ref, fieldIndex, view)) continue;
				encoder(this, buffer, changeTree, fieldIndex, operation, it, isEncodeAll, hasView, metadata);
			}
		}
		if (it.offset > buffer.byteLength) {
			const newSize = Math.ceil(it.offset / (Buffer.poolSize ?? 8192)) * (Buffer.poolSize ?? 8192);
			console.warn(`@colyseus/schema buffer overflow. Encoded state is higher than default BUFFER_SIZE. Use the following to increase default BUFFER_SIZE:

    import { Encoder } from "@colyseus/schema";
    Encoder.BUFFER_SIZE = ${Math.round(newSize / 1024)} * 1024; // ${Math.round(newSize / 1024)} KB
`);
			buffer = Buffer.alloc(newSize, buffer);
			if (buffer === this.sharedBuffer) this.sharedBuffer = buffer;
			return this.encode({ offset: initialOffset }, view, buffer, changeSetName, isEncodeAll);
		} else return buffer.subarray(0, it.offset);
	}
	encodeAll(it = { offset: 0 }, buffer = this.sharedBuffer) {
		return this.encode(it, void 0, buffer, "allChanges", true);
	}
	encodeAllView(view, sharedOffset, it, bytes = this.sharedBuffer) {
		const viewOffset = it.offset;
		this.encode(it, view, bytes, "allFilteredChanges", true, viewOffset);
		return Buffer.concat([bytes.subarray(0, sharedOffset), bytes.subarray(viewOffset, it.offset)]);
	}
	encodeView(view, sharedOffset, it, bytes = this.sharedBuffer) {
		const viewOffset = it.offset;
		for (const [refId, changes] of view.changes) {
			const changeTree = this.root.changeTrees[refId];
			if (changeTree === void 0) {
				view.changes.delete(refId);
				continue;
			}
			const keys = Object.keys(changes);
			if (keys.length === 0) continue;
			const ctor = changeTree.ref.constructor;
			const encoder = ctor[$encoder];
			const metadata = ctor[Symbol.metadata];
			bytes[it.offset++] = 255;
			encode.number(bytes, changeTree.refId, it);
			for (let i = 0, numChanges = keys.length; i < numChanges; i++) {
				const index = Number(keys[i]);
				const operation = changeTree.ref["~getByIndex"](index) !== void 0 && changes[index] || OPERATION.DELETE;
				encoder(this, bytes, changeTree, index, operation, it, false, true, metadata);
			}
		}
		view.changes.clear();
		this.encode(it, view, bytes, "filteredChanges", false, viewOffset);
		return Buffer.concat([bytes.subarray(0, sharedOffset), bytes.subarray(viewOffset, it.offset)]);
	}
	discardChanges() {
		let current = this.root.changes.next;
		while (current) {
			current.changeTree.endEncode("changes");
			current = current.next;
		}
		this.root.changes = createChangeTreeList();
		current = this.root.filteredChanges.next;
		while (current) {
			current.changeTree.endEncode("filteredChanges");
			current = current.next;
		}
		this.root.filteredChanges = createChangeTreeList();
	}
	tryEncodeTypeId(bytes, baseType, targetType, it) {
		const baseTypeId = this.context.getTypeId(baseType);
		const targetTypeId = this.context.getTypeId(targetType);
		if (targetTypeId === void 0) {
			console.warn(`@colyseus/schema WARNING: Class "${targetType.name}" is not registered on TypeRegistry - Please either tag the class with @entity or define a @type() field.`);
			return;
		}
		if (baseTypeId !== targetTypeId) {
			bytes[it.offset++] = 213;
			encode.number(bytes, targetTypeId, it);
		}
	}
	get hasChanges() {
		return this.root.changes.next !== void 0 || this.root.filteredChanges.next !== void 0;
	}
};
function spliceOne(arr, index) {
	if (index === -1 || index >= arr.length) return false;
	const len = arr.length - 1;
	for (let i = index; i < len; i++) arr[i] = arr[i + 1];
	arr.length = len;
	return true;
}
var DecodingWarning = class extends Error {
	constructor(message) {
		super(message);
		this.name = "DecodingWarning";
	}
};
var ReferenceTracker = class {
	constructor() {
		this.refs = /* @__PURE__ */ new Map();
		this.refIds = /* @__PURE__ */ new WeakMap();
		this.refCount = {};
		this.deletedRefs = /* @__PURE__ */ new Set();
		this.callbacks = {};
		this.nextUniqueId = 0;
	}
	getNextUniqueId() {
		return this.nextUniqueId++;
	}
	addRef(refId, ref, incrementCount = true) {
		this.refs.set(refId, ref);
		this.refIds.set(ref, refId);
		if (incrementCount) this.refCount[refId] = (this.refCount[refId] || 0) + 1;
		if (this.deletedRefs.has(refId)) this.deletedRefs.delete(refId);
	}
	removeRef(refId) {
		const refCount = this.refCount[refId];
		if (refCount === void 0) {
			try {
				throw new DecodingWarning("trying to remove refId that doesn't exist: " + refId);
			} catch (e) {
				console.warn(e);
			}
			return;
		}
		if (refCount === 0) {
			try {
				const ref = this.refs.get(refId);
				throw new DecodingWarning(`trying to remove refId '${refId}' with 0 refCount (${ref.constructor.name}: ${JSON.stringify(ref)})`);
			} catch (e) {
				console.warn(e);
			}
			return;
		}
		if ((this.refCount[refId] = refCount - 1) <= 0) this.deletedRefs.add(refId);
	}
	clearRefs() {
		this.refs.clear();
		this.deletedRefs.clear();
		this.callbacks = {};
		this.refCount = {};
	}
	garbageCollectDeletedRefs() {
		this.deletedRefs.forEach((refId) => {
			if (this.refCount[refId] > 0) return;
			const ref = this.refs.get(refId);
			if (ref.constructor[Symbol.metadata] !== void 0) {
				const metadata = ref.constructor[Symbol.metadata];
				for (const index in metadata) {
					const field = metadata[index].name;
					const childRefId = typeof ref[field] === "object" && this.refIds.get(ref[field]);
					if (childRefId && !this.deletedRefs.has(childRefId)) this.removeRef(childRefId);
				}
			} else if (typeof ref["~childType"] === "function") Array.from(ref.values()).forEach((child) => {
				const childRefId = this.refIds.get(child);
				if (!this.deletedRefs.has(childRefId)) this.removeRef(childRefId);
			});
			this.refs.delete(refId);
			delete this.refCount[refId];
			delete this.callbacks[refId];
		});
		this.deletedRefs.clear();
	}
	addCallback(refId, fieldOrOperation, callback) {
		if (refId === void 0) {
			const name = typeof fieldOrOperation === "number" ? OPERATION[fieldOrOperation] : fieldOrOperation;
			throw new Error(`Can't addCallback on '${name}' (refId is undefined)`);
		}
		if (!this.callbacks[refId]) this.callbacks[refId] = {};
		if (!this.callbacks[refId][fieldOrOperation]) this.callbacks[refId][fieldOrOperation] = [];
		this.callbacks[refId][fieldOrOperation].push(callback);
		return () => this.removeCallback(refId, fieldOrOperation, callback);
	}
	removeCallback(refId, field, callback) {
		const index = this.callbacks?.[refId]?.[field]?.indexOf(callback);
		if (index !== void 0 && index !== -1) spliceOne(this.callbacks[refId][field], index);
	}
};
var Decoder = class {
	constructor(root, context) {
		this.currentRefId = 0;
		this.setState(root);
		this.context = context || new TypeContext(root.constructor);
	}
	setState(root) {
		this.state = root;
		this.root = new ReferenceTracker();
		this.root.addRef(0, root);
	}
	decode(bytes, it = { offset: 0 }, ref = this.state) {
		const allChanges = [];
		const $root = this.root;
		const totalBytes = bytes.byteLength;
		let decoder = ref["constructor"][$decoder];
		this.currentRefId = 0;
		while (it.offset < totalBytes) {
			if (bytes[it.offset] == SWITCH_TO_STRUCTURE) {
				it.offset++;
				ref[$onDecodeEnd]?.();
				const nextRefId = decode.number(bytes, it);
				const nextRef = $root.refs.get(nextRefId);
				if (!nextRef) {
					console.error(`"refId" not found: ${nextRefId}`, {
						previousRef: ref,
						previousRefId: this.currentRefId
					});
					console.warn("Please report this issue to the developers.");
					this.skipCurrentStructure(bytes, it, totalBytes);
				} else {
					ref = nextRef;
					decoder = ref.constructor[$decoder];
					this.currentRefId = nextRefId;
				}
				continue;
			}
			if (decoder(this, bytes, it, ref, allChanges) === DEFINITION_MISMATCH) {
				console.warn("@colyseus/schema: definition mismatch");
				this.skipCurrentStructure(bytes, it, totalBytes);
				continue;
			}
		}
		ref[$onDecodeEnd]?.();
		this.triggerChanges?.(allChanges);
		$root.garbageCollectDeletedRefs();
		return allChanges;
	}
	skipCurrentStructure(bytes, it, totalBytes) {
		const nextIterator = { offset: it.offset };
		while (it.offset < totalBytes) {
			if (bytes[it.offset] === SWITCH_TO_STRUCTURE) {
				nextIterator.offset = it.offset + 1;
				if (this.root.refs.has(decode.number(bytes, nextIterator))) break;
			}
			it.offset++;
		}
	}
	getInstanceType(bytes, it, defaultType) {
		let type;
		if (bytes[it.offset] === TYPE_ID) {
			it.offset++;
			const type_id = decode.number(bytes, it);
			type = this.context.get(type_id);
		}
		return type || defaultType;
	}
	createInstanceOfType(type) {
		return new type();
	}
	removeChildRefs(ref, allChanges) {
		const needRemoveRef = typeof ref[$childType] !== "string";
		const refId = this.root.refIds.get(ref);
		ref.forEach((value, key) => {
			allChanges.push({
				ref,
				refId,
				op: OPERATION.DELETE,
				field: key,
				value: void 0,
				previousValue: value
			});
			if (needRemoveRef) this.root.removeRef(this.root.refIds.get(value));
		});
	}
};
/**
* Reflection
*/
var ReflectionField = class extends Schema {};
__decorate([type("string")], ReflectionField.prototype, "name", void 0);
__decorate([type("string")], ReflectionField.prototype, "type", void 0);
__decorate([type("number")], ReflectionField.prototype, "referencedType", void 0);
var ReflectionType = class extends Schema {
	constructor() {
		super(...arguments);
		this.fields = new ArraySchema();
	}
};
__decorate([type("number")], ReflectionType.prototype, "id", void 0);
__decorate([type("number")], ReflectionType.prototype, "extendsId", void 0);
__decorate([type([ReflectionField])], ReflectionType.prototype, "fields", void 0);
var Reflection = class Reflection extends Schema {
	constructor() {
		super(...arguments);
		this.types = new ArraySchema();
	}
	/**
	* Encodes the TypeContext of an Encoder into a buffer.
	*
	* @param encoder Encoder instance
	* @param it
	* @returns
	*/
	static encode(encoder, it = { offset: 0 }) {
		const context = encoder.context;
		const reflection = new Reflection();
		const reflectionEncoder = new Encoder(reflection);
		const rootType = context.schemas.get(encoder.state.constructor);
		if (rootType > 0) reflection.rootType = rootType;
		const includedTypeIds = /* @__PURE__ */ new Set();
		const pendingReflectionTypes = {};
		const addType = (type) => {
			if (type.extendsId === void 0 || includedTypeIds.has(type.extendsId)) {
				includedTypeIds.add(type.id);
				reflection.types.push(type);
				const deps = pendingReflectionTypes[type.id];
				if (deps !== void 0) {
					delete pendingReflectionTypes[type.id];
					deps.forEach((childType) => addType(childType));
				}
			} else {
				if (pendingReflectionTypes[type.extendsId] === void 0) pendingReflectionTypes[type.extendsId] = [];
				pendingReflectionTypes[type.extendsId].push(type);
			}
		};
		context.schemas.forEach((typeid, klass) => {
			const type = new ReflectionType();
			type.id = Number(typeid);
			const inheritFrom = Object.getPrototypeOf(klass);
			if (inheritFrom !== Schema) type.extendsId = context.schemas.get(inheritFrom);
			const metadata = klass[Symbol.metadata];
			if (metadata !== inheritFrom[Symbol.metadata]) for (const fieldIndex in metadata) {
				const index = Number(fieldIndex);
				const fieldName = metadata[index].name;
				if (!Object.prototype.hasOwnProperty.call(metadata, fieldName)) continue;
				const reflectionField = new ReflectionField();
				reflectionField.name = fieldName;
				let fieldType;
				const field = metadata[index];
				if (typeof field.type === "string") fieldType = field.type;
				else {
					let childTypeSchema;
					if (Schema.is(field.type)) {
						fieldType = "ref";
						childTypeSchema = field.type;
					} else {
						fieldType = Object.keys(field.type)[0];
						if (typeof field.type[fieldType] === "string") fieldType += ":" + field.type[fieldType];
						else childTypeSchema = field.type[fieldType];
					}
					reflectionField.referencedType = childTypeSchema ? context.getTypeId(childTypeSchema) : -1;
				}
				reflectionField.type = fieldType;
				type.fields.push(reflectionField);
			}
			addType(type);
		});
		for (const typeid in pendingReflectionTypes) pendingReflectionTypes[typeid].forEach((type) => reflection.types.push(type));
		return reflectionEncoder.encodeAll(it).slice(0, it.offset);
	}
	/**
	* Decodes the TypeContext from a buffer into a Decoder instance.
	*
	* @param bytes Reflection.encode() output
	* @param it
	* @returns Decoder instance
	*/
	static decode(bytes, it) {
		const reflection = new Reflection();
		new Decoder(reflection).decode(bytes, it);
		const typeContext = new TypeContext();
		reflection.types.forEach((reflectionType) => {
			const parentClass = typeContext.get(reflectionType.extendsId) ?? Schema;
			const schema = class _ extends parentClass {};
			TypeContext.register(schema);
			typeContext.add(schema, reflectionType.id);
		}, {});
		const addFields = (metadata, reflectionType, parentFieldIndex) => {
			reflectionType.fields.forEach((field, i) => {
				const fieldIndex = parentFieldIndex + i;
				if (field.referencedType !== void 0) {
					let fieldType = field.type;
					let refType = typeContext.get(field.referencedType);
					if (!refType) {
						const typeInfo = field.type.split(":");
						fieldType = typeInfo[0];
						refType = typeInfo[1];
					}
					if (fieldType === "ref") Metadata.addField(metadata, fieldIndex, field.name, refType);
					else Metadata.addField(metadata, fieldIndex, field.name, { [fieldType]: refType });
				} else Metadata.addField(metadata, fieldIndex, field.name, field.type);
			});
		};
		reflection.types.forEach((reflectionType) => {
			const schema = typeContext.get(reflectionType.id);
			const metadata = Metadata.initialize(schema);
			const inheritedTypes = [];
			let parentType = reflectionType;
			do {
				inheritedTypes.push(parentType);
				parentType = reflection.types.find((t) => t.id === parentType.extendsId);
			} while (parentType);
			let parentFieldIndex = 0;
			inheritedTypes.reverse().forEach((reflectionType) => {
				addFields(metadata, reflectionType, parentFieldIndex);
				parentFieldIndex += reflectionType.fields.length;
			});
		});
		return new Decoder(new (typeContext.get(reflection.rootType || 0))(), typeContext);
	}
};
__decorate([type([ReflectionType])], Reflection.prototype, "types", void 0);
__decorate([type("number")], Reflection.prototype, "rootType", void 0);
function getDecoderStateCallbacks(decoder) {
	const $root = decoder.root;
	const callbacks = $root.callbacks;
	const onAddCalls = /* @__PURE__ */ new WeakMap();
	let currentOnAddCallback;
	decoder.triggerChanges = function(allChanges) {
		const uniqueRefIds = /* @__PURE__ */ new Set();
		for (let i = 0, l = allChanges.length; i < l; i++) {
			const change = allChanges[i];
			const refId = change.refId;
			const ref = change.ref;
			const $callbacks = callbacks[refId];
			if (!$callbacks) continue;
			if ((change.op & OPERATION.DELETE) === OPERATION.DELETE && change.previousValue instanceof Schema) {
				const deleteCallbacks = callbacks[$root.refIds.get(change.previousValue)]?.[OPERATION.DELETE];
				for (let i = deleteCallbacks?.length - 1; i >= 0; i--) deleteCallbacks[i]();
			}
			if (ref instanceof Schema) {
				if (!uniqueRefIds.has(refId)) {
					const replaceCallbacks = $callbacks?.[OPERATION.REPLACE];
					for (let i = replaceCallbacks?.length - 1; i >= 0; i--) replaceCallbacks[i]();
				}
				if ($callbacks.hasOwnProperty(change.field)) {
					const fieldCallbacks = $callbacks[change.field];
					for (let i = fieldCallbacks?.length - 1; i >= 0; i--) fieldCallbacks[i](change.value, change.previousValue);
				}
			} else {
				if ((change.op & OPERATION.DELETE) === OPERATION.DELETE) {
					if (change.previousValue !== void 0) {
						const deleteCallbacks = $callbacks[OPERATION.DELETE];
						for (let i = deleteCallbacks?.length - 1; i >= 0; i--) deleteCallbacks[i](change.previousValue, change.dynamicIndex ?? change.field);
					}
					if ((change.op & OPERATION.ADD) === OPERATION.ADD) {
						const addCallbacks = $callbacks[OPERATION.ADD];
						for (let i = addCallbacks?.length - 1; i >= 0; i--) addCallbacks[i](change.value, change.dynamicIndex ?? change.field);
					}
				} else if ((change.op & OPERATION.ADD) === OPERATION.ADD && change.previousValue !== change.value) {
					const addCallbacks = $callbacks[OPERATION.ADD];
					for (let i = addCallbacks?.length - 1; i >= 0; i--) addCallbacks[i](change.value, change.dynamicIndex ?? change.field);
				}
				if (change.value !== change.previousValue && (change.value !== void 0 || change.previousValue !== void 0)) {
					const replaceCallbacks = $callbacks[OPERATION.REPLACE];
					for (let i = replaceCallbacks?.length - 1; i >= 0; i--) replaceCallbacks[i](change.value, change.dynamicIndex ?? change.field);
				}
			}
			uniqueRefIds.add(refId);
		}
	};
	function getProxy(metadataOrType, context) {
		let metadata = context.instance?.constructor[Symbol.metadata] || metadataOrType;
		let isCollection = context.instance && typeof context.instance["forEach"] === "function" || metadataOrType && typeof metadataOrType[Symbol.metadata] === "undefined";
		if (metadata && !isCollection) {
			const onAddListen = function(ref, prop, callback, immediate) {
				if (immediate && context.instance[prop] !== void 0 && !onAddCalls.has(currentOnAddCallback)) callback(context.instance[prop], void 0);
				return $root.addCallback($root.refIds.get(ref), prop, callback);
			};
			/**
			* Schema instances
			*/
			return new Proxy({
				listen: function listen(prop, callback, immediate = true) {
					if (context.instance) return onAddListen(context.instance, prop, callback, immediate);
					else {
						let detachCallback = () => {};
						context.onInstanceAvailable((ref, existing) => {
							detachCallback = onAddListen(ref, prop, callback, immediate && existing && !onAddCalls.has(currentOnAddCallback));
						});
						return () => detachCallback();
					}
				},
				onChange: function onChange(callback) {
					return $root.addCallback($root.refIds.get(context.instance), OPERATION.REPLACE, callback);
				},
				bindTo: function bindTo(targetObject, properties) {
					if (!properties) properties = Object.keys(metadata).map((index) => metadata[index].name);
					return $root.addCallback($root.refIds.get(context.instance), OPERATION.REPLACE, () => {
						properties.forEach((prop) => targetObject[prop] = context.instance[prop]);
					});
				}
			}, {
				get(target, prop) {
					const metadataField = metadata[metadata[prop]];
					if (metadataField) {
						const instance = context.instance?.[prop];
						const onInstanceAvailable = ((callback) => {
							const unbind = $(context.instance).listen(prop, (value, _) => {
								callback(value, false);
								unbind?.();
							}, false);
							if ($root.refIds.get(instance) !== void 0) callback(instance, true);
						});
						return getProxy(metadataField.type, {
							instance: $root.refIds.get(instance) && instance,
							parentInstance: context.instance,
							onInstanceAvailable
						});
					} else return target[prop];
				},
				has(target, prop) {
					return metadata[prop] !== void 0;
				},
				set(_, _1, _2) {
					throw new Error("not allowed");
				},
				deleteProperty(_, _1) {
					throw new Error("not allowed");
				}
			});
		} else {
			/**
			* Collection instances
			*/
			const onAdd = function(ref, callback, immediate) {
				if (immediate) ref.forEach((v, k) => callback(v, k));
				return $root.addCallback($root.refIds.get(ref), OPERATION.ADD, (value, key) => {
					onAddCalls.set(callback, true);
					currentOnAddCallback = callback;
					callback(value, key);
					onAddCalls.delete(callback);
					currentOnAddCallback = void 0;
				});
			};
			const onRemove = function(ref, callback) {
				return $root.addCallback($root.refIds.get(ref), OPERATION.DELETE, callback);
			};
			const onChange = function(ref, callback) {
				return $root.addCallback($root.refIds.get(ref), OPERATION.REPLACE, callback);
			};
			return new Proxy({
				onAdd: function(callback, immediate = true) {
					if (context.instance) return onAdd(context.instance, callback, immediate && !onAddCalls.has(currentOnAddCallback));
					else if (context.onInstanceAvailable) {
						let detachCallback = () => {};
						context.onInstanceAvailable((ref, existing) => {
							detachCallback = onAdd(ref, callback, immediate && existing && !onAddCalls.has(currentOnAddCallback));
						});
						return () => detachCallback();
					}
				},
				onRemove: function(callback) {
					if (context.instance) return onRemove(context.instance, callback);
					else if (context.onInstanceAvailable) {
						let detachCallback = () => {};
						context.onInstanceAvailable((ref) => {
							detachCallback = onRemove(ref, callback);
						});
						return () => detachCallback();
					}
				},
				onChange: function(callback) {
					if (context.instance) return onChange(context.instance, callback);
					else if (context.onInstanceAvailable) {
						let detachCallback = () => {};
						context.onInstanceAvailable((ref) => {
							detachCallback = onChange(ref, callback);
						});
						return () => detachCallback();
					}
				}
			}, {
				get(target, prop) {
					if (!target[prop]) throw new Error(`Can't access '${prop}' through callback proxy. access the instance directly.`);
					return target[prop];
				},
				has(target, prop) {
					return target[prop] !== void 0;
				},
				set(_, _1, _2) {
					throw new Error("not allowed");
				},
				deleteProperty(_, _1) {
					throw new Error("not allowed");
				}
			});
		}
	}
	function $(instance) {
		return getProxy(void 0, { instance });
	}
	return $;
}
registerType("map", { constructor: MapSchema });
registerType("array", { constructor: ArraySchema });
registerType("set", { constructor: SetSchema });
registerType("collection", { constructor: CollectionSchema });
//#endregion
export { getDecoderStateCallbacks as a, encode as i, Reflection as n, decode as r, Decoder as t };
