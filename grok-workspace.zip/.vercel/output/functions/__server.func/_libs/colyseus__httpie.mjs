import { r as __exportAll } from "../_runtime.mjs";
import { request } from "https";
import { globalAgent } from "http";
import { parse, resolve } from "url";
//#region node_modules/@colyseus/httpie/node/index.mjs
var node_exports = /* @__PURE__ */ __exportAll({
	del: () => del,
	get: () => get,
	patch: () => patch,
	post: () => post,
	put: () => put,
	send: () => send
});
function toError(rej, res, err) {
	err = err || new Error(res.statusMessage);
	err.statusMessage = res.statusMessage;
	err.statusCode = res.statusCode;
	err.headers = res.headers;
	err.data = res.data;
	rej(err);
}
function send(method, uri, opts = {}) {
	return new Promise((res, rej) => {
		let req, tmp, aborted, timedout = false, out = "";
		let { redirect = true } = opts;
		opts.method = method;
		if (uri && !!uri.toJSON) uri = uri.toJSON();
		Object.assign(opts, typeof uri === "string" ? parse(uri) : uri);
		opts.agent = opts.protocol === "http:" ? globalAgent : void 0;
		req = request(opts, (rr) => {
			if (rr.statusCode > 300 && redirect && rr.headers.location) {
				opts.path = resolve(opts.path, rr.headers.location);
				return send(method, opts.path.startsWith("/") ? opts : opts.path, opts).then(res, rej);
			}
			rr.on("data", (d) => {
				out += d;
			});
			rr.on("end", () => {
				tmp = rr.headers["content-type"];
				if (tmp && out && tmp.includes("application/json")) try {
					out = JSON.parse(out, opts.reviver);
				} catch (err) {
					return toError(rej, rr, err);
				}
				rr.data = out;
				if (rr.statusCode >= 400) toError(rej, rr);
				else res(rr);
			});
		});
		req.on("timeout", function() {
			timedout = true;
			req.abort();
		});
		req.on("error", (err) => {
			err.timeout = timedout;
			err.aborted = aborted;
			rej(err);
		});
		if (opts.signal) opts.signal.addEventListener("abort", function() {
			aborted = true;
			req.destroy();
		});
		if (opts.body) {
			tmp = typeof opts.body === "object" && !Buffer.isBuffer(opts.body);
			tmp && req.setHeader("content-type", "application/json");
			tmp = tmp ? JSON.stringify(opts.body) : opts.body;
			req.setHeader("content-length", Buffer.byteLength(tmp));
			req.write(tmp);
		}
		req.end();
	});
}
var get = /*#__PURE__*/ send.bind(send, "GET");
var post = /*#__PURE__*/ send.bind(send, "POST");
var patch = /*#__PURE__*/ send.bind(send, "PATCH");
var del = /*#__PURE__*/ send.bind(send, "DELETE");
var put = /*#__PURE__*/ send.bind(send, "PUT");
//#endregion
export { node_exports as t };
